---
name: ims-ify
description: |
  Installs/updates the canonical IMS agent instruction file (`AGENTS.md`).
  Use when onboarding a repo to IMS or repairing missing/outdated instruction wiring.
license: Proprietary
compatibility: Requires Python and outbound network access to fetch templates; modifies files in the target repo.
metadata:
  user_invocable: true
  managed_files: ["AGENTS.md"]
  keywords: ["onboarding", "setup", "templates", "agents", "ims", "agents.md"]
allowed-tools: run_shell_command read_files apply_patch create_file
---

# IMS-ify Skill
This skill "IMS-ifies" a project by ensuring the standard IMS agent instruction
file is present and up to date:
- `AGENTS.md` – Unified agent instructions for IMS-backed projects

The skill is implemented as a standalone Python script that always pulls the
latest canonical `AGENTS.md` template from the IMS GitHub repository and applies
it to the current project.

---

## When to use this skill
Use this skill whenever a user says things like:
- "IMS-ify this project"
- "Convert this project to use IMS"
- "Make this project use the integrated memory system"
- "Set up IMS instructions in this repo"

The intent is: *take the project I'm currently working in and ensure it has the
canonical `AGENTS.md` so agents know how to use IMS.*

---

## What the skill does
When invoked, the skill should:
1. Treat the **current working directory** as the target project root
   unless the user explicitly specifies another directory.
2. Run the `ims_ify.py` script from this skill directory, which will:
   - Fetch the canonical `AGENTS.md` template from GitHub
   - Ensure `AGENTS.md` exists in the target project:
     - If it does not exist, create it with the template content.
     - If it exists but does **not** contain the IMS marker string, prepend the
       template content to the existing file.
     - If it already contains the IMS marker string, leave it unchanged.

Marker used for deduplication:
- `AGENTS.md`: `"IMS Agent Configuration"`

This ensures repeated IMS-ify runs are idempotent and do not duplicate
instructions.

---

## How to invoke from an agent
When the user expresses the intent to IMS-ify the **current** project, the agent
should execute a shell command equivalent to:

```bash
python "$HOME/.skilz/skills/ims-ify/ims_ify.py" --target .
```

If the user explicitly names a different directory, pass that as `--target`:

```bash
python "$HOME/.skilz/skills/ims-ify/ims_ify.py" --target /path/to/other/project
```

Agents SHOULD surface the script's output back to the user so they can see
whether `AGENTS.md` was created, updated, or already IMS-ified.

---

## Configuration and overrides
### GitHub CLI template fetch (preferred)
By default, the script will try to fetch templates using the GitHub CLI
(`gh api`) from `jdelon02/integrated-memory-system` (ref: `main`) and fall back
to raw URL fetching if needed.

To override which repo/ref `gh` reads from:

```bash
export IMS_TEMPLATE_GH_REPO="<owner>/<repo>"
export IMS_TEMPLATE_GH_REF="<branch-or-tag>"  # optional; defaults to main
python "$HOME/.skilz/skills/ims-ify/ims_ify.py" --target .
```

To disable `gh` and force raw URL fetching:

```bash
export IMS_TEMPLATE_GH_REPO=""
python "$HOME/.skilz/skills/ims-ify/ims_ify.py" --target .
```

### Raw URL template fetch (fallback)
The raw base URL can be overridden (for testing or alternate branches/forks) by
setting:

```bash
export IMS_TEMPLATE_BASE_URL="https://raw.githubusercontent.com/<owner>/<repo>/<branch>"
python "$HOME/.skilz/skills/ims-ify/ims_ify.py" --target .
```

Agents do not need to construct these URLs themselves; they should only set
these overrides if the user explicitly requests using a non-default template
source.

---

## Safety and limitations
- The script only creates or edits `AGENTS.md`.
- Existing content is preserved and simply has IMS instructions prepended when
  necessary.
- Running the skill multiple times on the same project is safe; it will not
  duplicate IMS instructions thanks to marker-based detection.
- The skill requires outbound HTTP access to GitHub (or to whatever URL is
  provided via `IMS_TEMPLATE_BASE_URL`). If template fetch fails, the script
  exits with a clear error message.
