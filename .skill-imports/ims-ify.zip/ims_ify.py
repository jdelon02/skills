#!/usr/bin/env python3
from __future__ import annotations

"""IMS-ify a target project by installing the unified IMS agent instructions.

This script is designed to live inside the ims-ify skill directory, completely
independent of the integrated-memory-system codebase. It always pulls the
canonical `AGENTS.md` template from GitHub and applies it to a target
project directory.

Behavior:
- If `AGENTS.md` does not exist in the target project, it is created with the
  IMS instructions.
- If it exists but does not already contain the IMS instructions marker,
  the IMS instructions are prepended to the existing content.
- If it already contains the IMS instructions marker, it is left unchanged.

It does NOT depend on the target project already being IMS-enabled.
"""

import argparse
import os
import base64
import json
import subprocess
from pathlib import Path
from typing import Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# Marker to detect whether AGENTS.md IMS instructions are already present
AGENTS_MARKER = "IMS Agent Configuration"

# Hard-coded GitHub raw base for IMS templates. You can override this at runtime
# with the IMS_TEMPLATE_BASE_URL environment variable if needed.
IMS_TEMPLATE_BASE_URL_DEFAULT = "https://raw.githubusercontent.com/jdelon02/integrated-memory-system/main"

# Default GitHub repo/ref used when fetching templates via the GitHub CLI.
# These can be overridden by setting IMS_TEMPLATE_GH_REPO / IMS_TEMPLATE_GH_REF.
IMS_TEMPLATE_GH_REPO_DEFAULT = "jdelon02/integrated-memory-system"
IMS_TEMPLATE_GH_REF_DEFAULT = "main"

# Optional local override: if IMS_TEMPLATE_LOCAL_PATH is set, templates will be
# read directly from that directory instead of fetched over HTTP. This is
# especially useful when the integrated-memory-system repo is private and not
# accessible via raw.githubusercontent.com.
IMS_TEMPLATE_LOCAL_PATH_ENV = "IMS_TEMPLATE_LOCAL_PATH"

# GitHub template fetch configuration.
#
# By default, this script will TRY to fetch templates via the GitHub CLI
# (`gh api`) from IMS_TEMPLATE_GH_REPO_DEFAULT, and will fall back to the raw
# GitHub URL if that fails.
#
# If you explicitly set IMS_TEMPLATE_GH_REPO, the script treats GitHub CLI fetch
# as mandatory and will raise an error if it cannot fetch.
#
# Expected format:
#   IMS_TEMPLATE_GH_REPO="owner/repo"   # e.g. "jdelon02/integrated-memory-system"
#   IMS_TEMPLATE_GH_REF="main"          # optional, defaults to "main"
#
# To explicitly disable GitHub CLI fetching and force raw URL fetching, set:
#   IMS_TEMPLATE_GH_REPO=""  (empty)
IMS_TEMPLATE_GH_REPO_ENV = "IMS_TEMPLATE_GH_REPO"
IMS_TEMPLATE_GH_REF_ENV = "IMS_TEMPLATE_GH_REF"


class IMSifyError(Exception):
    """Custom error type for IMS-ify failures."""


def _template_base_url() -> str:
    """Return the base URL for fetching IMS templates.

    By default this is the raw GitHub URL for the integrated-memory-system
    repo on the main branch, but it can be overridden with the
    IMS_TEMPLATE_BASE_URL environment variable.
    """

    return os.getenv("IMS_TEMPLATE_BASE_URL", IMS_TEMPLATE_BASE_URL_DEFAULT).rstrip("/")


def _template_local_base() -> Optional[Path]:
    """Return a local base path for templates, if configured.

    If the IMS_TEMPLATE_LOCAL_PATH environment variable is set, we will read
    templates directly from that directory instead of fetching over HTTP.
    This is useful when the integrated-memory-system repo is private.
    """

    raw = os.getenv(IMS_TEMPLATE_LOCAL_PATH_ENV)
    if not raw:
        return None
    return Path(raw).expanduser().resolve()


def _template_gh_repo() -> Tuple[Optional[str], Optional[str], bool]:
    """Return GitHub repo/ref for template fetch and whether it is strict.

    Returns (repo, ref, strict):
    - repo/ref: which repo and ref to fetch from via `gh api`
    - strict: True if user explicitly configured IMS_TEMPLATE_GH_REPO and we
      should fail fast on any `gh` error.

    Default behavior (not strict): try GitHub CLI first (if available) against
    IMS_TEMPLATE_GH_REPO_DEFAULT/IMS_TEMPLATE_GH_REF_DEFAULT, then fall back to
    the raw GitHub URL.

    If IMS_TEMPLATE_GH_REPO is set explicitly:
    - non-empty: use that repo (strict=True)
    - empty: disable GitHub CLI fetch entirely
    """

    if IMS_TEMPLATE_GH_REPO_ENV in os.environ:
        repo = (os.environ.get(IMS_TEMPLATE_GH_REPO_ENV) or "").strip()
        if not repo:
            return None, None, True
        ref = os.environ.get(IMS_TEMPLATE_GH_REF_ENV, IMS_TEMPLATE_GH_REF_DEFAULT)
        return repo, ref, True

    return IMS_TEMPLATE_GH_REPO_DEFAULT, IMS_TEMPLATE_GH_REF_DEFAULT, False


def _fetch_template_via_gh(relative_path: str) -> Optional[str]:
    """Attempt to fetch a template file via the GitHub CLI.

    Returns decoded text content on success.

    If GitHub CLI fetching is disabled (explicitly), returns None.

    If GitHub CLI fetching is enabled by default (non-strict) and `gh` fails,
    returns None so callers can fall back to raw URL fetching.

    If GitHub CLI fetching is explicitly configured (strict) and `gh` fails,
    raises IMSifyError.
    """

    repo, ref, strict = _template_gh_repo()
    if repo is None or ref is None:
        # Either explicitly disabled (strict=True) or not configured.
        return None

    path = relative_path.lstrip("/")

    # Use `gh api repos/:owner/:repo/contents/:path?ref=...` to get file
    # metadata + base64-encoded content.
    try:
        proc = subprocess.run(
            [
                "gh",
                "api",
                f"repos/{repo}/contents/{path}",
                "--method",
                "GET",
                "-q",
                ".",
                "-f",
                f"ref={ref}",
            ],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        if strict:
            raise IMSifyError(
                "GitHub CLI 'gh' not found but IMS_TEMPLATE_GH_REPO is set; "
                "install gh or unset IMS_TEMPLATE_GH_REPO."
            ) from exc
        return None

    if proc.returncode != 0:
        stderr = proc.stderr.strip() or "unknown error"
        if strict:
            raise IMSifyError(
                f"Failed to fetch IMS template via gh for {repo}@{ref}:{path}: {stderr}"
            )
        return None

    try:
        meta = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        if strict:
            raise IMSifyError("Failed to parse GitHub API response as JSON") from exc
        return None

    content_b64 = meta.get("content")
    encoding = meta.get("encoding")
    if not content_b64 or encoding != "base64":
        if strict:
            raise IMSifyError(
                "GitHub API response missing base64-encoded 'content' field for template"
            )
        return None

    try:
        raw_bytes = base64.b64decode(content_b64)
    except (base64.binascii.Error, TypeError) as exc:
        if strict:
            raise IMSifyError("Failed to decode base64 content from GitHub API") from exc
        return None

    try:
        return raw_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        if strict:
            raise IMSifyError("Failed to decode GitHub template content as UTF-8") from exc
        return None

def fetch_template(relative_path: str) -> str:
    """Fetch an IMS template file from either local disk, GitHub, or raw URL.

    The relative_path should be a repository-relative path like
    "AGENTS.md".
    """

    # 1) Local override if configured.
    local_base = _template_local_base()
    if local_base is not None:
        local_file = (local_base / relative_path.lstrip("/")).resolve()
        if not local_file.exists():
            raise IMSifyError(
                f"Local IMS template not found at {local_file} (from {IMS_TEMPLATE_LOCAL_PATH_ENV})"
            )
        try:
            return local_file.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            raise IMSifyError(f"Failed to decode local IMS template {local_file} as UTF-8") from exc

    # 2) Try GitHub via gh CLI first (default), then fall back to raw.
    gh_content = _fetch_template_via_gh(relative_path)
    if gh_content is not None:
        return gh_content

    # 3) Fallback to HTTP fetch from the configured base URL (raw.githubusercontent).
    base = _template_base_url()
    url = f"{base}/{relative_path.lstrip('/')}"
    req = Request(url, headers={"User-Agent": "ims-ify/1.0"})

    try:
        with urlopen(req, timeout=10.0) as resp:  # nosec B310 - controlled URL
            data = resp.read()
    except HTTPError as exc:  # pragma: no cover - network dependent
        raise IMSifyError(f"Failed to fetch IMS template from {url}: HTTP {exc.code}") from exc
    except URLError as exc:  # pragma: no cover - network dependent
        raise IMSifyError(f"Failed to fetch IMS template from {url}: {exc.reason}") from exc

    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:  # pragma: no cover - unexpected
        raise IMSifyError(f"Failed to decode IMS template from {url} as UTF-8") from exc


def ensure_instructions(
    target_path: Path,
    template: str,
    marker: str,
) -> Tuple[bool, bool]:
    """Ensure the IMS instructions are present in the target file.

    Returns a tuple (created, modified):
      - created: True if the file was newly created
      - modified: True if the file existed and was modified
    """

    if not target_path.exists():
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(template, encoding="utf-8")
        return True, False

    existing = target_path.read_text(encoding="utf-8")

    if marker in existing:
        # Already IMS-ified
        return False, False

    # Prepend IMS instructions to existing content
    new_content = template.rstrip("\n") + "\n\n" + existing
    target_path.write_text(new_content, encoding="utf-8")
    return False, True


def ims_ify_project(target_dir: Path) -> None:
    """IMS-ify the given project directory.

    This will ensure a unified `AGENTS.md` file exists in the target
    directory with the canonical IMS agent instructions.
    """

    target_dir = target_dir.resolve()

    # Fetch canonical AGENTS.md template from the IMS GitHub repo.
    agents_template = fetch_template("AGENTS.md")

    agents_target = target_dir / "AGENTS.md"

    created, modified = ensure_instructions(agents_target, agents_template, AGENTS_MARKER)

    print(f"IMS-ify results for project: {target_dir}")
    if created:
        status = "created"
    elif modified:
        status = "updated (prepended IMS instructions)"
    else:
        status = "already IMS-ified (no changes)"
    print(f"  - AGENTS.md: {status}")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="IMS-ify a project by injecting IMS agent instructions.")
    parser.add_argument(
        "--target",
        "-t",
        type=str,
        default=".",
        help="Target project directory to IMS-ify (default: current directory)",
    )

    args = parser.parse_args(argv)
    target_dir = Path(args.target)

    try:
        ims_ify_project(target_dir)
    except IMSifyError as exc:
        raise SystemExit(f"IMS-ify failed: {exc}")


if __name__ == "__main__":  # pragma: no cover
    main()
