---
name: context-rag
description: |
  Unified IMS context retrieval (RAG) across code (Qdrant), docs (Meilisearch), and long-term memories (`memory-core`).
  Use when planning/debugging/implementing and you need grounded project context via `context_search`.
license: Proprietary
compatibility: Requires network access to IMS backend services (Qdrant, Meilisearch) and memory-core; read-only retrieval.
metadata:
  user_invocable: true
  phase: 3
  operations: ["context_search"]
  keywords: ["rag", "context_search", "qdrant", "meilisearch", "code search", "docs search", "memories", "ims"]
allowed-tools: read_mcp_resource call_mcp_tool
---

# context-rag Skill

Unified context retrieval for the Integrated Memory System. This skill
combines:

- Code context from a Qdrant `ims_code_context` collection
- Documentation/search from Meilisearch (e.g. `project_docs` index)
- Long-term memories from the `memory-core` skill (`/memories/search`)

All queries are scoped to a specific `project_id` (usually `basename($PWD)`).

---

## Identity & Scope

- `project_id` – required; identifies the current project (e.g. repo name).
- Optional filters:
  - `sources` – which context sources to query (`"code"`, `"docs"`, `"memories"`).
  - `per_source_limits` – per-source result caps.

This service does **not** manage sessions; use `session-memory` for
per-agent, per-task state. `context-rag` is stateless and purely reads from
indexes and `memory-core`.

---

## Data Model: ContextHit

Each result from `context-rag` is normalized into a `ContextHit`:

- `id` (string) – identifier for the underlying entity (e.g. file path, doc id,
  memory id).
- `source` (string) – one of:
  - `"code"` – code snippet from Qdrant `ims_code_context`.
  - `"docs"` – documentation or note snippet from Meilisearch.
  - `"memories"` – long-term memory from `memory-core`.
- `score` (number) – relative relevance score (higher is better).
- `snippet` (string) – short text snippet to show in the prompt.
- `metadata` (object) – additional fields, varying by source. Examples:
  - For `code`: `{ "path": "src/main.py", "start_line": 42, "end_line": 55 }`
  - For `docs`: `{ "title": "Session Design", "url": "..." }`
  - For `memories": { "kind": "decision", "tags": ["auth", "db"] }`

---

## Skill Operation: context_search

**Operation**: `context_search({ project_id, query, sources?, per_source_limits?, expand_graph?, graph_depth? })`

Retrieve relevant context for a given project and natural language query,
optionally constrained to specific sources and per-source limits. By default,
performs hybrid vector + graph search to include structurally related entities.

### Request

```json
{
  "project_id": "my-project",
  "query": "How do we store and resume session state?",
  "sources": ["code", "docs", "memories"],
  "per_source_limits": {
    "code": 5,
    "docs": 5,
    "memories": 5
  }
}
```

Agents and tools MUST call the `context-rag` skill/client (or
`IMSClient().context_rag.context_search(...)`). The JSON above describes
the payload shape for this operation.

Fields:

- `project_id` (string, required)
- `query` (string, required)
- `sources` (array of strings, optional)
  - Allowed values: `"code"`, `"docs"`, `"memories"`.
  - Default: all three sources.
- `per_source_limits` (object, optional)
  - Keys: subset of `"code"`, `"docs"`, `"memories"`.
  - Values: integer limit per source. If omitted, sensible defaults (e.g. 5).
- `expand_graph` (boolean, optional, default: `true`)
  - Enable graph relationship expansion after vector search.
  - When true, vector results are enriched with related entities from the
    ontology graph (Decisions, Bugs, Features, Components).
  - Set to false for vector-only search when graph relationships aren't needed.
- `graph_depth` (integer, optional, default: `2`)
  - How deep to traverse graph relationships (1-3).
  - Higher values return more context but may be slower.
  - `depth=1`: Direct relationships only.
  - `depth=2`: Relationships of relationships (recommended).
  - `depth=3`: Extended graph traversal (use sparingly).

### Behavior

#### Hybrid Vector + Graph Search (Default)

By default (`expand_graph=true`), `context_search` performs hybrid retrieval:

1. **Vector Search Phase**:
   - **Code context** (`"code"` in `sources`):
     - Compute an embedding for `query` using the same model as `memory-core`.
     - Ensure Qdrant `ims_code_context` collection exists.
     - Query Qdrant using `query_points` with a filter on `project_id` and
       `limit = per_source_limits["code"] or default`.
     - Map each `ScoredPoint` to a `ContextHit` with `source="code"`, using
       the point score and payload fields (e.g., `path`, `snippet`).

   - **Docs context** (`"docs"` in `sources`):
     - Use Meilisearch (via `IMS_MEILI_URL` / `IMS_MEILI_API_KEY`).
     - Query index `project_docs` (configurable) with `q = query` and a
       filter `project_id = <project_id>`.
     - Map each hit to a `ContextHit` with `source="docs"`, using `_rankingScore`
       and a text snippet (`snippet`/`content`/`text`).

   - **Memory context** (`"memories"` in `sources`):
     - Call `POST /memories/search` (memory-core) with:

       ```json
       {
         "project_id": "my-project",
         "query": "...",
         "kinds": null,
         "tags": null,
         "limit": <per_source_limits["memories"] or default>
       }
       ```

     - Map each returned `MemoryOut` to a `ContextHit` with `source="memories"`,
       `snippet = memory.text`, and `metadata = {"kind", "tags"}`.

2. **Graph Expansion Phase** (if `expand_graph=true`):
   - For each vector result, traverse the ontology graph to find related entities:
     - **Related Decisions** that affect returned Components
     - **Bugs** that block returned Features
     - **Components** that depend on returned Components
     - **Superseded decisions** to avoid outdated information
   - Traversal depth controlled by `graph_depth` parameter.
   - Graph-expanded results are marked with `metadata.graph_node = true`.

3. **Merge & Sort**:
   - Concatenate vector hits with graph-expanded context into a single list.
   - Deduplicate by entity ID.
   - Sort by `score` descending.
   - Return as `ContextSearchResult`.

#### When to Disable Graph Expansion

Set `expand_graph=false` for vector-only search when:
- Simple keyword searches where relationships don't matter
- Performance-critical queries where speed matters more than context depth
- Searching for specific text/code snippets without needing related context

#### Error Handling

On errors talking to Qdrant or Meilisearch, the service currently **fails
open** for that source (skips those hits rather than failing the whole
request). Memory-core and graph errors are propagated as HTTP 500s.

### Response

```json
{
  "results": [
    {
      "id": "code-1",
      "source": "code",
      "score": 0.92,
      "snippet": "def resume_session(session_id): ...",
      "metadata": {
        "project_id": "my-project",
        "path": "src/session.py",
        "start_line": 120,
        "end_line": 140
      }
    },
    {
      "id": "doc-7",
      "source": "docs",
      "score": 8.7,
      "snippet": "Session state is stored in Redis under the key ims:session:...",
      "metadata": {
        "title": "Session Design",
        "project_id": "my-project",
        "url": "https://docs.example.com/sessions"
      }
    },
    {
      "id": "mem-42",
      "source": "memories",
      "score": 1.0,
      "snippet": "We decided to persist SessionState keyed by project/user/agent/task.",
      "metadata": {
        "kind": "decision",
        "tags": ["session", "redis"],
        "graph_node": true
      }
    },
    {
      "id": "component-auth",
      "source": "memories",
      "score": 1.0,
      "snippet": "Auth component depends on session management for user context.",
      "metadata": {
        "kind": "component",
        "tags": ["architecture"],
        "graph_node": true
      }
    }
  ]
}
```

Note: Results with `metadata.graph_node = true` were added via graph expansion,
not direct vector search.

---

## Capability Endpoint

The backend exposes `GET /capabilities/context-rag` which returns structured documentation about:
- Available operations (context_search)
- Source types (code, docs, memories)
- Query best practices and usage guidance

This endpoint is used by hooks to inject usage documentation into agent context at appropriate times. The PreToolUse hook automatically fetches and includes context-rag capabilities when searching for related context before file modifications.

---

## Hook Integration

**PreToolUse Automation**: Before Edit/Write operations on code files, the PreToolUse hook automatically:
1. Calls `context_search` with a query based on the file path and operation type
2. Fetches context-rag capabilities from `/capabilities/context-rag`
3. Injects both search results and usage documentation into agent context

This provides agents with relevant past work, related code patterns, and documentation right when they need it, helping prevent repeated mistakes and maintain consistency.

**PostToolUse Automation**: After file Edit/Write operations, the PostToolUse hook:
1. Calls `context_search` to find related memories and code
2. Includes these findings in memory storage suggestions

Agents can still call `context_search` directly at any time for additional context retrieval.

---

## Usage Examples

### Example 1: Graph-Expanded Search (Default)

Use hybrid vector + graph search for comprehensive context:

```json
{
  "project_id": "my-app",
  "query": "authentication implementation",
  "sources": ["code", "memories"],
  "per_source_limits": {"code": 5, "memories": 5},
  "expand_graph": true,
  "graph_depth": 2
}
```

**Returns:**
- **Vector hits**: Auth code files, authentication-related memories
- **Graph expansion**: Decisions about auth architecture, bugs blocking auth
  features, components depending on auth service, superseded auth decisions

**Use when**: Planning work, debugging issues, understanding architectural
context, or exploring related decisions/components.

### Example 2: Vector-Only Search

Disable graph expansion for simple keyword searches:

```json
{
  "project_id": "my-app",
  "query": "authentication",
  "sources": ["code"],
  "expand_graph": false
}
```

**Returns**: Only vector-similar code files, no graph relationships.

**Use when**: Looking for specific code snippets, performance-critical searches,
or when graph relationships aren't relevant.

### Example 3: Deep Graph Traversal

Use higher graph depth for extensive context:

```json
{
  "project_id": "my-app",
  "query": "payment processing",
  "sources": ["memories", "docs"],
  "expand_graph": true,
  "graph_depth": 3
}
```

**Returns**: Vector hits plus extended graph traversal (relationships of
relationships of relationships).

**Use when**: Analyzing complex dependencies, understanding blast radius of
architectural changes, or exploring deep component relationships.

**Caution**: Higher depth = slower queries. Use `graph_depth=3` sparingly.

---

## Recommended Agent Workflow

1. **Before major reasoning steps** (planning, debugging, design):
   - Call `context-rag.context_search(...)` (or
     `IMSClient().context_rag.context_search(...)`) with `sources` including
     at least `"memories"` and whichever of `"code"`/`"docs"` are relevant.
   - Inject the returned `snippet` + `metadata` into the LLM prompt to provide
     grounded context.

2. **Use source-specific strategies**:
   - For `code` hits: open `metadata.path` at `start_line`/`end_line`.
   - For `docs` hits: follow `metadata.url` or show `snippet` to the user.
   - For `memories` hits: surface `metadata.kind`/`tags` and treat as prior
     knowledge or constraints.

3. **Combine with `session-memory`**:
   - Use `session-memory` to track what has been read or applied from the
     context (e.g., mark certain `ContextHit.id` values as "used").

4. **Leverage graph expansion by default**:
   - Leave `expand_graph=true` (default) for most queries to benefit from
     relationship-enriched context automatically.
   - Only disable graph expansion (`expand_graph=false`) for simple keyword
     searches or performance-critical scenarios.

5. **For advanced graph operations**:
   - Use the `graph-rag` skill for creating graph entities (Decisions, Bugs,
     Features, Components), analyzing impact, tracking architectural drift,
     and managing self-improving patterns.
   - `context-rag` provides read-only graph-enriched retrieval.
   - `graph-rag` provides full graph read/write capabilities.

This skill is the primary way for agents to gather relevant, project-scoped
knowledge before taking actions. Graph expansion (enabled by default) enriches
vector search results with structurally related entities for deeper context.
