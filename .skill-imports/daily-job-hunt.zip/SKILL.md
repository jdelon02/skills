---
name: daily-job-hunt
description: Automated daily LinkedIn job search with AI-powered filtering and cover letter generation. Uses linkedin_mcp to discover jobs, OpenAI to score fit, and generates tailored cover letters for high-match roles.
allowed-tools:
  - Read
  - Write
  - Edit
  - mcp__linkedin_mcp__search_jobs
  - mcp__linkedin_mcp__get_job_details
  - mcp__linkedin_mcp__get_person_profile
---

# Daily LinkedIn Job Hunt

Automated daily workflow to discover, filter, and generate cover letters for high-match LinkedIn jobs.

## Quick Start

```
User: "Run my daily job hunt"

Agent:
1. Read keywords from ~/Projects/Personal/jobhunt2026/keywords.json
2. Fetch my LinkedIn profile once
3. Search LinkedIn for each keyword
4. Log all job URLs to all_jobs_urls.jsonl
5. For each job: filter by remote + US + high/excellent match
6. Generate cover letters for qualifying jobs
```

**Key principle:** Non-interactive, fully automated filtering. Only generate letters for jobs that meet ALL criteria.

---

## Configuration

### Required Files

| File | Purpose |
|------|---------|
| `~/Projects/Personal/jobhunt2026/keywords.json` | Search keywords (editable) |
| `~/Projects/Personal/jobhunt2026/all_jobs_urls.jsonl` | Job URL log (append-only) |
| `~/Projects/Personal/jobhunt2026/cover_letters/` | Generated cover letters |

### Environment Variables

```bash
LINKEDIN_USERNAME="your-linkedin-username"  # Required
OPENAI_API_KEY="sk-..."                      # Required
OPENAI_MODEL="gpt-4o-mini"                   # Optional (default: gpt-4.1-mini)
```

---

## Workflow

### Phase 1: Load Configuration

**Actions:**
1. Read `~/Projects/Personal/jobhunt2026/keywords.json`
2. Parse list of `{"keyword": "...", "location": "..."}` entries
3. Verify at least one keyword exists

**If file missing:**
```
keywords.json not found. Creating template with example keywords...
[Created file with System Engineer, Backend Developer, Drupal Developer]
Please edit keywords.json to add your search terms, then re-run.
```

---

### Phase 2: Fetch Profile (Once Per Run)

**Tool:** `linkedin_mcp.get_person_profile`

**Call:**
```json
{
  "linkedin_username": "<from LINKEDIN_USERNAME env var>"
}
```

**Result:** Store profile in memory for entire run (used for all match scoring)

**If username not set:**
```
LINKEDIN_USERNAME environment variable not set.
Set it to your LinkedIn username (e.g., "jdelon02") and re-run.
```

---

### Phase 3: Search Jobs

**For each keyword in keywords.json:**

**Tool:** `linkedin_mcp.search_jobs`

**Call:**
```json
{
  "keywords": "<keyword>",
  "location": "<location from keywords.json>",
  "limit": 25
}
```

**Result:** List of job URLs

**Actions:**
1. Log each URL immediately to `all_jobs_urls.jsonl`:
   ```json
   {"timestamp": "2026-02-03T05:10:00Z", "keyword": "System Engineer", "url": "https://..."}
   ```
2. Extract job ID from URL (handles `/jobs/view/<id>` and `currentJobId=<id>` patterns)
3. Deduplicate job IDs across all keyword searches
4. Build list of unique jobs to process

---

### Phase 4: Score & Filter Jobs

**For each unique job:**

#### Step 4a: Get Job Details

**Tool:** `linkedin_mcp.get_job_details`

**Call:**
```json
{
  "job_id": "<extracted job ID>"
}
```

**Result:** Job title, company, location, description

#### Step 4b: AI Match Scoring

**OpenAI Call (JSON mode):**

**System Prompt:**
```
You are a precise job-matching and cover-letter assistant.
You must respond with STRICT JSON only (no markdown, no comments).
```

**User Prompt:**
```json
{
  "instructions": "Given my LinkedIn profile and a job posting, decide if the job is remote, US-based, and a high or excellent match for me. If and only if ALL these conditions are met, generate a markdown cover letter for that job. The first line of the markdown must be exactly the job URL, then a blank line, then the letter body.",
  "job_url": "<job URL>",
  "my_profile": { <full profile from Phase 2> },
  "job": { <job details from get_job_details> },
  "output_schema": {
    "type": "object",
    "properties": {
      "is_remote": {"type": "boolean"},
      "is_us_company": {"type": "boolean"},
      "match_level": {"type": "string", "enum": ["low", "medium", "high", "excellent"]},
      "cover_letter_markdown": {"type": ["string", "null"]}
    },
    "required": ["is_remote", "is_us_company", "match_level", "cover_letter_markdown"]
  },
  "rules": [
    "Classify is_remote as true only if the job clearly allows remote or work-from-home.",
    "Classify is_us_company as true only if the company appears US-based (location, description, etc.).",
    "Use match_level=high if I meet almost all core requirements.",
    "Use match_level=excellent if my experience is very strongly aligned.",
    "If either is_remote or is_us_company is false, OR match_level is low or medium, set cover_letter_markdown to null."
  ]
}
```

**Response Schema:**
```json
{
  "is_remote": true,
  "is_us_company": true,
  "match_level": "high",
  "cover_letter_markdown": "https://linkedin.com/jobs/view/123...\n\nDear Hiring Manager,\n\n[Cover letter body]\n\nSincerely,\n[Name]"
}
```

#### Step 4c: Save Cover Letter

**If ALL conditions met:**
- `is_remote == true`
- `is_us_company == true`
- `match_level in ["high", "excellent"]`
- `cover_letter_markdown` is non-null string

**Action:**
Write to `~/Projects/Personal/jobhunt2026/cover_letters/<job_id>.md`

**Otherwise:** Skip (no cover letter generated)

---

## Output Files

### all_jobs_urls.jsonl

Append-only log of every job URL discovered.

**Format (one JSON object per line):**
```json
{"timestamp": "2026-02-03T05:10:00Z", "keyword": "System Engineer", "url": "https://linkedin.com/jobs/view/4079285952"}
{"timestamp": "2026-02-03T05:10:05Z", "keyword": "BackEnd Developer", "url": "https://linkedin.com/jobs/view/4079285952"}
{"timestamp": "2026-02-03T05:10:10Z", "keyword": "Drupal Developer", "url": "https://linkedin.com/jobs/view/4081234567"}
```

**Purpose:** Complete history, allows deduping on later runs, manual review

---

### cover_letters/<job_id>.md

Generated markdown cover letters for high-match jobs.

**Format:**
```markdown
https://linkedin.com/jobs/view/4079285952

Dear Hiring Manager,

I am writing to express my interest in the [Job Title] position at [Company]. With [N] years of experience in [relevant areas], I am confident I can contribute to [specific company goal or value].

[Paragraph highlighting relevant experience and achievements]

[Paragraph showing understanding of company/role and alignment]

I would welcome the opportunity to discuss how my background aligns with [Company]'s needs.

Sincerely,
[Your Name]
```

**First line:** Always exact job URL (enables easy click-through)

---

## Job ID Extraction

**Handles two LinkedIn URL patterns:**

### Pattern 1: `/jobs/view/<id>`
```
https://www.linkedin.com/jobs/view/4079285952/
https://www.linkedin.com/jobs/view/4079285952?refId=...
```
Extract: `4079285952`

### Pattern 2: `currentJobId=<id>`
```
https://www.linkedin.com/jobs/search/?currentJobId=4079285952&...
```
Extract: `4079285952`

**Deduplication:** Track job IDs in a set during run to avoid processing same job multiple times

---

## Error Handling

### LinkedIn MCP Errors

| Error | Action |
|-------|--------|
| Profile not found | Report to user, suggest checking LINKEDIN_USERNAME |
| Search returns no results | Log, continue with other keywords |
| Job details unavailable | Log job URL, skip (don't generate letter) |
| Rate limit hit | Wait 60s, retry once, skip if still failing |

### OpenAI Errors

| Error | Action |
|-------|--------|
| API key invalid | Report to user, halt workflow |
| JSON parsing failed | Log error, skip job, continue with next |
| Rate limit | Wait and retry with exponential backoff |

### File System Errors

| Error | Action |
|-------|--------|
| keywords.json missing | Create template, prompt user to edit |
| Cannot write to cover_letters/ | Create directory, retry |
| Cannot append to all_jobs_urls.jsonl | Create file, retry |

---

## Usage Examples

### Basic Invocation

```
User: "Run my daily job hunt"

Agent:
✓ Loaded 3 keywords from keywords.json
✓ Fetched LinkedIn profile for jdelon02
✓ Searching: "System Engineer" in United States (25 results)
✓ Searching: "BackEnd Developer" in United States (25 results)
✓ Searching: "Drupal Developer" in United States (25 results)
✓ Logged 75 job URLs to all_jobs_urls.jsonl
✓ Processing 63 unique jobs...

Job 1/63: Senior Backend Engineer at Stripe
  ✓ Remote: yes
  ✓ US company: yes
  ✓ Match: excellent
  → Cover letter saved: cover_letters/4079285952.md

Job 2/63: Systems Engineer at Lockheed Martin
  ✗ Remote: no (on-site in Arlington, VA)
  → Skipped

Job 3/63: Backend Developer at startup
  ✓ Remote: yes
  ✗ US company: no (UK-based)
  → Skipped

...

Summary:
- Total jobs found: 75 URLs (63 unique)
- Cover letters generated: 8
- See: ~/Projects/Personal/jobhunt2026/cover_letters/
```

### Add New Keyword

```
User: "Add 'DevOps Engineer' to my job search keywords"

Agent:
✓ Read keywords.json
✓ Added: {"keyword": "DevOps Engineer", "location": "United States"}
✓ Saved keywords.json

Next run will search for DevOps Engineer in addition to existing keywords.
```

### Review Results

```
User: "Show me today's top job matches"

Agent:
✓ Read cover_letters/ directory
✓ Found 8 cover letters generated today

Top matches:
1. Senior Backend Engineer at Stripe
   URL: https://linkedin.com/jobs/view/4079285952
   Match: excellent
   Cover letter: cover_letters/4079285952.md

2. System Architect at HashiCorp
   URL: https://linkedin.com/jobs/view/4081234567
   Match: high
   Cover letter: cover_letters/4081234567.md

...

Would you like me to:
- Open a specific cover letter for review
- Run job-fit-analysis on a top job for deeper positioning
- Use apply-job to submit applications
```

---

## Integration with Other Skills

### After Daily Run

**For top 1-3 jobs, use deeper skills:**

#### job-fit-analysis
```
User: "Analyze my fit for the Stripe backend engineer role"

[Invokes job-fit-analysis skill with job URL]
→ Deep gap analysis
→ Reframing strategies
→ Cover letter strategic plan
```

#### cv-creator
```
User: "Create a resume variant for backend engineering roles"

[Invokes cv-creator skill]
→ ATS-optimized resume
→ Keyword-matched for backend roles
→ PDF/DOCX/JSON formats
```

#### apply-job
```
User: "Apply to the Stripe job"

[Invokes apply-job skill with job URL]
→ Auto-fill application
→ Recruiter outreach (email + LinkedIn)
→ Track in applications.json
```

---

## Scheduling

### Manual Daily Runs

Run from Warp/agent:
```
User: "Run my daily job hunt"
```

### Automated (Future)

**Option A: Cron via wrapper script**
```bash
#!/bin/bash
# ~/bin/daily-job-hunt.sh
cd ~/Projects/Personal/jobhunt2026
warp-agent-cli run-skill daily-job-hunt >> jobhunt.log 2>&1
```

Crontab:
```
0 8 * * * ~/bin/daily-job-hunt.sh
```

**Option B: launchd plist** (macOS)
Create `~/Library/LaunchAgents/com.user.daily-job-hunt.plist` that invokes the skill via agent CLI

---

## Success Criteria

✅ Runs without user interaction (fully automated)
✅ Logs every job URL seen (complete history)
✅ Only generates cover letters for: remote + US + high/excellent match
✅ Cover letters include job URL on first line
✅ Can be scheduled to run daily
✅ Handles errors gracefully (continues processing other jobs)
✅ Fast enough to process 50-100 jobs in reasonable time (<10 min)

---

## Troubleshooting

### No cover letters generated

**Possible causes:**
1. No jobs matched filters (remote + US + high/excellent)
2. OpenAI model being too conservative with "high" ratings
3. Job descriptions don't align with profile

**Solution:**
- Review `all_jobs_urls.jsonl` to see jobs found
- Manually check a few job URLs to verify they should match
- Consider adjusting match threshold (add "medium" tier)

### Rate limits

**LinkedIn:**
- Reduce `limit` per keyword search (default: 25)
- Add delay between searches

**OpenAI:**
- Use cheaper model (gpt-4o-mini)
- Implement exponential backoff

### Stale profile data

**If your LinkedIn changes:**
Profile is fetched fresh every run, so just run again after updating LinkedIn

---

**Line Count:** ~450 (detailed workflow for automation)
**Dependencies:** linkedin_mcp, OpenAI API
**Output:** all_jobs_urls.jsonl, cover_letters/*.md
