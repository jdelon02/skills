---
name: context-maintenance
description: |
  IMS maintenance utilities (reindex docs/specs/plans for context-rag).
  Use after documentation changes when context-rag results are stale (`ReindexMe`) or to enable the IMS graph workflow (`EnableIMSGraph`).
license: Proprietary
compatibility: Requires access to IMS docs indexing pipeline and Meilisearch credentials/config; writes to project_docs index.
metadata:
  user_invocable: true
  operations: ["ReindexMe", "EnableIMSGraph"]
  keywords: ["reindex", "meilisearch", "project_docs", "context-rag", "ims-graph", "workflow"]
allowed-tools: run_shell_command read_files apply_patch create_file
---

# context-maintenance Skill

Maintenance wrapper around the Integrated Memory System (IMS) backend.

This skill currently provides:

- **ReindexMe** – reindex project docs into Meilisearch `project_docs`
  so `/context/search` can surface updated specs/plans/requirements.
- **EnableIMSGraph** – install a standard GitHub Actions workflow
  that builds an `ims-graph` artifact suitable for Neo4j ingestion.

---

## Invocation

### User-facing trigger

Trigger this skill when the user says:

- `ReindexMe`

or any clear variant like:

- "Please reindex docs for this project"
- "Reindex context for this repo"

### Behavior on `ReindexMe`

When you detect `ReindexMe` in an IMS-backed project:

1. Determine `project_id`:

   - Prefer explicit `IMS_PROJECT_ID` env var if set.
   - Otherwise default to `basename($PWD)`.

2. Run the docs indexing pipeline for this project. In this repo,
   that means calling the `index_docs_for_project` function from
   `app.index_docs` (or invoking the module as a script):

   - **Preferred (Python entrypoint)**:

     ```bash
     IMS_PROJECT_ID=<project_id> \
     python -m app.index_docs
     ```

   - **Behavior**:
     - Walks the repo root.
     - Indexes:
       - Root `README.md` and `WARP.md` (if present).
       - All `*.md` files under top-level:
         - `spec/`
         - `docs/`
         - `technical_requirements/`
         - `diagrams/`
     - Upserts documents into Meilisearch index `project_docs`
       (primary key `id`), using `IMS_MEILI_URL` and
       `IMS_MEILI_API_KEY`.

3. After indexing completes, **summarize** to the user:

   - Which project_id was indexed.
   - How many docs were updated (if available from the pipeline logs).
   - Remind them that `/context/search` `docs` results now reflect
     the latest content.

---

## Environment & Assumptions

This skill assumes:

- You are in an IMS-aware project wired to the Integrated Memory
  System backend.
- The `integrated-memory-system` service is available in the
  environment (or reachable where the CLI runs).
- Meilisearch is configured via:

  - `IMS_MEILI_URL` (e.g. `http://localhost:7700`)
  - `IMS_MEILI_API_KEY` (if required)

- The docs indexing pipeline exists as:

  - `app/index_docs.py` with `index_docs_for_project(project_id: str)`,
  - or an equivalent CLI entrypoint `python -m app.index_docs`.

---

## Safety & Frequency

- It is **not** necessary to run `ReindexMe` on every session.
- Recommended triggers:
  - After editing specs/requirements/implementation plans.
  - After adding new documentation under `spec/`, `docs/`,
    `technical_requirements/`, or `diagrams/`.
- Avoid calling it in a tight loop; it may be moderately expensive
  on large repos (reading many markdown files and updating Meilisearch).

---

## Future Extensions

This skill is intentionally narrow for now (docs-only). Later it can
be extended to:

- `ReindexCode` – reindex code context into Qdrant `ims_code_context`.
- `RebuildGraph` – repopulate Neo4j graph nodes/edges for `/graph/query`.
- A combined `ReindexAll` that orchestrates docs + code + graph as
  a maintenance operation.

## EnableIMSGraph

### User-facing trigger

Trigger this workflow when the user says:

- `EnableIMSGraph`
- or explicitly asks to "enable the IMS Neo4j graph workflow" for the
  current GitHub repository.

### Behavior on `EnableIMSGraph`

When you detect `EnableIMSGraph` in a Git-backed project:

1. Determine the repo root (project root) and ensure it is a Git repo
   with a `.git` directory.

2. Ensure the IMS graph tooling is present in the current project by
   copying templates from the `integrated-memory-system` repo:

   - Workflow template:
     - Source: `templates/github/ims-graph-workflow.yml`
     - Destination: `.github/workflows/ims-graph.yml`

   - Script templates (if they do not already exist in the target repo):
     - Source: `templates/scripts/build_graph.sh`
       Destination: `.github/scripts/build_graph.sh`
     - Source: `templates/scripts/build_graph.py`
       Destination: `.github/scripts/build_graph.py`

   The resulting workflow and scripts should match the templates,
   unless the user has explicitly requested customizations.

3. If a workflow already exists at `.github/workflows/ims-graph.yml`:

   - Show the diff between the existing file and the template.
   - Ask the user whether to:
     - overwrite with the latest template, or
     - keep the existing version.

4. After copying, summarize to the user:

   - Confirm the file `.github/workflows/ims-graph.yml` was created or
     updated.
   - Remind them they still need to implement the actual graph
     analysis step that produces `ims_graph.json` (e.g. by editing the
     "Build IMS graph JSON" step in the workflow).

### Environment & Assumptions for `EnableIMSGraph`

- The IMS repo (containing `templates/github/ims-graph-workflow.yml`)
  is available on the same machine and readable.
- The current project is a GitHub-backed repo where `.github/workflows`
  is an appropriate place to add workflows.
- The user has appropriate permissions to push workflow changes.

---

described above.
