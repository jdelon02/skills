#!/usr/bin/env python
"""Build a simple IMS graph JSON for a Python codebase.

- Walks the repo (assumes this script lives in `.github/scripts/` under the repo).
- Finds all `.py` files (excluding common virtualenv/hidden dirs).
- For each file, records:
  - `symbols`: top-level functions and classes (and their methods).
  - `calls`: function/method call edges discovered via `ast.Call`.

Output JSON format (to stdout):

[
  {
    "file_path": "app/main.py",
    "symbols": [
      {"name": "store_memory", "kind": "function"},
      {"name": "SessionState", "kind": "class"}
    ],
    "calls": [
      {"caller": "store_memory", "callee": "embed_text"}
    ]
  },
  ...
]
"""

from __future__ import annotations

import ast
import json
import os
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class SymbolDef:
  name: str  # e.g. "store_memory" or "SessionState.__init__"
  kind: str  # "function" | "class" | "method"


@dataclass
class CallEdge:
  caller: str  # symbol name as above
  callee: str  # best-effort name, e.g. "embed_text" or "qdrant_client.upsert"


@dataclass
class FileGraph:
  file_path: str  # repo-relative
  symbols: List[SymbolDef]
  calls: List[CallEdge]


class CallGraphVisitor(ast.NodeVisitor):
  """AST visitor that collects symbol definitions and call edges for one file."""

  def __init__(self) -> None:
    self.symbols: List[SymbolDef] = []
    self.calls: List[CallEdge] = []
    self._symbol_stack: List[str] = []  # e.g. ["store_memory"] or ["MyClass", "save"]
    self._class_stack: List[str] = []

  def _current_symbol_name(self) -> Optional[str]:
    if not self._symbol_stack:
      return None
    if len(self._symbol_stack) == 1:
      return self._symbol_stack[0]
    return ".".join(self._symbol_stack)

  @staticmethod
  def _call_target_name(node: ast.Call) -> str:
    """Best-effort callee name extraction."""
    func = node.func
    if isinstance(func, ast.Name):
      return func.id
    if isinstance(func, ast.Attribute):
      parts: List[str] = []
      while isinstance(func, ast.Attribute):
        parts.append(func.attr)
        func = func.value
      if isinstance(func, ast.Name):
        parts.append(func.id)
        parts.reverse()
        return ".".join(parts)
    return "<unknown>"

  def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
    if self._class_stack:
      kind = "method"
      symbol_name = f"{self._class_stack[-1]}.{node.name}"
      self._symbol_stack.append(symbol_name)
    else:
      kind = "function"
      symbol_name = node.name
      self._symbol_stack.append(symbol_name)

    self.symbols.append(SymbolDef(name=symbol_name, kind=kind))
    self.generic_visit(node)
    self._symbol_stack.pop()

  def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> Any:  # noqa: D401
    return self.visit_FunctionDef(node)  # type: ignore[arg-type]

  def visit_ClassDef(self, node: ast.ClassDef) -> Any:
    self.symbols.append(SymbolDef(name=node.name, kind="class"))
    self._class_stack.append(node.name)
    self.generic_visit(node)
    self._class_stack.pop()

  def visit_Call(self, node: ast.Call) -> Any:
    caller = self._current_symbol_name()
    if caller:
      callee = self._call_target_name(node)
      self.calls.append(CallEdge(caller=caller, callee=callee))
    self.generic_visit(node)


EXCLUDE_DIRS = {".git", ".venv", "venv", ".mypy_cache", ".pytest_cache", "__pycache__"}


def iter_python_files(root: Path) -> List[Path]:
  paths: List[Path] = []
  for dirpath, dirnames, filenames in os.walk(root):
    dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
    for fname in filenames:
      if fname.endswith(".py"):
        paths.append(Path(dirpath) / fname)
  return paths


def build_file_graph(py_path: Path, repo_root: Path) -> Optional[FileGraph]:
  try:
    text = py_path.read_text(encoding="utf-8")
  except Exception:
    return None

  try:
    tree = ast.parse(text, filename=str(py_path))
  except SyntaxError:
    return None

  visitor = CallGraphVisitor()
  visitor.visit(tree)

  rel = py_path.relative_to(repo_root)
  return FileGraph(
    file_path=str(rel),
    symbols=visitor.symbols,
    calls=visitor.calls,
  )


def main() -> None:
  # .github/scripts/build_graph.py -> repo root is two levels up
  repo_root = Path(__file__).resolve().parents[2]
  graphs: List[Dict[str, Any]] = []

  for py_file in iter_python_files(repo_root):
    fg = build_file_graph(py_file, repo_root)
    if not fg:
      continue
    graphs.append(
      {
        "file_path": fg.file_path,
        "symbols": [asdict(s) for s in fg.symbols],
        "calls": [asdict(c) for c in fg.calls],
      }
    )

  json.dump(graphs, sys.stdout, indent=2)


if __name__ == "__main__":
  main()
