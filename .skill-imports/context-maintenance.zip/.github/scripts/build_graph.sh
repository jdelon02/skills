#!/usr/bin/env bash
set -euo pipefail

# language-aware IMS graph builder wrapper
#
# Assumes this script will live in `.github/scripts/` under the repo root.
# It will:
# - Detect common language/structure hints
# - Call the appropriate graph builder
# - Write ims_graph.json in the repo root

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${SCRIPT_DIR%/.github/scripts}"

cd "$REPO_ROOT"

echo "[IMS] Detecting project language for graph build..." >&2

if [ -f composer.json ] || find . -name '*.php' -print -quit | grep -q .; then
  echo "[IMS] Detected PHP project (composer.json or .php files found)" >&2
  if [ -x .github/scripts/build_graph_php.php ]; then
    php .github/scripts/build_graph_php.php > ims_graph.json
  else
    echo "[IMS] WARNING: scripts/build_graph_php.php not found; emitting empty graph" >&2
    echo '[]' > ims_graph.json
  fi
elif find . -name '*.py' -print -quit | grep -q .; then
  echo "[IMS] Detected Python project (.py files found)" >&2
  if [ -x .github/scripts/build_graph.py ]; then
    python .github/scripts/build_graph.py > ims_graph.json
  else
    echo "[IMS] WARNING: scripts/build_graph.py not found; emitting empty graph" >&2
    echo '[]' > ims_graph.json
  fi
else
  echo "[IMS] No recognized language; emitting empty graph" >&2
  echo '[]' > ims_graph.json
fi

ls -lh ims_graph.json >&2
