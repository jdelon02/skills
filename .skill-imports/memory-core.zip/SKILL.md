---
name: memory-core
description: |
  IMS long-term memory store + semantic retrieval for project-scoped decisions/issues/notes/facts (Postgres + Qdrant).
  Use to store durable learnings (`store_memory`) and recall prior context before planning/debugging (`find_memories`).
license: Proprietary
compatibility: Requires IMS backend connectivity (Postgres + Qdrant) and embedding generation; read/write memory data.
metadata:
  user_invocable: true
  phase: 1
  operations: ["store_memory", "find_memories"]
  memory_kinds: ["decision", "issue", "note", "fact"]
  keywords: ["store_memory", "find_memories", "semantic search", "qdrant", "postgres", "decisions", "issues"]
allowed-tools: read_mcp_resource call_mcp_tool
---

# memory-core Skill

Long-term, project-scoped memory service. This skill stores and retrieves
structured memories for a given project, with Qdrant used for semantic
ranking and Postgres as the source of truth.

---

## Identity & Scoping

- `project_id` – typically `basename($PWD)` of the current repo.
- Optional (future extensions):
  - `user_id` – logical/OS user.
  - `agent_id` – agent role (planner, implementer, debugger, etc.).

All memory operations MUST include `project_id`. Results are always scoped to
a single project.

---

## Data Model (Conceptual)

A **memory** has at least:

- `id` (UUID)
- `project_id` (string)
- `kind` (string) – e.g. `"decision"`, `"issue"`, `"note"`, `"fact"`.
- `text` (string) – the main content.
- `tags` (list of strings, optional)
- `importance` (float, optional)

Implementation details:

- Stored in Postgres (`memories` table).
- Embeddings stored in Qdrant collection `ims_memories` with payload:
  - `memory_id`, `project_id`, `kind`, `tags`.

---

## Skill Operation: store_memory
Store a new memory for a given project.

**Enhanced with ontology graph integration:** When `kind="decision"` or `kind="issue"`,
the backend automatically creates corresponding graph nodes (Decision or Bug)
in the knowledge graph, enabling relationship tracking and impact analysis.

### Request

```json
{
  "project_id": "my-project",
  "text": "We decided to use connection pooling with max 10 connections per worker.",
  "kind": "decision",
  "tags": ["db", "pooling"],
  "importance": 0.8
}
```

Fields:

- `project_id` (string, required)
- `text` (string, required)
- `kind` (string, required) - See "Graph Integration" below for graph node behavior
- `tags` (array of strings, optional)
- `importance` (number, optional)

### Behavior

- Ensures a `projects` row exists for `project_id` (creates if missing).
- Inserts a `memories` row in Postgres with a new UUID `id`.
- Computes an embedding for `text`.
- Upserts a point into Qdrant `ims_memories` with:
  - `id = memory_id`
  - `vector = embedding(text)`
  - payload `{ "project_id", "kind", "tags" }`.
- **Graph Integration:** If `kind="decision"` or `kind="issue"`, also creates a graph node (see below).

### Response

```json
{
  "id": "UUID-string",
  "project_id": "my-project",
  "text": "We decided to use connection pooling with max 10 connections per worker.",
  "kind": "decision",
  "tags": ["db", "pooling"],
  "importance": 0.8
}
```

---

## Graph Integration (Ontology)

When storing memories of certain kinds, the backend automatically creates
corresponding graph nodes for relationship tracking and impact analysis:

**Automatic Graph Node Creation:**

- `kind="decision"` → Creates Decision node in Neo4j + memory in Postgres + embedding in Qdrant
- `kind="issue"` → Creates Bug node in Neo4j + memory in Postgres + embedding in Qdrant
- `kind="note"` or `kind="fact"` → Creates memory in Postgres + embedding in Qdrant only (no graph node)

**Why Graph Nodes?**

Graph nodes enable:
- Tracking which components are affected by decisions (via AFFECTS relationships)
- Analyzing what bugs block which features (via BLOCKS relationships)
- Detecting architectural drift (via SUPERSEDES relationships between decisions)
- Building organizational knowledge graphs for impact analysis
- Querying relationships ("show all decisions affecting the auth component")

**Example: Decision with Graph Node**

```python
ims.memory_core.store_memory(
    project_id="my-project",
    text="Use Redis for session storage keyed by (project, user, agent, task)",
    kind="decision",
    tags=["architecture", "sessions", "redis"],
    importance=0.9
)
# Creates:
# 1. Memory record in Postgres (retrievable via find_memories)
# 2. Embedding in Qdrant (for semantic search)
# 3. Decision node in Neo4j (for graph queries and impact analysis)
```

**Example: Issue with Graph Node**

```python
ims.memory_core.store_memory(
    project_id="my-project",
    text="Auth timeout bug: Sessions expire after 1 hour instead of 24. Fixed by updating SESSION_TTL in config/redis.py",
    kind="issue",
    tags=["bug", "auth", "sessions"],
    importance=0.7
)
# Creates:
# 1. Memory record in Postgres (retrievable via find_memories)
# 2. Embedding in Qdrant (for semantic search)
# 3. Bug node in Neo4j (can link to affected Features/Components)
```

**Example: Fact without Graph Node**

```python
ims.memory_core.store_memory(
    project_id="my-project",
    text="Redis runs on localhost:6379 in development",
    kind="fact",
    tags=["config", "redis"]
)
# Creates:
# 1. Memory record in Postgres (retrievable via find_memories)
# 2. Embedding in Qdrant (for semantic search)
# (No graph node - facts are for retrieval only, not relationship tracking)
```

**When to Use Which Kind:**

- Use `kind="decision"` for architectural choices, technical decisions with rationale
- Use `kind="issue"` for bug fixes (symptoms + root cause + solution)
- Use `kind="fact"` for stable configurations, API endpoints, feature flags
- Use `kind="note"` for general observations that don't fit other categories

**Advanced Graph Operations:**

For advanced graph operations beyond automatic node creation (creating Features,
Components, analyzing relationships, detecting drift), see the `graph-rag` skill.

---

## Skill Operation: find_memories (search_memories)

Search memories for a project using semantic similarity (Qdrant) plus lookup
in Postgres.

**Note**: This operation is also referred to as `search_memories` in the backend API (`POST /memories/search`). The MCP tool name is `find_memories` but both names refer to the same operation.

### Request

```json
{
  "project_id": "my-project",
  "query": "database connection pooling decision",
  "kinds": ["decision"],
  "tags": ["db"],
  "limit": 10
}
```

Fields:

- `project_id` (string, required)
- `query` (string, required)
- `kinds` (array of strings, optional) – restrict by `kind`.
- `tags` (array of strings, optional) – restrict by tags (implementation-defined).
- `limit` (integer, optional, default 10).

### Behavior

1. Embed `query` to a vector.
2. Query Qdrant collection `ims_memories` with a filter on `project_id`
   (and optionally `kind`/`tags` when implemented).
3. Take the top hits and fetch full memory rows from Postgres by `id`.
4. Return results ordered by Qdrant similarity.

### Response

```json
{
  "results": [
    {
      "id": "UUID-string",
      "project_id": "my-project",
      "text": "We decided to use connection pooling with max 10 connections per worker.",
      "kind": "decision",
      "tags": ["db", "pooling"],
      "importance": 0.8
    }
  ]
}
```

---

## Capability Endpoint

The backend exposes `GET /capabilities/memory-core` which returns structured documentation about:
- Available operations (store_memory, search_memories/find_memories)
- Memory kinds (decision, issue, note, fact)
- Required and optional parameters
- Usage best practices and examples

This endpoint is used by hooks to inject usage documentation into agent context at appropriate times.

---

## Hook Integration

**PreToolUse Automation**: Before Edit/Write operations on code files, the PreToolUse hook automatically:
1. Calls `search_memories` (via `/memories/search`) to find relevant past decisions, issues, and facts
2. Fetches memory-core capabilities from `/capabilities/memory-core`
3. Injects both search results and usage documentation into agent context

This helps agents learn from past work and avoid repeating mistakes.

**PostToolUse Automation**: After file Edit/Write operations, the PostToolUse hook:
1. Searches for related memories using `search_memories`
2. Fetches memory-core capabilities
3. Suggests storing the change in memory-core with:
   - Related past work context
   - Suggested memory kind and tags
   - Complete usage documentation

This creates a learning loop where agents see memory-core usage docs exactly when they should document their changes.

Agents can still call memory-core operations directly at any time for manual memory management.

---

## Future Memory Kinds (Planned)

The following memory kinds are planned for self-improving agent capabilities:

- `correction` - User corrections of agent behavior (e.g., "Actually, use X pattern instead of Y")
- `reflection` - Agent self-evaluation and lessons learned from task execution
- `pattern` - Confirmed behavioral patterns (promoted from corrections with 3+ uses)
- `lesson` - Improvements learned from reflections and applied to future work

These kinds are **not yet available** but are reserved for future IMS enhancements.
When implemented, they will integrate with the self-improving workflow in the
`graph-rag` skill (Correction → Pattern promotion).

---

## Recommended Usage Pattern

1. **After important events**, call the `memory-core` skill/client
   (or `IMSClient().memory_core.store_memory(...)`):
   - Architecture decisions.
   - Bug + fix summaries.
   - Key configuration facts or gotchas.

2. **Before making new decisions or debugging**, call
   `memory-core.find_memories(...)`:
   - Use a descriptive `query` like:
     - `"previous auth token expiry decisions"`
     - `"past issues with D1 migrations"`.

3. Prefer reusing existing memories over re-deriving from scratch. This skill
   is the long-term project brain; `session-memory` (Phase 2) handles
   short-term task progress.

### Example (Python, using IMSClient wrapper)

```python
from app.ims_client import IMSClient

ims = IMSClient()

# Store a decision
ims.memory_core.store_memory(
    text="We store SessionState in Redis keyed by project/user/agent/task.",
    kind="decision",
    tags=["session", "redis"],
)

# Find prior decisions
results = ims.memory_core.find_memories(
    query="SessionState Redis keying decision",
    kinds=["decision"],
)
```
