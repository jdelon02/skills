#!/usr/bin/env python3
"""
Initialize a comprehensive system design specification folder structure.

Usage:
    python init_spec.py <system-name> [--path <output-directory>]

Example:
    python init_spec.py chat-application --path ./specs
"""

import argparse
from pathlib import Path
from datetime import datetime


SPEC_STRUCTURE = {
    "README.md": """# {system_name} - System Design Specification

**Project**: {system_name}
**Created**: {date}
**Last Updated**: {date}

## Document Overview

This directory contains the complete system design specification for {system_name}.

## Structure

- `01-overview.md` - Executive summary and system overview
- `02-requirements.md` - Functional and non-functional requirements
- `03-architecture.md` - High-level architecture and design decisions
- `04-data-model.md` - Database schema and data modeling
- `05-api-design.md` - API specifications and contracts
- `06-scalability.md` - Scalability strategy and performance considerations
- `07-security.md` - Security design and threat modeling
- `08-monitoring.md` - Observability, logging, and alerting
- `09-deployment.md` - Deployment strategy and infrastructure
- `diagrams/` - Architecture diagrams and visualizations

## Status

🔴 Draft | 🟡 In Review | 🟢 Approved

Current Status: 🔴 Draft
""",

    "01-overview.md": """# System Overview

## Executive Summary

Brief description of the system and its primary purpose.

## Problem Statement

What problem does this system solve? Who are the users?

## Goals and Objectives

### Primary Goals
- Goal 1
- Goal 2
- Goal 3

### Success Metrics
- Metric 1: Target value
- Metric 2: Target value
- Metric 3: Target value

## Scope

### In Scope
- Feature 1
- Feature 2
- Feature 3

### Out of Scope
- What we explicitly won't build
- Future considerations

## Key Stakeholders

| Role | Name | Responsibilities |
|------|------|------------------|
| Product Owner | TBD | Define requirements |
| Tech Lead | TBD | Architecture decisions |
| DevOps Lead | TBD | Infrastructure |

## High-Level Timeline

| Phase | Duration | Deliverables |
|-------|----------|--------------|
| Design | TBD | Architecture docs |
| Development | TBD | MVP |
| Testing | TBD | QA sign-off |
| Deployment | TBD | Production launch |
""",

    "02-requirements.md": """# Requirements

## Functional Requirements

### Core Features

#### Feature 1: [Feature Name]
**Description**: What the feature does
**User Story**: As a [user type], I want to [action] so that [benefit]
**Acceptance Criteria**:
- Criterion 1
- Criterion 2
- Criterion 3

#### Feature 2: [Feature Name]
**Description**: What the feature does
**User Story**: As a [user type], I want to [action] so that [benefit]
**Acceptance Criteria**:
- Criterion 1
- Criterion 2

## Non-Functional Requirements

### Performance
- **Response Time**: API calls should return within 200ms (p95)
- **Throughput**: System should handle X requests/second
- **Concurrent Users**: Support Y concurrent users

### Scalability
- **Horizontal Scaling**: System must scale horizontally
- **Growth Projection**: Support Z% growth year-over-year
- **Data Volume**: Handle X GB/TB of data

### Availability
- **Uptime**: 99.9% uptime SLA
- **RTO**: Recovery Time Objective of X minutes
- **RPO**: Recovery Point Objective of X minutes

### Security
- **Authentication**: [e.g., OAuth 2.0, JWT]
- **Authorization**: Role-based access control (RBAC)
- **Encryption**: Data encryption at rest and in transit
- **Compliance**: [e.g., GDPR, HIPAA, SOC 2]

### Reliability
- **Data Durability**: 99.999999999% (11 nines)
- **Fault Tolerance**: Graceful degradation on component failure
- **Disaster Recovery**: Multi-region backup strategy

### Maintainability
- **Code Quality**: Automated testing with >80% coverage
- **Documentation**: Comprehensive API and architecture docs
- **Monitoring**: Full observability stack

### Usability
- **User Interface**: Responsive design, WCAG 2.1 AA compliance
- **API Design**: RESTful, intuitive, well-documented
- **Error Handling**: Clear, actionable error messages

## Constraints

### Technical Constraints
- Must use [specific technology/framework]
- Must integrate with [existing system]
- Must support [browsers/platforms]

### Business Constraints
- Budget: $X
- Timeline: X months
- Team Size: X engineers

### Regulatory Constraints
- Compliance requirements
- Data residency requirements
- Privacy regulations

## Assumptions

- Assumption 1
- Assumption 2
- Assumption 3

## Dependencies

| System/Service | Purpose | SLA | Owner |
|----------------|---------|-----|-------|
| Service A | Auth | 99.9% | Team X |
| Service B | Payments | 99.95% | Team Y |
""",

    "03-architecture.md": """# System Architecture

## Architecture Overview

```mermaid
graph TB
    Client[Client Applications]
    LB[Load Balancer]
    API[API Gateway]
    Auth[Auth Service]
    Service1[Service 1]
    Service2[Service 2]
    Cache[Cache Layer]
    DB[(Database)]
    Queue[Message Queue]

    Client --> LB
    LB --> API
    API --> Auth
    API --> Service1
    API --> Service2
    Service1 --> Cache
    Service1 --> DB
    Service2 --> Queue
    Queue --> Service1
```

## Architecture Style

**Chosen Style**: [e.g., Microservices, Monolith, Event-Driven, Serverless]

**Rationale**: Why this architecture was chosen over alternatives.

## System Components

### 1. Client Layer
**Technologies**: React, React Native, etc.
**Responsibilities**:
- User interface rendering
- Client-side validation
- State management

### 2. API Gateway
**Technology**: [e.g., Kong, AWS API Gateway, nginx]
**Responsibilities**:
- Request routing
- Rate limiting
- API versioning
- Request/response transformation

### 3. Authentication Service
**Technology**: [e.g., Auth0, Keycloak, custom]
**Responsibilities**:
- User authentication
- Token generation/validation
- Session management

### 4. Core Services

#### Service 1: [Name]
**Technology**: [e.g., Node.js, Python, Go]
**Responsibilities**:
- Business logic
- Data access
- Event publishing

#### Service 2: [Name]
**Technology**: [e.g., Node.js, Python, Go]
**Responsibilities**:
- Business logic
- Data access
- Event consumption

### 5. Data Layer
**Primary Database**: [e.g., PostgreSQL, MongoDB]
**Cache**: [e.g., Redis, Memcached]
**Object Storage**: [e.g., S3, GCS]

### 6. Message Queue
**Technology**: [e.g., RabbitMQ, Kafka, SQS]
**Purpose**: Asynchronous processing, event-driven communication

## Design Decisions

### Decision 1: [Title]
**Context**: What problem needed solving
**Options Considered**:
- Option A: Pros and cons
- Option B: Pros and cons
- Option C: Pros and cons

**Decision**: Chosen option and why
**Consequences**: Trade-offs and implications

### Decision 2: [Title]
**Context**: What problem needed solving
**Options Considered**:
- Option A: Pros and cons
- Option B: Pros and cons

**Decision**: Chosen option and why
**Consequences**: Trade-offs and implications

## Communication Patterns

### Synchronous Communication
- **Protocol**: REST/HTTP, gRPC
- **Use Cases**: Real-time queries, user-facing requests
- **Error Handling**: Retry logic, circuit breakers

### Asynchronous Communication
- **Protocol**: Message queue (event-driven)
- **Use Cases**: Background processing, data synchronization
- **Error Handling**: Dead letter queues, retry policies

## Data Flow

### Write Path
1. Client sends request to API Gateway
2. API Gateway authenticates and routes to service
3. Service validates and writes to database
4. Service publishes event to message queue
5. Response returned to client

### Read Path
1. Client sends request to API Gateway
2. API Gateway routes to service
3. Service checks cache
4. If cache miss, query database
5. Update cache and return response

## Failure Modes and Recovery

| Component | Failure Mode | Detection | Recovery Strategy | Impact |
|-----------|--------------|-----------|-------------------|--------|
| API Gateway | Down | Health check | Failover to backup | Total outage |
| Service | Crash | Monitoring | Auto-restart | Partial degradation |
| Database | Down | Connection failure | Failover to replica | Read-only mode |
| Cache | Down | Connection timeout | Direct DB access | Performance degradation |

## Technology Stack

### Frontend
- Framework: [React, Vue, Angular]
- State Management: [Redux, MobX, Context API]
- Build Tool: [Webpack, Vite]

### Backend
- Language: [Node.js, Python, Go, Java]
- Framework: [Express, FastAPI, Gin, Spring Boot]
- API Style: [REST, GraphQL, gRPC]

### Data Storage
- Primary DB: [PostgreSQL, MySQL, MongoDB]
- Cache: [Redis, Memcached]
- Object Storage: [S3, GCS, Azure Blob]

### Infrastructure
- Cloud Provider: [AWS, GCP, Azure]
- Container Orchestration: [Kubernetes, ECS, Cloud Run]
- CI/CD: [GitHub Actions, GitLab CI, Jenkins]

### Observability
- Logging: [ELK, Splunk, CloudWatch]
- Monitoring: [Prometheus, Grafana, Datadog]
- Tracing: [Jaeger, Zipkin, OpenTelemetry]

## Diagrams

See `diagrams/` folder for detailed architecture diagrams:
- `architecture-overview.mmd` - High-level system architecture
- `component-diagram.mmd` - Component relationships
- `deployment-diagram.mmd` - Infrastructure layout
- `sequence-diagrams.mmd` - Key interaction flows
""",

    "04-data-model.md": """# Data Model

## Database Strategy

**Primary Database**: [PostgreSQL, MongoDB, etc.]
**Rationale**: Why this database was chosen

**Sharding Strategy**: [Horizontal, Vertical, None]
**Replication**: [Master-Slave, Multi-Master, None]

## Schema Design

### Entity Relationship Diagram

```mermaid
erDiagram
    USER ||--o{ ORDER : places
    USER {
        uuid id PK
        string email
        string password_hash
        timestamp created_at
        timestamp updated_at
    }
    ORDER ||--|{ ORDER_ITEM : contains
    ORDER {
        uuid id PK
        uuid user_id FK
        decimal total_amount
        string status
        timestamp created_at
    }
    ORDER_ITEM {
        uuid id PK
        uuid order_id FK
        uuid product_id FK
        int quantity
        decimal price
    }
    PRODUCT ||--o{ ORDER_ITEM : "ordered in"
    PRODUCT {
        uuid id PK
        string name
        text description
        decimal price
        int stock_quantity
    }
```

## Table Definitions

### Users Table

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    deleted_at TIMESTAMP,

    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
);
```

**Columns**:
- `id`: Unique identifier (UUID for distributed systems)
- `email`: User's email address (unique, indexed for login)
- `password_hash`: Bcrypt hashed password
- `created_at`: Account creation timestamp
- `updated_at`: Last modification timestamp
- `deleted_at`: Soft delete timestamp (NULL if active)

**Indexes**:
- `idx_email`: Fast email lookups for authentication
- `idx_created_at`: Analytics queries on user growth

**Relationships**:
- One-to-many with Orders

### Orders Table

```sql
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),

    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);
```

**Columns**:
- `id`: Unique order identifier
- `user_id`: Foreign key to users table
- `total_amount`: Total order value
- `status`: Order status (pending, confirmed, shipped, delivered, cancelled)
- `created_at`: Order creation time
- `updated_at`: Last status update time

**Indexes**:
- `idx_user_id`: Fast user order lookups
- `idx_status`: Order filtering by status
- `idx_created_at`: Time-based queries

### Products Table

```sql
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    category_id UUID REFERENCES categories(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),

    INDEX idx_category_id (category_id),
    INDEX idx_name (name)
);
```

## Data Access Patterns

### Common Queries

#### Get User Orders
```sql
SELECT o.*, oi.*, p.*
FROM orders o
JOIN order_items oi ON o.id = oi.order_id
JOIN products p ON oi.product_id = p.id
WHERE o.user_id = ?
ORDER BY o.created_at DESC
LIMIT 20;
```

**Performance**: Uses `idx_user_id` index, expected query time <50ms

#### Product Search
```sql
SELECT * FROM products
WHERE name ILIKE ?
  AND stock_quantity > 0
ORDER BY created_at DESC
LIMIT 20;
```

**Performance**: Full-text search index recommended for production

## Caching Strategy

### Cache Keys
- `user:{user_id}` - User profile data (TTL: 1 hour)
- `product:{product_id}` - Product details (TTL: 10 minutes)
- `orders:user:{user_id}` - User's recent orders (TTL: 5 minutes)

### Cache Invalidation
- **Write-through**: Update cache on database write
- **TTL-based**: Automatic expiration
- **Event-based**: Invalidate on specific events

## Data Partitioning

### Sharding Strategy
**Method**: Hash-based sharding on user_id
**Shard Count**: 16 shards initially
**Shard Key**: user_id

### Partition Scheme
- Users: Partitioned by created_at (monthly partitions)
- Orders: Partitioned by created_at (weekly partitions)
- Logs: Time-series partitioning (daily)

## Data Migration Strategy

### Version Control
All schema changes tracked in migration files:
```
migrations/
  001_create_users_table.sql
  002_create_orders_table.sql
  003_add_user_email_index.sql
```

### Rollback Plan
Each migration includes:
- Forward migration (UP)
- Rollback migration (DOWN)
- Data migration scripts (if needed)

## Backup and Recovery

### Backup Strategy
- **Frequency**: Continuous WAL archiving + daily full backups
- **Retention**: 30 days point-in-time recovery
- **Storage**: S3 with cross-region replication
- **Testing**: Monthly recovery drills

### Disaster Recovery
- **RPO**: 5 minutes (WAL-based)
- **RTO**: 30 minutes (automated failover)
- **Replica Strategy**: Synchronous replica in same region, async in DR region
""",

    "05-api-design.md": """# API Design

## API Style

**Style**: REST
**Alternative Considered**: GraphQL, gRPC

**Rationale**: REST chosen for simplicity and broad client support

## API Versioning

**Strategy**: URL-based versioning
**Format**: `/api/v1/resource`

**Deprecation Policy**:
- New version announced 6 months before old version deprecation
- Old version supported for 12 months after new version release

## Base URL

**Production**: `https://api.example.com`
**Staging**: `https://api-staging.example.com`
**Development**: `http://localhost:3000/api`

## Authentication

**Method**: JWT (JSON Web Tokens)
**Token Lifetime**: 15 minutes (access token), 7 days (refresh token)
**Header Format**: `Authorization: Bearer <token>`

### Authentication Flow

```mermaid
sequenceDiagram
    Client->>API: POST /auth/login
    API->>API: Validate credentials
    API-->>Client: Access token + Refresh token
    Client->>API: GET /protected (with access token)
    API-->>Client: Protected resource
    Note over Client,API: Access token expires
    Client->>API: POST /auth/refresh (with refresh token)
    API-->>Client: New access token
```

## API Endpoints

### Authentication

#### POST /api/v1/auth/register
Register a new user account.

**Request**:
```json
{
  "email": "user@example.com",
  "password": "SecureP@ssw0rd",
  "first_name": "John",
  "last_name": "Doe"
}
```

**Response** (201 Created):
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "created_at": "2024-01-15T10:30:00Z"
}
```

**Errors**:
- `400`: Invalid input (e.g., weak password, invalid email)
- `409`: Email already exists

---

#### POST /api/v1/auth/login
Authenticate user and receive tokens.

**Request**:
```json
{
  "email": "user@example.com",
  "password": "SecureP@ssw0rd"
}
```

**Response** (200 OK):
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "Bearer",
  "expires_in": 900
}
```

**Errors**:
- `401`: Invalid credentials
- `429`: Too many login attempts

---

### Users

#### GET /api/v1/users/me
Get current user profile.

**Headers**: `Authorization: Bearer <token>`

**Response** (200 OK):
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:30:00Z"
}
```

**Errors**:
- `401`: Unauthorized (invalid/expired token)

---

#### PATCH /api/v1/users/me
Update current user profile.

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "first_name": "Jane",
  "last_name": "Smith"
}
```

**Response** (200 OK):
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "email": "user@example.com",
  "first_name": "Jane",
  "last_name": "Smith",
  "updated_at": "2024-01-15T11:45:00Z"
}
```

**Errors**:
- `401`: Unauthorized
- `400`: Invalid input

---

### Orders

#### GET /api/v1/orders
List user's orders with pagination.

**Headers**: `Authorization: Bearer <token>`

**Query Parameters**:
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 20, max: 100)
- `status`: Filter by status (optional)
- `sort`: Sort field (default: created_at)
- `order`: Sort order (asc/desc, default: desc)

**Request**: `GET /api/v1/orders?page=1&limit=20&status=confirmed`

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": "660e8400-e29b-41d4-a716-446655440000",
      "user_id": "550e8400-e29b-41d4-a716-446655440000",
      "total_amount": 99.99,
      "status": "confirmed",
      "items": [
        {
          "product_id": "770e8400-e29b-41d4-a716-446655440000",
          "product_name": "Widget",
          "quantity": 2,
          "price": 49.99
        }
      ],
      "created_at": "2024-01-15T12:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 45,
    "total_pages": 3
  }
}
```

---

#### POST /api/v1/orders
Create a new order.

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "items": [
    {
      "product_id": "770e8400-e29b-41d4-a716-446655440000",
      "quantity": 2
    },
    {
      "product_id": "880e8400-e29b-41d4-a716-446655440000",
      "quantity": 1
    }
  ]
}
```

**Response** (201 Created):
```json
{
  "id": "660e8400-e29b-41d4-a716-446655440000",
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "total_amount": 149.97,
  "status": "pending",
  "items": [
    {
      "product_id": "770e8400-e29b-41d4-a716-446655440000",
      "quantity": 2,
      "price": 49.99
    },
    {
      "product_id": "880e8400-e29b-41d4-a716-446655440000",
      "quantity": 1,
      "price": 49.99
    }
  ],
  "created_at": "2024-01-15T14:30:00Z"
}
```

**Errors**:
- `400`: Invalid product IDs or insufficient stock
- `401`: Unauthorized

---

### Products

#### GET /api/v1/products
List products with search and filtering.

**Query Parameters**:
- `page`: Page number
- `limit`: Items per page
- `search`: Text search in name/description
- `category`: Filter by category ID
- `min_price`: Minimum price filter
- `max_price`: Maximum price filter

**Request**: `GET /api/v1/products?search=widget&category=electronics&page=1`

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": "770e8400-e29b-41d4-a716-446655440000",
      "name": "Super Widget",
      "description": "An amazing widget",
      "price": 49.99,
      "stock_quantity": 100,
      "category": {
        "id": "990e8400-e29b-41d4-a716-446655440000",
        "name": "Electronics"
      },
      "created_at": "2024-01-10T08:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "total_pages": 8
  }
}
```

---

## Error Handling

### Standard Error Response

All errors follow this format:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input provided",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      }
    ],
    "request_id": "req_123456789"
  }
}
```

### Error Codes

| HTTP Status | Error Code | Description |
|-------------|------------|-------------|
| 400 | VALIDATION_ERROR | Invalid input data |
| 401 | UNAUTHORIZED | Missing or invalid authentication |
| 403 | FORBIDDEN | Insufficient permissions |
| 404 | NOT_FOUND | Resource not found |
| 409 | CONFLICT | Resource conflict (e.g., duplicate) |
| 429 | RATE_LIMIT_EXCEEDED | Too many requests |
| 500 | INTERNAL_ERROR | Server error |
| 503 | SERVICE_UNAVAILABLE | Temporary unavailability |

## Rate Limiting

**Strategy**: Token bucket algorithm
**Limits**:
- Authenticated users: 1000 requests/hour
- Unauthenticated: 100 requests/hour
- Specific endpoints may have stricter limits

**Headers**:
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 987
X-RateLimit-Reset: 1640000000
```

**Response** (429):
```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Rate limit exceeded. Try again in 3600 seconds.",
    "retry_after": 3600
  }
}
```

## API Documentation

**Format**: OpenAPI 3.0 (Swagger)
**Location**: `/api/v1/docs`
**Interactive UI**: Swagger UI at `/api/v1/docs/ui`

## SDK Support

**Official SDKs**:
- JavaScript/TypeScript: npm package `@company/api-client`
- Python: PyPI package `company-api-client`
- Mobile: React Native integration

## Webhook Support

For asynchronous notifications (order status changes, payment confirmations):

**Endpoint Registration**: Via dashboard
**Payload Signing**: HMAC-SHA256
**Retry Policy**: Exponential backoff (5 attempts)

### Webhook Payload Example

```json
{
  "event": "order.confirmed",
  "timestamp": "2024-01-15T15:00:00Z",
  "data": {
    "order_id": "660e8400-e29b-41d4-a716-446655440000",
    "status": "confirmed"
  },
  "signature": "sha256=..."
}
```
""",

    "06-scalability.md": """# Scalability and Performance

## Scalability Requirements

**Current Load**:
- 10,000 requests/second
- 100,000 active users
- 1TB database size

**Projected Growth** (3 years):
- 100,000 requests/second (10x)
- 1,000,000 active users (10x)
- 10TB database size (10x)

## Scalability Strategy

### Horizontal Scaling

**Application Tier**:
- Stateless services enable horizontal scaling
- Auto-scaling based on CPU/memory metrics
- Target: 70% resource utilization

**Database Tier**:
- Read replicas for read-heavy workloads
- Sharding strategy for write scalability
- Connection pooling to prevent resource exhaustion

### Vertical Scaling

Used as a temporary measure, not primary strategy:
- Quick response to unexpected load
- Provides time to implement horizontal scaling
- Cost-effective for databases up to certain size

## Caching Strategy

### Multi-Layer Caching

```mermaid
graph LR
    Client[Client] --> CDN[CDN Cache]
    CDN --> API[API Gateway]
    API --> AppCache[Application Cache]
    AppCache --> DBCache[Database Query Cache]
    DBCache --> DB[(Database)]
```

### Cache Layers

#### 1. CDN Cache (CloudFront, Cloudflare)
**Purpose**: Static assets, public content
**TTL**: 24 hours
**Invalidation**: On deployment or manual purge

#### 2. Application Cache (Redis)
**Purpose**: API responses, session data, rate limiting
**TTL**: 5 minutes - 1 hour (varies by data type)
**Eviction Policy**: LRU (Least Recently Used)

**Key Patterns**:
```
user:{user_id}:profile        TTL: 1 hour
product:{product_id}          TTL: 10 minutes
search:results:{hash}         TTL: 5 minutes
session:{session_id}          TTL: 24 hours
ratelimit:{user_id}:{window}  TTL: 1 hour
```

#### 3. Database Query Cache
**Purpose**: Expensive query results
**Strategy**: Application-managed with cache-aside pattern

### Cache Invalidation

**Strategies**:
1. **Time-based (TTL)**: Automatic expiration
2. **Event-based**: Invalidate on data mutation
3. **Pattern-based**: Invalidate all keys matching pattern

**Implementation**:
```python
# Cache-aside pattern
def get_user(user_id):
    # Try cache first
    cached = redis.get(f"user:{user_id}")
    if cached:
        return json.loads(cached)

    # Cache miss - query database
    user = db.query("SELECT * FROM users WHERE id = ?", user_id)

    # Update cache
    redis.setex(f"user:{user_id}", 3600, json.dumps(user))
    return user

# Invalidation on update
def update_user(user_id, data):
    db.query("UPDATE users SET ... WHERE id = ?", user_id)
    redis.delete(f"user:{user_id}")  # Invalidate cache
```

## Load Balancing

### Application Load Balancer

**Type**: Layer 7 (HTTP/HTTPS)
**Algorithm**: Least connections
**Health Checks**: HTTP GET /health every 30s
**Sticky Sessions**: Cookie-based (if needed)

**Configuration**:
- Cross-zone load balancing enabled
- Connection draining: 300s timeout
- Deregistration delay: 30s

### Database Load Balancing

**Read Traffic**: Round-robin across read replicas
**Write Traffic**: Primary instance only
**Connection Pooling**: PgBouncer (transaction mode)

## Database Optimization

### Query Optimization

**Indexing Strategy**:
- All foreign keys indexed
- Compound indexes for common query patterns
- Covering indexes for frequent SELECT queries

**Query Analysis**:
```sql
-- Monitor slow queries
SELECT query, calls, mean_exec_time, max_exec_time
FROM pg_stat_statements
WHERE mean_exec_time > 100
ORDER BY mean_exec_time DESC
LIMIT 20;
```

### Connection Pooling

**Tool**: PgBouncer
**Mode**: Transaction pooling
**Pool Size**: 25 connections per backend instance
**Max Client Connections**: 1000

**Benefits**:
- Reduces database connection overhead
- Prevents connection exhaustion
- Enables higher concurrency

### Partitioning

**Strategy**: Range partitioning on created_at
**Tables**: orders, logs, events
**Partition Size**: Weekly partitions
**Retention**: Automatic partition dropping after 90 days

```sql
-- Example partition
CREATE TABLE orders_2024_01_w1 PARTITION OF orders
FOR VALUES FROM ('2024-01-01') TO ('2024-01-08');
```

### Read Replicas

**Configuration**:
- 2 read replicas in same region
- 1 read replica in DR region
- Asynchronous replication (lag target: <1s)

**Read Routing**:
- Eventually consistent reads → replicas
- Strongly consistent reads → primary
- Application-level routing based on query type

## Asynchronous Processing

### Message Queue Architecture

**Tool**: RabbitMQ / Amazon SQS
**Pattern**: Producer-Consumer with dead letter queue

**Use Cases**:
- Email notifications
- Report generation
- Data aggregation
- Third-party API calls

### Background Jobs

**Framework**: Celery (Python) / Bull (Node.js)
**Worker Scaling**: Auto-scale based on queue depth
**Priority Queues**: High, Normal, Low priority

**Example**:
```python
@celery.task(queue='emails', priority=5)
def send_welcome_email(user_id):
    user = get_user(user_id)
    send_email(user.email, 'welcome_template')
```

## CDN Strategy

**Provider**: CloudFront / Cloudflare
**Purpose**:
- Static asset delivery
- API response caching (for public endpoints)
- DDoS protection

**Cached Content**:
- Images, CSS, JavaScript
- Public API responses (product listings)
- Generated thumbnails

**Cache Behavior**:
- Images: 1 year TTL
- API responses: 5 minutes TTL
- Versioned URLs for cache busting

## Auto-Scaling Configuration

### Application Tier

**Metrics**:
- Target CPU utilization: 70%
- Target memory utilization: 75%
- Request count: Scale at 1000 req/sec per instance

**Scaling Policy**:
- Scale up: Add instance when metric >80% for 2 minutes
- Scale down: Remove instance when metric <50% for 5 minutes
- Min instances: 3
- Max instances: 50
- Cooldown: 300s

### Database Tier

**Read Replicas**:
- Auto-scale based on replica lag and CPU
- Min replicas: 2
- Max replicas: 5

**Sharding** (if needed):
- Pre-planned shard addition strategy
- Consistent hashing for data distribution
- Online shard migration tools

## Performance Targets

| Metric | Target | Measurement |
|--------|--------|-------------|
| API Response Time | <200ms (p95) | APM tools |
| Page Load Time | <2s (p95) | RUM |
| Database Query Time | <50ms (p95) | Query logs |
| Cache Hit Rate | >80% | Redis stats |
| Throughput | 100k req/sec | Load balancer metrics |
| Error Rate | <0.1% | Application logs |

## Load Testing

**Tools**: k6, JMeter, Locust
**Frequency**: Before every major release
**Scenarios**:
1. Baseline: Normal traffic patterns
2. Stress: 2x peak load
3. Spike: Sudden 10x load increase
4. Endurance: Sustained peak load for 24 hours

**Example k6 Script**:
```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  stages: [
    { duration: '5m', target: 100 },   // Ramp up
    { duration: '10m', target: 100 },  // Sustained
    { duration: '5m', target: 0 },     // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<200'],  // 95% of requests <200ms
  },
};

export default function () {
  let response = http.get('https://api.example.com/products');
  check(response, { 'status is 200': (r) => r.status === 200 });
  sleep(1);
}
```

## Capacity Planning

**Current Capacity**:
- Application: 20,000 req/sec
- Database: 10,000 write ops/sec, 50,000 read ops/sec
- Cache: 100,000 ops/sec

**Monitoring**:
- Weekly capacity reviews
- Automated alerts at 70% capacity
- Quarterly growth projections

**Scaling Triggers**:
- When sustained load reaches 70% of capacity
- 3 months before projected capacity limit
- Major feature launches or marketing campaigns
""",

    "07-security.md": """# Security Design

## Security Principles

1. **Defense in Depth**: Multiple layers of security controls
2. **Least Privilege**: Minimal access rights for users and services
3. **Zero Trust**: Never trust, always verify
4. **Security by Design**: Security considerations in every design decision
5. **Fail Secure**: System fails to a secure state

## Threat Model

### Assets to Protect

1. **User Data**: Personal information, credentials, payment data
2. **Business Data**: Orders, transactions, analytics
3. **System Access**: API keys, service credentials, infrastructure access
4. **Intellectual Property**: Source code, algorithms, business logic

### Threat Actors

| Actor | Motivation | Capability | Likelihood |
|-------|------------|------------|------------|
| External Hacker | Financial gain | Medium-High | Medium |
| Insider Threat | Various | High | Low |
| Script Kiddie | Recreation | Low | High |
| Nation State | Espionage | Very High | Very Low |
| Competitor | Business advantage | Medium | Low |

### Attack Vectors

1. **Application Layer**: SQL injection, XSS, CSRF
2. **Authentication**: Credential stuffing, brute force
3. **Infrastructure**: DDoS, server compromise
4. **Social Engineering**: Phishing, pretexting
5. **Supply Chain**: Compromised dependencies

## Authentication & Authorization

### Authentication

**Method**: JWT (JSON Web Tokens)
**Token Storage**: HttpOnly cookies (web), Secure storage (mobile)
**Token Lifetime**:
- Access token: 15 minutes
- Refresh token: 7 days

**Password Requirements**:
- Minimum 12 characters
- Mix of uppercase, lowercase, numbers, special characters
- NIST SP 800-63B compliant
- Hashed with bcrypt (cost factor: 12)

**Multi-Factor Authentication (MFA)**:
- TOTP-based (compatible with Google Authenticator, Authy)
- SMS fallback (less secure, but available)
- Mandatory for admin accounts
- Optional for regular users

### Authorization

**Model**: Role-Based Access Control (RBAC)
**Roles**:
- `admin`: Full system access
- `user`: Standard user permissions
- `support`: Read-only access to user data
- `service`: Internal service-to-service communication

**Permission Matrix**:

| Resource | Admin | User | Support | Service |
|----------|-------|------|---------|---------|
| User Profile | CRUD | RU (own) | R | R |
| Orders | CRUD | CRUD (own) | R | CRUD |
| Products | CRUD | R | R | R |
| System Config | CRUD | - | - | - |

**Implementation**:
```python
@require_permission('orders:write')
def create_order(user, order_data):
    # Only allow users to create orders for themselves
    if order_data.user_id != user.id and not user.has_role('admin'):
        raise PermissionDenied()
    # ... create order
```

## Data Protection

### Encryption at Rest

**Database**: AES-256 encryption
**File Storage**: Server-side encryption (SSE-KMS)
**Backups**: Encrypted before storage
**Key Management**: AWS KMS / HashiCorp Vault

**Sensitive Fields** (additional field-level encryption):
- Credit card numbers (tokenized via Stripe)
- Social Security Numbers
- Health information

### Encryption in Transit

**External Communication**: TLS 1.3
**Internal Communication**: mTLS (mutual TLS) for service-to-service
**Cipher Suites**: Only strong ciphers, forward secrecy enabled

**TLS Configuration**:
```nginx
ssl_protocols TLSv1.3;
ssl_ciphers 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
ssl_prefer_server_ciphers on;
ssl_session_cache shared:SSL:10m;
```

### Data Masking

**Logging**: Sensitive data (passwords, tokens, PII) redacted from logs
**API Responses**: Credit card numbers masked (****-****-****-1234)
**Support Access**: PII masked in support tools

## Input Validation & Sanitization

### Validation Rules

**Server-side Validation** (never trust client):
- Type checking (string, number, email, UUID)
- Range validation (min/max length, value ranges)
- Format validation (regex patterns)
- Business logic validation

**Example**:
```python
from pydantic import BaseModel, EmailStr, constr, validator

class UserRegistration(BaseModel):
    email: EmailStr
    password: constr(min_length=12, max_length=128)
    first_name: constr(min_length=1, max_length=100)

    @validator('password')
    def validate_password_strength(cls, v):
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain uppercase')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain digit')
        return v
```

### SQL Injection Prevention

**Approach**: Parameterized queries / ORM
**Never**: String concatenation for SQL

**Good**:
```python
db.query("SELECT * FROM users WHERE email = ?", [user_email])
```

**Bad**:
```python
db.query(f"SELECT * FROM users WHERE email = '{user_email}'")  # VULNERABLE
```

### XSS Prevention

**Output Encoding**: All user-generated content HTML-escaped
**Content Security Policy**: Strict CSP headers
**Framework**: Use React/Vue automatic escaping

**CSP Header**:
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-{random}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;
```

### CSRF Prevention

**Token-based**: Synchronizer token pattern
**SameSite Cookies**: `SameSite=Strict` for session cookies
**Double Submit**: Cookie + header validation

## API Security

### Rate Limiting

**Purpose**: Prevent abuse, brute force, DDoS
**Implementation**: Token bucket algorithm (Redis-backed)

**Limits**:
- Login attempts: 5 per 15 minutes
- API calls: 1000 per hour (authenticated), 100 per hour (unauthenticated)
- Password reset: 3 per hour

### API Keys

**Format**: Cryptographically random, 32+ characters
**Storage**: Hashed (SHA-256) in database
**Rotation**: Automated 90-day rotation policy
**Scopes**: Granular permissions per API key

### CORS Policy

**Allowed Origins**: Whitelist of approved domains
**Methods**: GET, POST, PUT, DELETE, PATCH
**Headers**: `Authorization`, `Content-Type`
**Credentials**: Allowed for authenticated requests

```javascript
app.use(cors({
  origin: ['https://app.example.com', 'https://admin.example.com'],
  credentials: true,
  maxAge: 3600
}));
```

## Infrastructure Security

### Network Security

**VPC Configuration**:
- Public subnet: Load balancers only
- Private subnet: Application servers
- Isolated subnet: Databases

**Security Groups**:
- Default deny all traffic
- Explicit allow rules only
- Principle of least privilege

**Example Rules**:
```
# Load Balancer Security Group
Inbound: 443 from 0.0.0.0/0 (HTTPS)
Outbound: All to Application SG

# Application Security Group
Inbound: 8080 from Load Balancer SG
Outbound: 5432 to Database SG, 443 to 0.0.0.0/0 (external APIs)

# Database Security Group
Inbound: 5432 from Application SG
Outbound: None
```

### Secrets Management

**Tool**: HashiCorp Vault / AWS Secrets Manager
**Rotation**: Automatic 90-day rotation
**Access**: IAM role-based, no long-lived credentials
**Audit**: All secret access logged

**Never**:
- Hardcode secrets in code
- Commit secrets to version control
- Store secrets in environment variables (use secrets manager)

### Container Security

**Base Images**: Minimal, official images only
**Scanning**: Automated vulnerability scanning (Trivy, Snyk)
**Updates**: Regular base image updates
**Runtime**: Run as non-root user

**Dockerfile Best Practices**:
```dockerfile
FROM node:18-alpine  # Minimal base image
RUN addgroup -g 1001 -S nodejs && adduser -S nodejs -u 1001
USER nodejs  # Run as non-root
COPY --chown=nodejs:nodejs . .
```

## Monitoring & Incident Response

### Security Monitoring

**Logging**:
- Authentication events (success/failure)
- Authorization failures
- API rate limit violations
- Suspicious patterns (SQL injection attempts, XSS)

**SIEM Integration**: Splunk / ELK Stack
**Alerting**: Real-time alerts for critical events

### Anomaly Detection

**Patterns to Detect**:
- Unusual login locations (geolocation-based)
- Multiple failed login attempts
- Large data exports
- Privilege escalation attempts

**Response**: Automatic account lockout, alert security team

### Incident Response Plan

**Severity Levels**:
- **P0**: Data breach, system compromise - Immediate response
- **P1**: Security vulnerability discovered - 24-hour response
- **P2**: Suspicious activity - 1-week investigation

**Response Team**:
- Incident Commander
- Security Engineer
- DevOps Engineer
- Legal/Compliance Representative

**Runbook**: Documented procedures for common incidents

## Compliance

### Regulations

**GDPR**: EU data protection
**CCPA**: California privacy
**SOC 2**: Security controls audit
**PCI DSS**: Payment card data (handled by Stripe)

### Data Retention

**User Data**: Retained until account deletion + 30 days
**Logs**: 90 days retention
**Backups**: 30 days retention
**Right to Deletion**: User can request data deletion (GDPR)

### Audit Trail

**Logged Events**:
- User authentication
- Data modifications
- Admin actions
- API access

**Retention**: 1 year
**Immutability**: Append-only logs, tamper-evident

## Security Testing

### Regular Testing

**Frequency**:
- Automated scanning: Daily (SAST, dependency checks)
- Penetration testing: Quarterly (external firm)
- Security code review: Every PR
- Bug bounty program: Continuous

### Vulnerability Management

**Process**:
1. Identify: Automated scanning + bug reports
2. Assess: CVSS scoring, business impact
3. Remediate: Patching within SLA (Critical: 24h, High: 7d, Medium: 30d)
4. Verify: Confirm fix deployed

**Disclosure Policy**:
- Responsible disclosure program
- 90-day disclosure timeline
- Acknowledgment page for researchers

## Security Checklist

- [ ] All passwords hashed with bcrypt
- [ ] HTTPS enforced (HSTS enabled)
- [ ] SQL parameterized queries only
- [ ] XSS prevention (output encoding)
- [ ] CSRF tokens on state-changing requests
- [ ] Rate limiting on authentication endpoints
- [ ] Secrets in secrets manager (not code)
- [ ] Security headers configured (CSP, X-Frame-Options, etc.)
- [ ] Dependency vulnerability scanning enabled
- [ ] Logging of security events
- [ ] Incident response plan documented
- [ ] Regular security testing scheduled
""",

    "08-monitoring.md": """# Monitoring and Observability

## Observability Pillars

1. **Logs**: Detailed event records
2. **Metrics**: Numerical measurements over time
3. **Traces**: Request flow across services

## Logging Strategy

### Log Levels

| Level | Usage | Examples |
|-------|-------|----------|
| ERROR | Application errors requiring attention | Unhandled exceptions, service failures |
| WARN | Potential issues, degraded state | Retry attempts, deprecated API usage |
| INFO | Important business events | User login, order creation |
| DEBUG | Detailed diagnostic information | Function entry/exit, variable values |

### Log Format

**Standard**: Structured JSON logging

```json
{
  "timestamp": "2024-01-15T10:30:45.123Z",
  "level": "INFO",
  "service": "order-service",
  "trace_id": "550e8400-e29b-41d4-a716-446655440000",
  "span_id": "660e8400-e29b-41d4-a716-446655440000",
  "message": "Order created successfully",
  "context": {
    "user_id": "user_123",
    "order_id": "order_456",
    "total_amount": 99.99
  }
}
```

### What to Log

**Always Log**:
- Request start/end (with duration)
- Authentication events (success/failure)
- Authorization failures
- External API calls (with latency)
- Database queries (slow queries >100ms)
- Errors and exceptions
- Business-critical events

**Never Log**:
- Passwords or credentials
- Credit card numbers (except last 4 digits)
- Personal health information
- Full API keys or tokens

### Log Aggregation

**Tool**: ELK Stack (Elasticsearch, Logstash, Kibana) / Splunk / CloudWatch

**Architecture**:
```
Application → Fluentd/Filebeat → Logstash → Elasticsearch → Kibana
```

**Retention**:
- Hot storage: 7 days (fast search)
- Warm storage: 30 days (slower search)
- Cold storage: 90 days (archive)

### Example Queries

**Find failed logins**:
```
level:ERROR AND service:auth-service AND message:"login failed"
```

**Find slow API requests**:
```
service:api-gateway AND duration:>1000
```

## Metrics and Monitoring

### Key Metrics

#### Golden Signals (SRE)

1. **Latency**: How long requests take
2. **Traffic**: How many requests received
3. **Errors**: Rate of failed requests
4. **Saturation**: How "full" the service is

#### Application Metrics

**API Metrics**:
- Request rate (req/sec)
- Response time (p50, p95, p99)
- Error rate (%)
- Status code distribution

**Business Metrics**:
- Orders created per minute
- User registrations per hour
- Revenue per hour
- Active users (real-time)

**Infrastructure Metrics**:
- CPU utilization (%)
- Memory utilization (%)
- Disk I/O (MB/sec)
- Network throughput (Mbps)

**Database Metrics**:
- Connection pool usage
- Query latency (ms)
- Slow query count
- Replication lag (seconds)

**Cache Metrics**:
- Hit rate (%)
- Miss rate (%)
- Eviction rate
- Memory usage

### Metrics Collection

**Tool**: Prometheus + Grafana
**Scrape Interval**: 15 seconds
**Retention**: 30 days

**Example Prometheus Metrics**:
```python
from prometheus_client import Counter, Histogram, Gauge

# Counter: Monotonically increasing
http_requests_total = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

# Histogram: Distribution of values
http_request_duration = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration',
    ['method', 'endpoint']
)

# Gauge: Value that can go up or down
active_users = Gauge(
    'active_users',
    'Number of currently active users'
)
```

### Dashboards

**Grafana Dashboards**:

1. **Overview Dashboard**:
   - Request rate (all services)
   - Error rate (all services)
   - P95 latency (all services)
   - Active users
   - Current system health status

2. **Service-Specific Dashboards** (per service):
   - Request rate by endpoint
   - Latency percentiles (p50, p95, p99)
   - Error rate by endpoint
   - Resource utilization (CPU, memory)
   - Dependency health

3. **Infrastructure Dashboard**:
   - Host metrics (CPU, memory, disk, network)
   - Container metrics
   - Database metrics
   - Cache metrics

4. **Business Dashboard**:
   - Orders per hour
   - Revenue per hour
   - User registrations
   - Conversion funnel

## Distributed Tracing

### Purpose

Track a single request as it flows through multiple services, identifying bottlenecks and failures.

### Implementation

**Tool**: Jaeger / Zipkin / OpenTelemetry
**Sampling Rate**: 10% of requests (100% for errors)

### Trace Context Propagation

**Header**: `traceparent` (W3C Trace Context standard)

```
traceparent: 00-550e8400e29b41d4a716446655440000-660e8400e29b41d4-01
             ^^ ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ ^^^^^^^^^^^^^^^^ ^^
             |  |                                 |                |
             |  trace-id                          span-id          sampled
             version
```

**Example Trace**:
```
HTTP Request
├─ API Gateway (50ms)
│  ├─ Auth Service (10ms)
│  ├─ Order Service (35ms)
│  │  ├─ Database Query (20ms)
│  │  └─ Cache Lookup (5ms)
│  └─ Email Service (5ms)
```

### Instrumentation

**Automatic**: Middleware captures HTTP requests/responses
**Manual**: Annotate critical code paths

```python
from opentelemetry import trace

tracer = trace.get_tracer(__name__)

@tracer.start_as_current_span("process_order")
def process_order(order_id):
    span = trace.get_current_span()
    span.set_attribute("order.id", order_id)

    # Processing logic
    with tracer.start_as_current_span("validate_order"):
        validate_order(order_id)

    with tracer.start_as_current_span("charge_payment"):
        charge_payment(order_id)
```

## Alerting

### Alert Philosophy

- **Actionable**: Every alert must require human action
- **High Signal**: Low false positive rate
- **Timely**: Alert before user impact (predictive when possible)
- **Contextualized**: Include enough context to diagnose

### Alert Rules

#### Critical Alerts (Page on-call engineer immediately)

**High Error Rate**:
```yaml
alert: HighErrorRate
expr: (rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m])) > 0.05
for: 2m
severity: critical
description: Error rate is {{ $value }}%, above 5% threshold
```

**Service Down**:
```yaml
alert: ServiceDown
expr: up{job="api-service"} == 0
for: 1m
severity: critical
description: Service {{ $labels.instance }} is down
```

**Database Connection Failure**:
```yaml
alert: DatabaseConnectionFailure
expr: database_connection_errors_total > 10
for: 1m
severity: critical
description: Database connection failures detected
```

#### Warning Alerts (Notify team, investigate during business hours)

**High Latency**:
```yaml
alert: HighLatency
expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 1
for: 5m
severity: warning
description: P95 latency is {{ $value }}s, above 1s threshold
```

**Disk Space Low**:
```yaml
alert: DiskSpaceLow
expr: (node_filesystem_avail_bytes / node_filesystem_size_bytes) < 0.2
for: 10m
severity: warning
description: Disk space below 20% on {{ $labels.instance }}
```

**High CPU Usage**:
```yaml
alert: HighCPUUsage
expr: (100 - (avg by (instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)) > 80
for: 10m
severity: warning
description: CPU usage above 80% on {{ $labels.instance }}
```

### Alert Routing

**Notification Channels**:
- **Critical**: PagerDuty (pages on-call engineer)
- **Warning**: Slack channel + Email
- **Info**: Logged to monitoring dashboard only

**On-Call Rotation**:
- Primary on-call: Immediate page
- Secondary on-call: Escalation after 15 minutes
- Engineering manager: Escalation after 30 minutes

## Health Checks

### Endpoint Design

**GET /health**: Quick liveness check (is service running?)
**GET /health/ready**: Readiness check (is service ready to serve traffic?)

**Liveness Check** (returns 200 if healthy):
```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Readiness Check** (includes dependencies):
```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:00Z",
  "dependencies": {
    "database": "ok",
    "cache": "ok",
    "message_queue": "ok"
  }
}
```

**Degraded State** (returns 503):
```json
{
  "status": "degraded",
  "timestamp": "2024-01-15T10:30:00Z",
  "dependencies": {
    "database": "ok",
    "cache": "error",
    "message_queue": "ok"
  }
}
```

### Health Check Configuration

**Kubernetes**:
```yaml
livenessProbe:
  httpGet:
    path: /health
    port: 8080
  initialDelaySeconds: 30
  periodSeconds: 10

readinessProbe:
  httpGet:
    path: /health/ready
    port: 8080
  initialDelaySeconds: 5
  periodSeconds: 5
```

## SLIs, SLOs, and Error Budgets

### Service Level Indicators (SLIs)

**Availability**:
```
SLI = (successful requests / total requests) * 100
```

**Latency**:
```
SLI = (requests under 200ms / total requests) * 100
```

### Service Level Objectives (SLOs)

| Metric | SLO | Measurement Window |
|--------|-----|-------------------|
| Availability | 99.9% | 30 days |
| Latency (p95) | <200ms | 30 days |
| Error Rate | <0.1% | 30 days |

### Error Budget

**Calculation**:
```
Error Budget = 100% - SLO

For 99.9% availability SLO:
Error Budget = 0.1% = 43.2 minutes of downtime per month
```

**Policy**:
- **>50% budget remaining**: Ship new features freely
- **25-50% budget remaining**: Increase testing, slow down releases
- **<25% budget remaining**: Feature freeze, focus on reliability

## Performance Monitoring

### Application Performance Monitoring (APM)

**Tool**: New Relic / DataDog / Dynatrace

**Tracked Metrics**:
- Transaction traces
- Database query performance
- External service calls
- Error tracking with stack traces
- Real User Monitoring (RUM)

### Real User Monitoring (RUM)

**Client-Side Metrics**:
- Page load time
- First Contentful Paint (FCP)
- Time to Interactive (TTI)
- Cumulative Layout Shift (CLS)

**Tool**: Google Analytics, Sentry Performance

## Incident Management

### Incident Severity Levels

| Severity | Description | Response Time | Example |
|----------|-------------|---------------|---------|
| P0 | Complete outage | Immediate | Database down |
| P1 | Major degradation | <15 minutes | High error rate |
| P2 | Minor degradation | <1 hour | Slow responses |
| P3 | Cosmetic issue | <1 day | UI bug |

### Incident Response Process

1. **Detect**: Automated alert or user report
2. **Triage**: Assess severity, assign incident commander
3. **Mitigate**: Restore service (rollback, failover, etc.)
4. **Communicate**: Update status page, notify stakeholders
5. **Resolve**: Implement permanent fix
6. **Post-Mortem**: Blameless analysis, action items

### Status Page

**Tool**: StatusPage.io / Atlassian Statuspage

**Components**:
- API
- Web Application
- Database
- Background Jobs

**Incident Updates**:
- Investigating
- Identified
- Monitoring
- Resolved

## Monitoring Checklist

- [ ] Structured logging configured (JSON format)
- [ ] Log aggregation system deployed (ELK/Splunk)
- [ ] Metrics collection configured (Prometheus)
- [ ] Dashboards created (Grafana)
- [ ] Distributed tracing implemented (Jaeger)
- [ ] Critical alerts defined and tested
- [ ] Health check endpoints implemented
- [ ] SLOs defined and monitored
- [ ] On-call rotation established
- [ ] Incident response runbook documented
- [ ] Status page configured
- [ ] Post-mortem process established
""",

    "09-deployment.md": """# Deployment Strategy

## Deployment Architecture

### Infrastructure Overview

**Cloud Provider**: AWS / GCP / Azure
**Container Orchestration**: Kubernetes (EKS/GKE/AKS)
**Infrastructure as Code**: Terraform
**Configuration Management**: Helm Charts

### Environments

| Environment | Purpose | Deployment Trigger | Approval |
|-------------|---------|-------------------|----------|
| Development | Local development | Manual | None |
| Staging | Pre-production testing | Merge to `develop` | Automated |
| UAT | User acceptance testing | Manual promotion | QA team |
| Production | Live users | Merge to `main` | Engineering lead |

**Environment Parity**: All environments use identical infrastructure (scaled down for non-prod)

## Deployment Strategy

### Blue-Green Deployment

**Approach**: Maintain two identical production environments (Blue and Green)

**Process**:
1. Blue environment serves production traffic
2. Deploy new version to Green environment
3. Run smoke tests on Green
4. Switch traffic from Blue to Green
5. Keep Blue as rollback option for 24 hours

**Benefits**:
- Zero downtime deployments
- Instant rollback capability
- Full testing before traffic switch

**Implementation** (Kubernetes):
```yaml
# Service switches between blue and green
apiVersion: v1
kind: Service
metadata:
  name: app-service
spec:
  selector:
    app: myapp
    version: green  # Switch this label to change traffic
  ports:
    - port: 80
```

### Canary Deployment

**Approach**: Gradually roll out to subset of users

**Process**:
1. Deploy new version to 5% of instances
2. Monitor error rates, latency for 30 minutes
3. If healthy, increase to 25%
4. Monitor for 30 minutes
5. Increase to 50%, then 100%
6. Rollback at any stage if issues detected

**Benefits**:
- Limited blast radius
- Early issue detection
- Data-driven rollout decisions

**Implementation** (Istio/Traffic Splitting):
```yaml
apiVersion: networking.istio.io/v1beta1
kind: VirtualService
metadata:
  name: app-canary
spec:
  hosts:
    - app-service
  http:
    - match:
        - headers:
            x-canary:
              exact: "true"
      route:
        - destination:
            host: app-service
            subset: v2
    - route:
        - destination:
            host: app-service
            subset: v1
          weight: 95
        - destination:
            host: app-service
            subset: v2
          weight: 5  # Canary traffic
```

## CI/CD Pipeline

### Pipeline Stages

```mermaid
graph LR
    A[Code Commit] --> B[Lint & Format]
    B --> C[Unit Tests]
    C --> D[Build Docker Image]
    D --> E[Integration Tests]
    E --> F[Security Scan]
    F --> G[Push to Registry]
    G --> H{Deploy to Staging}
    H --> I[Smoke Tests]
    I --> J{Manual Approval}
    J -->|Approved| K[Deploy to Production]
    J -->|Rejected| L[Rollback]
```

### Pipeline Configuration

**Tool**: GitHub Actions / GitLab CI / Jenkins

**Example GitHub Actions**:
```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run tests
        run: npm test

      - name: Run linter
        run: npm run lint

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Build Docker image
        run: docker build -t myapp:${{ github.sha }} .

      - name: Security scan
        run: trivy image myapp:${{ github.sha }}

      - name: Push to registry
        run: docker push myapp:${{ github.sha }}

  deploy-staging:
    needs: build
    if: github.ref == 'refs/heads/develop'
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to staging
        run: kubectl set image deployment/app app=myapp:${{ github.sha }}

      - name: Run smoke tests
        run: npm run test:smoke

  deploy-production:
    needs: build
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production  # Requires approval
    steps:
      - name: Deploy to production (canary)
        run: ./scripts/canary-deploy.sh ${{ github.sha }}
```

### Build Artifacts

**Docker Images**:
- Tagged with git commit SHA
- Immutable (never overwrite tags)
- Scanned for vulnerabilities (Trivy, Snyk)
- Stored in private registry (ECR, GCR, ACR)

**Retention Policy**:
- Production images: Keep all (indefinitely)
- Staging images: 30 days
- Development images: 7 days

## Infrastructure as Code

### Terraform Structure

```
infrastructure/
├── modules/
│   ├── vpc/
│   ├── eks/
│   ├── rds/
│   └── redis/
├── environments/
│   ├── staging/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── terraform.tfvars
│   └── production/
│       ├── main.tf
│       ├── variables.tf
│       └── terraform.tfvars
└── README.md
```

**Example VPC Module**:
```hcl
module "vpc" {
  source = "../../modules/vpc"

  environment = var.environment
  vpc_cidr    = "10.0.0.0/16"

  public_subnets  = ["10.0.1.0/24", "10.0.2.0/24"]
  private_subnets = ["10.0.10.0/24", "10.0.11.0/24"]

  enable_nat_gateway = true
  enable_vpn_gateway = false

  tags = {
    Environment = var.environment
    Terraform   = "true"
  }
}
```

### State Management

**Backend**: S3 + DynamoDB (state locking)
**Workspaces**: Separate workspace per environment
**State Encryption**: Enabled

```hcl
terraform {
  backend "s3" {
    bucket         = "myapp-terraform-state"
    key            = "production/terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    dynamodb_table = "terraform-lock"
  }
}
```

## Kubernetes Configuration

### Namespace Strategy

- `production`: Production workloads
- `staging`: Staging workloads
- `monitoring`: Monitoring stack (Prometheus, Grafana)
- `logging`: Logging stack (ELK)

### Deployment Configuration

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app-deployment
  namespace: production
spec:
  replicas: 10
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
  selector:
    matchLabels:
      app: myapp
  template:
    metadata:
      labels:
        app: myapp
        version: v1.2.3
    spec:
      containers:
        - name: app
          image: myapp:abc123
          ports:
            - containerPort: 8080
          env:
            - name: DATABASE_URL
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: url
          resources:
            requests:
              cpu: 100m
              memory: 256Mi
            limits:
              cpu: 500m
              memory: 512Mi
          livenessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 30
            periodSeconds: 10
          readinessProbe:
            httpGet:
              path: /health/ready
              port: 8080
            initialDelaySeconds: 5
            periodSeconds: 5
```

### Helm Charts

**Chart Structure**:
```
charts/myapp/
├── Chart.yaml
├── values.yaml
├── values-staging.yaml
├── values-production.yaml
└── templates/
    ├── deployment.yaml
    ├── service.yaml
    ├── ingress.yaml
    ├── configmap.yaml
    └── secret.yaml
```

**Deployment Command**:
```bash
helm upgrade --install myapp ./charts/myapp \
  --namespace production \
  --values ./charts/myapp/values-production.yaml \
  --set image.tag=abc123
```

## Database Migrations

### Migration Strategy

**Tool**: Flyway / Liquibase / Alembic
**Execution**: Automated in CI/CD pipeline, before app deployment

**Migration Structure**:
```
migrations/
├── V001__create_users_table.sql
├── V002__create_orders_table.sql
├── V003__add_user_email_index.sql
└── V004__add_order_status_column.sql
```

**Safety Rules**:
1. Migrations are immutable (never edit existing migrations)
2. Backward compatible changes only (for zero-downtime)
3. Data migrations tested in staging
4. Large migrations run during maintenance window

**Example Migration**:
```sql
-- V005__add_user_phone_column.sql
-- Add column as nullable first (backward compatible)
ALTER TABLE users ADD COLUMN phone VARCHAR(20);

-- Backfill data in batches
-- (handled by separate script, not in migration)

-- Make column non-null after backfill (future migration)
-- ALTER TABLE users ALTER COLUMN phone SET NOT NULL;
```

## Rollback Procedures

### Automatic Rollback Triggers

**Conditions**:
- Error rate >5% for 2 minutes
- P95 latency >1s for 5 minutes
- Health check failures >50% of instances

**Implementation**:
```bash
#!/bin/bash
# canary-deploy.sh with automatic rollback

NEW_VERSION=$1
CANARY_WEIGHT=5

# Deploy canary
kubectl set image deployment/app app=myapp:$NEW_VERSION

# Monitor for 5 minutes
for i in {1..10}; do
  ERROR_RATE=$(get_error_rate)
  if (( $(echo "$ERROR_RATE > 0.05" | bc -l) )); then
    echo "Error rate too high: $ERROR_RATE, rolling back"
    kubectl rollout undo deployment/app
    exit 1
  fi
  sleep 30
done

# Gradually increase traffic
for WEIGHT in 25 50 100; do
  set_canary_weight $WEIGHT
  sleep 300  # Monitor for 5 minutes
done

echo "Deployment successful"
```

### Manual Rollback

**Kubernetes**:
```bash
# Rollback to previous version
kubectl rollout undo deployment/app

# Rollback to specific revision
kubectl rollout undo deployment/app --to-revision=5

# Check rollout status
kubectl rollout status deployment/app
```

**Database**:
```bash
# Rollback last migration
flyway undo

# Rollback to specific version
flyway migrate -target=V003
```

## Disaster Recovery

### Backup Strategy

**Database Backups**:
- Continuous WAL archiving
- Daily full backups (retained 30 days)
- Weekly full backups (retained 1 year)
- Stored in separate region

**Application State**:
- Kubernetes manifests in Git
- Terraform state in S3 (versioned, encrypted)
- Secrets in Vault (replicated)

### Recovery Procedures

**Database Recovery**:
```bash
# Point-in-time recovery
aws rds restore-db-instance-to-point-in-time \
  --source-db-instance prod-db \
  --target-db-instance prod-db-restored \
  --restore-time 2024-01-15T10:00:00Z
```

**Full Environment Recovery**:
1. Restore infrastructure (Terraform apply)
2. Restore database from backup
3. Deploy application (Helm install)
4. Restore secrets (Vault restore)
5. Verify functionality (smoke tests)

**RTO**: 30 minutes (automated recovery)
**RPO**: 5 minutes (WAL-based)

### Multi-Region Failover

**Setup**:
- Primary region: us-east-1
- DR region: us-west-2
- Async database replication
- DNS failover (Route 53)

**Failover Process**:
1. Detect primary region failure
2. Promote DR database to primary
3. Update DNS to point to DR region
4. Monitor application health

**Failback**:
1. Restore primary region
2. Sync data from DR to primary
3. Switch DNS back to primary
4. DR region returns to standby

## Deployment Checklist

**Pre-Deployment**:
- [ ] Code reviewed and approved
- [ ] Tests passing (unit, integration, e2e)
- [ ] Security scan passed
- [ ] Database migrations tested
- [ ] Rollback plan documented
- [ ] Stakeholders notified

**During Deployment**:
- [ ] Monitor error rates
- [ ] Monitor latency
- [ ] Monitor resource utilization
- [ ] Check health endpoints
- [ ] Verify key user flows

**Post-Deployment**:
- [ ] Smoke tests passed
- [ ] Monitor for 1 hour
- [ ] Update documentation
- [ ] Tag release in Git
- [ ] Announce deployment
- [ ] Archive logs
""",

    "diagrams/.gitkeep": "",
}


def create_directory_structure(base_path: Path, system_name: str, structure: dict, date: str):
    """Create the spec folder structure with template files."""
    spec_folder = base_path / system_name
    spec_folder.mkdir(parents=True, exist_ok=True)

    for filename, content in structure.items():
        file_path = spec_folder / filename

        # Create parent directories if needed (e.g., for diagrams/.gitkeep)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Format content with system name and date
        formatted_content = content.replace('{system_name}', system_name).replace('{date}', date)

        file_path.write_text(formatted_content)
        print(f"✅ Created: {file_path.relative_to(base_path)}")


def main():
    parser = argparse.ArgumentParser(
        description="Initialize a system design specification folder"
    )
    parser.add_argument(
        "system_name",
        help="Name of the system (e.g., 'chat-application')"
    )
    parser.add_argument(
        "--path",
        default="./spec",
        help="Output directory path (default: ./spec)"
    )

    args = parser.parse_args()

    # Clean and format system name
    system_name = args.system_name.strip().lower().replace(" ", "-")
    output_path = Path(args.path)

    # Get current date
    date = datetime.now().strftime("%Y-%m-%d")

    print(f"🚀 Initializing system design spec for: {system_name}")
    print(f"   Location: {output_path.absolute()}/{system_name}\n")

    # Create the structure
    create_directory_structure(output_path, system_name, SPEC_STRUCTURE, date)

    print(f"\n✅ System design spec '{system_name}' initialized successfully!")
    print(f"\nNext steps:")
    print(f"1. cd {output_path}/{system_name}")
    print(f"2. Fill in the template sections with your system design details")
    print(f"3. Add architecture diagrams to the diagrams/ folder")
    print(f"4. Update the README.md status when ready for review")


if __name__ == "__main__":
    main()
