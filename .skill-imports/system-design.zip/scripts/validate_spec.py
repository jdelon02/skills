#!/usr/bin/env python3
"""
Validate the completeness of a system design specification.

Usage:
    python validate_spec.py <path-to-spec-folder>

Example:
    python validate_spec.py ./spec/chat-application
"""

import argparse
import sys
from pathlib import Path
from typing import List

# Required files in a complete spec
REQUIRED_FILES = [
    "README.md",
    "01-overview.md",
    "02-requirements.md",
    "03-architecture.md",
    "04-data-model.md",
    "05-api-design.md",
    "06-scalability.md",
    "07-security.md",
    "08-monitoring.md",
    "09-deployment.md",
]

# Required sections in each file (key markers to check)
REQUIRED_SECTIONS = {
    "README.md": ["Document Overview", "Structure", "Status"],
    "01-overview.md": ["Executive Summary", "Problem Statement", "Goals and Objectives"],
    "02-requirements.md": ["Functional Requirements", "Non-Functional Requirements"],
    "03-architecture.md": ["Architecture Overview", "System Components", "Design Decisions"],
    "04-data-model.md": ["Database Strategy", "Schema Design", "Table Definitions"],
    "05-api-design.md": ["API Style", "Authentication", "API Endpoints"],
    "06-scalability.md": ["Scalability Requirements", "Scalability Strategy", "Caching Strategy"],
    "07-security.md": ["Security Principles", "Threat Model", "Authentication & Authorization"],
    "08-monitoring.md": ["Observability Pillars", "Logging Strategy", "Metrics and Monitoring"],
    "09-deployment.md": ["Deployment Architecture", "Deployment Strategy", "CI/CD Pipeline"],
}

# Placeholder text that should be replaced
PLACEHOLDER_PATTERNS = [
    "TBD",
    "TODO",
    "[Feature Name]",
    "[Name]",
    "[Title]",
    "TODO:",
    "FIXME:",
]


class ValidationResult:
    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.info: List[str] = []

    def add_error(self, message: str):
        self.errors.append(f"❌ ERROR: {message}")

    def add_warning(self, message: str):
        self.warnings.append(f"⚠️  WARNING: {message}")

    def add_info(self, message: str):
        self.info.append(f"ℹ️  INFO: {message}")

    def is_valid(self) -> bool:
        return len(self.errors) == 0

    def print_results(self):
        if self.errors:
            print("\n🔴 Validation Errors:")
            for error in self.errors:
                print(f"  {error}")

        if self.warnings:
            print("\n🟡 Warnings:")
            for warning in self.warnings:
                print(f"  {warning}")

        if self.info:
            print("\n🔵 Information:")
            for info in self.info:
                print(f"  {info}")

        print()
        if self.is_valid():
            print("✅ Validation passed! Your system design spec is complete.")
            return 0
        else:
            print("❌ Validation failed. Please address the errors above.")
            return 1


def check_file_exists(spec_path: Path, filename: str, result: ValidationResult) -> bool:
    """Check if a required file exists."""
    file_path = spec_path / filename
    if not file_path.exists():
        result.add_error(f"Missing required file: {filename}")
        return False
    return True


def check_file_content(spec_path: Path, filename: str, required_sections: List[str], result: ValidationResult):
    """Check if file contains required sections and no placeholders."""
    file_path = spec_path / filename

    if not file_path.exists():
        return

    content = file_path.read_text()

    # Check for required sections
    for section in required_sections:
        if section not in content:
            result.add_warning(f"{filename}: Missing section '{section}'")

    # Check for placeholders
    placeholder_count = 0
    for placeholder in PLACEHOLDER_PATTERNS:
        count = content.count(placeholder)
        placeholder_count += count

    if placeholder_count > 0:
        result.add_warning(f"{filename}: Contains {placeholder_count} placeholder(s) that should be filled in")

    # Check file size (very small files are likely incomplete)
    if len(content) < 500:
        result.add_warning(f"{filename}: File seems very short ({len(content)} characters). Consider adding more details.")


def check_diagrams_folder(spec_path: Path, result: ValidationResult):
    """Check if diagrams folder exists and contains files."""
    diagrams_path = spec_path / "diagrams"

    if not diagrams_path.exists():
        result.add_warning("No diagrams/ folder found. Consider adding architecture diagrams.")
        return

    # List all files (excluding .gitkeep)
    diagram_files = [f for f in diagrams_path.iterdir() if f.is_file() and f.name != ".gitkeep"]

    if len(diagram_files) == 0:
        result.add_info("diagrams/ folder is empty. Consider adding architecture diagrams (Mermaid, PNG, etc.)")
    else:
        result.add_info(f"Found {len(diagram_files)} diagram file(s)")


def check_status(spec_path: Path, result: ValidationResult):
    """Check if status is updated in README."""
    readme_path = spec_path / "README.md"

    if not readme_path.exists():
        return

    content = readme_path.read_text()

    if "🔴 Draft" in content:
        result.add_info("Current status: 🔴 Draft")
    elif "🟡 In Review" in content:
        result.add_info("Current status: 🟡 In Review")
    elif "🟢 Approved" in content:
        result.add_info("Current status: 🟢 Approved")


def validate_spec(spec_path: Path) -> ValidationResult:
    """Validate a system design specification folder."""
    result = ValidationResult()

    if not spec_path.exists():
        result.add_error(f"Spec folder not found: {spec_path}")
        return result

    if not spec_path.is_dir():
        result.add_error(f"Path is not a directory: {spec_path}")
        return result

    print(f"🔍 Validating system design spec: {spec_path.name}\n")

    # Check all required files exist
    for filename in REQUIRED_FILES:
        check_file_exists(spec_path, filename, result)

    # Check file contents
    for filename, required_sections in REQUIRED_SECTIONS.items():
        check_file_content(spec_path, filename, required_sections, result)

    # Check diagrams folder
    check_diagrams_folder(spec_path, result)

    # Check status
    check_status(spec_path, result)

    return result


def main():
    parser = argparse.ArgumentParser(
        description="Validate a system design specification folder"
    )
    parser.add_argument(
        "spec_path",
        help="Path to the system design spec folder"
    )

    args = parser.parse_args()
    spec_path = Path(args.spec_path)

    result = validate_spec(spec_path)
    exit_code = result.print_results()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
