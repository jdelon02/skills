# Architectural Patterns Reference

This reference provides guidance on common architectural patterns for system design. Use this when choosing an architecture style or designing system components.

## Table of Contents

1. [Monolithic Architecture](#monolithic-architecture)
2. [Microservices Architecture](#microservices-architecture)
3. [Serverless Architecture](#serverless-architecture)
4. [Event-Driven Architecture](#event-driven-architecture)
5. [Layered (N-Tier) Architecture](#layered-n-tier-architecture)
6. [Hexagonal Architecture (Ports and Adapters)](#hexagonal-architecture)
7. [CQRS (Command Query Responsibility Segregation)](#cqrs)
8. [Event Sourcing](#event-sourcing)
9. [Service-Oriented Architecture (SOA)](#service-oriented-architecture)
10. [Micro-Frontend Architecture](#micro-frontend-architecture)

---

## Monolithic Architecture

### Description
A single, unified codebase where all components are tightly integrated and deployed as one unit.

### When to Use
- Small to medium-sized applications
- Early-stage startups (MVP development)
- Teams want to move fast with simple deployment
- Limited team size or expertise
- Application doesn't require independent scaling

### Pros
- Simple to develop and deploy
- Easy to test (single codebase)
- Straightforward debugging
- No network latency between components
- ACID transactions across all data

### Cons
- Scaling requires scaling entire application
- Long-term maintenance becomes difficult
- Technology lock-in (one framework/language)
- Deployment risk (all-or-nothing)
- Limited team autonomy

### Example Structure
```
monolith/
├── api/           # API routes
├── services/      # Business logic
├── models/        # Data models
├── controllers/   # Request handlers
└── views/         # Frontend templates
```

---

## Microservices Architecture

### Description
Application decomposed into small, independent services that communicate over network protocols.

### When to Use
- Large, complex applications
- Need independent scaling of components
- Multiple teams working on different features
- Different technology requirements per service
- High availability requirements

### Pros
- Independent deployment and scaling
- Technology diversity (polyglot architecture)
- Fault isolation (one service failure doesn't crash all)
- Team autonomy
- Easier to understand individual services

### Cons
- Increased operational complexity
- Network latency and failures
- Distributed transaction challenges
- Testing complexity
- Requires DevOps maturity

### Design Principles
1. **Single Responsibility**: Each service does one thing well
2. **Bounded Context**: Clear service boundaries (DDD)
3. **Autonomous**: Services are independently deployable
4. **Resilient**: Services handle failures gracefully
5. **Observable**: Comprehensive logging and monitoring

### Communication Patterns

#### Synchronous (Request/Response)
- **REST**: HTTP-based, resource-oriented
- **gRPC**: High-performance RPC with Protocol Buffers
- **GraphQL**: Flexible query language

#### Asynchronous (Event-Driven)
- **Message Queue**: RabbitMQ, SQS
- **Event Bus**: Kafka, EventBridge
- **Pub/Sub**: Google Pub/Sub, SNS

### Example Structure
```
services/
├── user-service/
│   ├── api/
│   ├── database/
│   └── Dockerfile
├── order-service/
│   ├── api/
│   ├── database/
│   └── Dockerfile
└── payment-service/
    ├── api/
    ├── database/
    └── Dockerfile
```

---

## Serverless Architecture

### Description
Application built using managed cloud services and functions that run on-demand without server management.

### When to Use
- Variable or unpredictable traffic
- Event-driven workloads
- Rapid prototyping
- Cost optimization (pay per use)
- Minimal DevOps resources

### Pros
- No server management
- Automatic scaling
- Pay-per-execution pricing
- Fast time to market
- Built-in high availability

### Cons
- Cold start latency
- Vendor lock-in
- Limited execution time (timeouts)
- Debugging difficulty
- Cost at high scale

### Common Patterns

#### Function as a Service (FaaS)
```
Trigger → Lambda Function → Action
```

#### Backend for Frontend (BFF)
```
Frontend → API Gateway → Lambda Functions → Services
```

#### Event Processing
```
S3 Upload → Lambda → Process Image → Store Result
```

### Example Stack (AWS)
- **Compute**: AWS Lambda
- **API**: API Gateway
- **Database**: DynamoDB
- **Storage**: S3
- **Auth**: Cognito
- **Messaging**: SQS, SNS

---

## Event-Driven Architecture

### Description
System components communicate by producing and consuming events, enabling loose coupling and asynchronous processing.

### When to Use
- Real-time data processing
- Complex workflows with many steps
- Need for system decoupling
- Audit trail requirements
- Integration with multiple systems

### Pros
- Loose coupling between services
- High scalability
- Fault tolerance (async processing)
- Audit trail (event log)
- Flexibility (easy to add consumers)

### Cons
- Eventual consistency
- Debugging complexity
- Event schema management
- Message ordering challenges
- Duplicate event handling

### Patterns

#### Event Notification
Service publishes event when something happens; consumers react.

#### Event-Carried State Transfer
Event contains full state; consumers update local cache.

#### Event Sourcing
Store all state changes as events; rebuild state by replaying events.

### Example Flow
```
Order Created Event
  ├→ Inventory Service (decrease stock)
  ├→ Email Service (send confirmation)
  ├→ Analytics Service (track metrics)
  └→ Shipping Service (schedule delivery)
```

---

## Layered (N-Tier) Architecture

### Description
Application organized into horizontal layers, each with specific responsibilities.

### Common Layers
1. **Presentation Layer**: UI, API endpoints
2. **Business Logic Layer**: Core application logic
3. **Data Access Layer**: Database interactions
4. **Database Layer**: Data storage

### When to Use
- Traditional enterprise applications
- Clear separation of concerns needed
- Team organized by technical function
- Stable, well-understood domain

### Pros
- Clear separation of concerns
- Easy to understand
- Reusable layers
- Testable (can mock layers)

### Cons
- Can become monolithic
- Tight coupling between layers
- Performance overhead (layer traversal)
- Encourages database-centric design

### Example Structure
```
Presentation Layer (Controllers)
       ↓
Business Logic Layer (Services)
       ↓
Data Access Layer (Repositories)
       ↓
Database Layer (PostgreSQL)
```

---

## Hexagonal Architecture

### Description
Also called "Ports and Adapters," isolates core business logic from external dependencies through well-defined interfaces.

### Components
- **Domain**: Core business logic (center)
- **Ports**: Interfaces defining interactions
- **Adapters**: Implementations of ports (external systems)

### When to Use
- Complex business logic
- Need to swap implementations (databases, APIs)
- High testability requirements
- Domain-driven design

### Pros
- Highly testable (mock adapters)
- Technology agnostic core
- Easy to change external dependencies
- Clear business logic isolation

### Cons
- Initial complexity
- More code (interfaces and implementations)
- Learning curve

### Example Structure
```
Core Domain (Business Logic)
       ↓
    Ports (Interfaces)
       ↓
Adapters
  ├─ REST API Adapter
  ├─ Database Adapter (PostgreSQL)
  ├─ Message Queue Adapter (RabbitMQ)
  └─ Email Service Adapter (SendGrid)
```

---

## CQRS

### Description
Separates read (query) and write (command) operations into different models.

### When to Use
- Read and write workloads differ significantly
- Complex business logic on writes
- Need for different data models for reads vs. writes
- High performance requirements
- Event-sourced systems

### Pros
- Optimized read and write models
- Scalability (scale reads and writes independently)
- Flexibility (different databases for reads/writes)
- Clear command/query separation

### Cons
- Increased complexity
- Eventual consistency between read and write models
- Code duplication
- Learning curve

### Pattern Structure
```
Write Side (Commands)
  User creates order → Command Handler → Write Database → Event Published

Read Side (Queries)
  Event → Update Read Model → Query Handler → Return to User
```

### Example
```
Command Side:
  - CreateOrderCommand → OrderWriteModel (normalized)
  - UpdateInventoryCommand → InventoryWriteModel

Query Side:
  - GetOrderDetails → OrderReadModel (denormalized for fast reads)
  - GetUserOrders → UserOrdersReadModel (pre-joined data)
```

---

## Event Sourcing

### Description
Store all changes to application state as a sequence of events, rather than just the current state.

### When to Use
- Audit trail required
- Need to replay events (debugging, analytics)
- Complex domain with state changes
- Temporal queries (state at any point in time)
- CQRS implementation

### Pros
- Complete audit trail
- Time travel (reconstruct past state)
- Event replay capability
- Natural fit for event-driven architecture

### Cons
- Complexity (event versioning, migrations)
- Query complexity (rebuild state from events)
- Storage overhead (all events stored)
- Learning curve

### Pattern Structure
```
Command → Event Store (append-only log)
              ↓
        Event Replay → Current State
              ↓
        Projections (Read Models)
```

### Example Event Store
```
OrderCreated { orderId: 123, userId: 456, total: 99.99 }
OrderItemAdded { orderId: 123, itemId: 789, quantity: 2 }
OrderShipped { orderId: 123, trackingNumber: "ABC123" }
OrderDelivered { orderId: 123, deliveryDate: "2024-01-15" }

Current State = Replay all events
```

---

## Service-Oriented Architecture

### Description
Application structured as a collection of services that communicate via standard protocols (SOAP, REST).

### When to Use
- Enterprise integration
- Legacy system modernization
- Reusable business capabilities
- Service governance requirements

### Pros
- Service reusability
- Interoperability (standard protocols)
- Business alignment (services map to business capabilities)
- Technology agnostic

### Cons
- Can become complex (ESB overhead)
- Performance (XML/SOAP overhead)
- Vendor lock-in (ESB products)
- Governance complexity

### SOA vs. Microservices
| Aspect | SOA | Microservices |
|--------|-----|---------------|
| Granularity | Coarser | Finer |
| Communication | ESB, SOAP | REST, gRPC, events |
| Data | Shared database common | Database per service |
| Deployment | Monolithic deployment | Independent deployment |

---

## Micro-Frontend Architecture

### Description
Extend microservices concepts to frontend, decomposing UI into independent micro-apps.

### When to Use
- Multiple teams working on different features
- Different technology stacks per feature
- Independent deployment of UI features
- Large, complex frontend applications

### Pros
- Team autonomy
- Technology diversity
- Independent deployment
- Incremental migration (legacy to modern)

### Cons
- Increased complexity
- Code duplication
- Performance overhead (multiple bundles)
- Consistency challenges (UX, design)

### Implementation Approaches

#### 1. Build-Time Integration
Micro-frontends compiled together at build time.

#### 2. Server-Side Composition
Server assembles HTML from multiple micro-frontends.

#### 3. Client-Side Composition
JavaScript dynamically loads micro-frontends.

#### 4. Module Federation (Webpack 5)
Share code between micro-frontends at runtime.

### Example Structure
```
Shell App (container)
  ├─ Header Micro-Frontend
  ├─ Product Catalog Micro-Frontend (React)
  ├─ Shopping Cart Micro-Frontend (Vue)
  └─ User Profile Micro-Frontend (Angular)
```

---

## Pattern Selection Guide

| Requirement | Recommended Pattern |
|-------------|---------------------|
| Small team, simple app | Monolithic |
| Large team, complex domain | Microservices |
| Variable traffic, low DevOps | Serverless |
| Real-time processing | Event-Driven |
| Clear separation of concerns | Layered |
| Testability, DDD | Hexagonal |
| Read/write workload differences | CQRS |
| Audit trail, time travel | Event Sourcing |
| Enterprise integration | SOA |
| Multiple frontend teams | Micro-Frontend |

---

## Anti-Patterns to Avoid

### 1. Distributed Monolith
- Microservices with tight coupling
- **Solution**: Ensure bounded contexts, async communication

### 2. Premature Decomposition
- Microservices before understanding domain
- **Solution**: Start monolithic, extract services later

### 3. Shared Database
- Multiple services accessing same database
- **Solution**: Database per service pattern

### 4. Chatty Services
- Too many synchronous calls between services
- **Solution**: Event-driven communication, data denormalization

### 5. Anemic Domain Model
- Business logic in services instead of domain
- **Solution**: Rich domain models (DDD)
