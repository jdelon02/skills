---
name: task-memory
description: |
  GitHub-backed persistent task management for IMS projects (via GitHub Issues).
  Use to create/list/update durable tasks and link them to IMS sessions.
license: Proprietary
compatibility: Requires IMS backend task API availability and GitHub authentication (backend uses gh CLI); writes/updates GitHub Issues.
metadata:
  user_invocable: true
  operations: ["create_task", "list_tasks", "get_task", "update_task"]
  keywords: ["ims", "tasks", "task-memory", "github issues", "gh", "tracking", "session-memory"]
allowed-tools: read_mcp_resource call_mcp_tool
---

# task-memory Skill

GitHub-backed persistent task management for IMS projects.

---

## Overview

The **task-memory** skill provides persistent, project-scoped task tracking backed by GitHub Issues. This replaces ephemeral in-memory task lists with durable storage that survives session restarts and integrates seamlessly with the IMS session-memory system.

## Key Features

- **GitHub Issues as Tasks**: Tasks are stored as GitHub Issues (zero additional infrastructure)
- **Project-Scoped**: Tasks automatically map to GitHub repos via `project_id`
- **Session-Integrated**: Tasks can be linked to specific sessions via labels
- **Rich UI**: Access tasks via GitHub web/mobile interface
- **Collaboration-Ready**: Comments, @mentions, assignees all work naturally
- **Persistent**: Tasks survive session restarts and context switches

## Backend Service

Tasks are managed via the IMS backend API running on `http://localhost:8000`.

Core operations:
- `POST /tasks/create` - Create a new task (GitHub Issue)
- `POST /tasks/list` - List tasks with filters
- `GET /tasks/{task_id}` - Get a single task
- `POST /tasks/update` - Update task status/assignee

## Task Data Model

```typescript
interface Task {
  // Identity
  id: string;                      // Format: "gh-owner/repo-123"
  project_id: string;              // IMS project identifier

  // Core fields
  subject: string;                 // Issue title
  description: string;             // Issue body (before metadata)
  status: string;                  // pending, in_progress, completed
  priority: string;                // low, medium, high, critical

  // Assignment
  owner: string | null;            // GitHub assignee
  tags: string[];                  // Labels (ims:tag format)

  // Context
  file_path: string | null;        // Primary file for this task
  line_hint: number | null;        // Line number hint

  // Metadata
  metadata: {
    github_repo: string;           // owner/repo
    github_issue: number;          // Issue number
    github_url: string;            // Full issue URL
    session_id: string | null;     // Linked session
  }
}
```

## Usage

### Create Task

```bash
curl -X POST http://localhost:8000/tasks/create \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": "integrated-memory-system",
    "subject": "Fix context-rag empty results",
    "description": "Meilisearch returning no results for project queries",
    "session_id": "43614360-fcec-401c-8085-ed2e42c2f63b",
    "tags": ["bug", "context-rag"],
    "priority": "high",
    "file_path": "app/main.py"
  }'
```

**Result**: Creates GitHub Issue in `jdelon02/integrated-memory-system` with:
- Title: "Fix context-rag empty results"
- Labels: `ims:bug`, `ims:context-rag`, `priority:high`, `session-43614360`
- Body includes session ID and file path

### List Tasks

```bash
curl -X POST http://localhost:8000/tasks/list \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": "integrated-memory-system",
    "status": ["pending", "in_progress"],
    "session_id": "43614360-fcec-401c-8085-ed2e42c2f63b"
  }'
```

**Filters**:
- `status` - Filter by task status
- `owner` - Filter by GitHub assignee
- `session_id` - Filter by session (uses `session-{id[:8]}` label)
- `tags` - Filter by tags (searches for `ims:{tag}` labels)
- `limit` - Max results (default: 50)

### Get Task

```bash
curl http://localhost:8000/tasks/gh-jdelon02-integrated-memory-system-123
```

### Update Task

```bash
curl -X POST http://localhost:8000/tasks/update \
  -H "Content-Type: application/json" \
  -d '{
    "task_id": "gh-jdelon02-integrated-memory-system-123",
    "status": "completed",
    "comment": "Fixed by indexing docs into Meilisearch"
  }'
```

**Actions**:
- `status: "completed"` - Closes the GitHub Issue
- `status: "in_progress"` - Reopens if closed
- `owner: "username"` - Assigns to GitHub user
- `comment: "text"` - Adds comment to issue

## Integration with Session Memory

### Store Current Task in Session

```python
# When starting work on a task
session = continue_session(
    project_id="integrated-memory-system",
    agent_id="implementer",
    task_id="default"
)

# Create task
task = create_task(
    project_id="integrated-memory-system",
    session_id=session.session_id,
    subject="Implement task-memory service",
    tags=["architecture"]
)

# Link task to session
session.state.metadata["current_task_id"] = task.id
session.state.metadata["current_github_issue"] = task.metadata["github_issue"]
session.state.next_action = {
    "description": f"Work on: {task.subject}",
    "file_path": task.file_path
}
```

### Resume with Tasks

```python
# On session resume
session = continue_session(...)

# Check for active task
if "current_task_id" in session.state.metadata:
    task = get_task(session.state.metadata["current_task_id"])

    print(f"Resuming work on: {task.subject}")
    print(f"GitHub: {task.metadata['github_url']}")
    print(f"Status: {task.status}")

# List other tasks for this session
tasks = list_tasks(
    project_id=session.project_id,
    session_id=session.session_id,
    status=["pending", "in_progress"]
)
```

## Label Conventions

GitHub Issues created by task-memory use structured labels:

- **`ims:{tag}`** - User-defined tags (e.g., `ims:bug`, `ims:feature`)
- **`priority:{level}`** - Priority (`priority:low`, `priority:medium`, `priority:high`, `priority:critical`)
- **`session-{id}`** - Session identifier (first 8 chars of session_id)
- **`agent:{name}`** - Creating agent (e.g., `agent:implementer`)

## Requirements

### GitHub CLI

The backend uses the `gh` CLI to interact with GitHub:

```bash
# Install gh CLI
brew install gh

# Authenticate
gh auth login

# Or set token
export GITHUB_TOKEN=your_token_here
```

### Repository Mapping

Tasks automatically map `project_id` to GitHub repos:

1. **Auto-detection**: Checks git remote in common project locations
2. **Fallback**: Uses convention `{default_org}/{project_id}`

Example:
- `project_id: "integrated-memory-system"`
- Auto-detected: `jdelon02/integrated-memory-system` (from git remote)
- Fallback: `jdelon02/integrated-memory-system`

## Example: Full Workflow

```bash
# 1. Start session
SESSION=$(curl -X POST http://localhost:8000/sessions/continue \
  -H "Content-Type: application/json" \
  -d '{"project_id": "my-app", "agent_id": "implementer", "task_id": "default"}' \
  | jq -r '.session_id')

# 2. Create task (creates GitHub Issue)
TASK=$(curl -X POST http://localhost:8000/tasks/create \
  -H "Content-Type: application/json" \
  -d "{
    \"project_id\": \"my-app\",
    \"session_id\": \"$SESSION\",
    \"subject\": \"Add user authentication\",
    \"description\": \"Implement JWT-based auth\",
    \"tags\": [\"feature\", \"auth\"],
    \"priority\": \"high\"
  }")

TASK_ID=$(echo $TASK | jq -r '.id')
ISSUE_URL=$(echo $TASK | jq -r '.metadata.github_url')

echo "Created task: $TASK_ID"
echo "GitHub Issue: $ISSUE_URL"

# 3. Work on task...
# (implement code)

# 4. Update task
curl -X POST http://localhost:8000/tasks/update \
  -H "Content-Type: application/json" \
  -d "{
    \"task_id\": \"$TASK_ID\",
    \"status\": \"completed\",
    \"comment\": \"Implemented JWT auth with refresh tokens\"
  }"

# 5. Wrap session
curl -X POST http://localhost:8000/sessions/continue \
  -H "Content-Type: application/json" \
  -d "{
    \"project_id\": \"my-app\",
    \"agent_id\": \"implementer\",
    \"task_id\": \"default\",
    \"initial_state\": {
      \"session_id\": \"$SESSION\",
      \"project_id\": \"my-app\",
      \"user_id\": \"jdelon02\",
      \"agent_id\": \"implementer\",
      \"task_id\": \"default\",
      \"metadata\": {\"completed_task_id\": \"$TASK_ID\"}
    }
  }"
```

## Benefits

### vs. Ephemeral In-Memory Lists
- ✅ Persistent across sessions
- ✅ Queryable from any context
- ✅ Visible in GitHub UI
- ✅ Collaborative (team can see/comment)

### vs. Separate Task Database
- ✅ Zero additional infrastructure
- ✅ No sync complexity
- ✅ Rich UI already built
- ✅ Mobile apps available
- ✅ Notifications work

### vs. External Task Services (Todoist, Linear)
- ✅ Project-scoped (follows IMS conventions)
- ✅ Session-integrated
- ✅ No API rate limits
- ✅ Privacy (stays in your GitHub)
- ✅ Git integration (link issues to commits)

## Future Enhancements

### Phase 1: ✅ Complete
- Basic CRUD operations
- GitHub Issue mapping
- Session integration
- Label conventions

### Phase 2: Planned
- Semantic task search (index issues in Qdrant)
- Task dependencies (blocks/blocked_by)
- Integrate into context-rag
- Task templates

### Phase 3: Future
- GitHub Actions automation
- Auto-link tasks to commits
- Task analytics/metrics
- Cross-project task queries

## Troubleshooting

### "gh: command not found"
Install GitHub CLI: `brew install gh` or see https://cli.github.com

### "authentication required"
Run: `gh auth login` or set `GITHUB_TOKEN` environment variable

### "repository not found"
Check that:
1. Repository exists in GitHub
2. You have access to the repository
3. Project ID maps correctly to repo name

### "Failed to create issue"
Ensure:
1. `gh` is authenticated
2. You have write access to the repository
3. Repository exists and is correct

## Architecture

```
Agent → task-memory skill → IMS Backend (localhost:8000) → gh CLI → GitHub Issues
                                                                         ↓
                                              Session State ← Redis ← SessionState.metadata.current_task_id
```

The task-memory service is a thin wrapper over the GitHub CLI, providing an IMS-native API while using GitHub Issues as the persistent storage layer.
