---
name: project-intake
description: |
  Collect a canonical project definition (purpose, workflows, invariants, related projects) via a short Q&A intake,
  then generate a version-controlled `docs/PROJECT.md` (YAML frontmatter + Markdown) suitable for indexing into Meilisearch.
  Use when onboarding a repo into your IMS ecosystem or when related-project relationships are unclear.
license: Proprietary
compatibility: Requires Python (optional helper script) and write access to the target repo; writes/updates docs/PROJECT.md for IMS indexing.
metadata:
  user_invocable: true
  managed_files: ["docs/PROJECT.md"]
  keywords: ["ims", "project intake", "onboarding", "project definition", "meilisearch", "docs", "related projects"]
allowed-tools: run_shell_command read_files apply_patch create_file
---

# Project Intake

## Purpose

IMS works best when each repo has a **stable, canonical project definition** that agents can retrieve
(via docs search / Meilisearch) and machines can parse (via YAML frontmatter).

This skill defines a **templated intake flow** that:

1. Asks a small, structured set of questions.
2. Produces/updates `docs/PROJECT.md` in the target repo.
3. Ensures the output is prompt-ready and relationship-friendly (for related-project discovery).

## Helper script (recommended)

An interactive helper is included:

```bash
python ~/.agents/skills/project-intake/project_intake.py --target /path/to/repo
```

Defaults:

- Writes `docs/PROJECT.md` under the target repo
- Refuses to overwrite unless `--overwrite` is provided

Overwrite example:

```bash
python ~/.agents/skills/project-intake/project_intake.py --target /path/to/repo --overwrite
```

## When to use

Use this skill when:

- A repo is newly added to your IMS “ecosystem” and needs canonical metadata.
- You want to define **related projects** (parent/child/sibling/depends_on) for cross-project context.
- A repo’s README is too noisy/long to serve as canonical machine-readable project metadata.

## Output artifact (canonical)

- Create (or update) **`docs/PROJECT.md`** in the target repo.
- Use the template in `templates/PROJECT.md`.

## Intake questions (recommended)

Ask and record answers for:

1. **Project name** (human-readable)
2. **One-sentence purpose** (what it is / why it exists)
3. **Project kind**: `backend` | `mcp-server` | `skill` | `cli` | `library` | `app` | `docs`
4. **Primary workflows** (2–6 commands): dev/run, test, lint/typecheck, build, deploy
5. **Key invariants** (“must always be true”, 3–8 bullets)
6. **Interfaces**: key APIs/ports, MCP tool names, CLIs, entrypoints
7. **Related projects**: list of `{ project_id, relation_type, note? }`
   - `relation_type`: `parent` | `child` | `sibling` | `depends_on` | `used_by`
8. **Tags** (keywords that improve retrieval)

Keep the Q&A short; the goal is to generate a stable doc, not write a full spec.

## Frontmatter schema (YAML)

Populate a top-level `ims:` object.

Required (minimum):

- `ims.project_id`
- `ims.name`
- `ims.kind`

Recommended:

- `ims.summary`
- `ims.tags`
- `ims.related_projects[]`

Example:

```yaml
---
ims:
  project_id: integrated-memory-system
  name: Integrated Memory System
  kind: backend
  summary: FastAPI backend providing memory-core/session-memory/context-rag services.
  tags: [ims, memory, fastapi, qdrant, postgres, redis, meilisearch]
  related_projects:
    - project_id: ims-mcp
      relation_type: sibling
      note: MCP server exposing IMS tools.
    - project_id: ims-ify
      relation_type: sibling
      note: Skill for installing IMS instruction files.
---
```

## Behavior guidelines

- Prefer stable identifiers:
  - `ims.project_id` should normally equal `basename($PWD)` for the repo.
- Keep related-project entries factual and minimal.
- If a repo already has `docs/PROJECT.md`, update it rather than duplicating in other files.

## Notes on indexing

Many IMS setups index `docs/**/*.md` into Meilisearch. If so, `docs/PROJECT.md` becomes:

- Discoverable via full-text search.
- Prompt-friendly via YAML frontmatter extraction.
- A natural seed source for backend `project_relationships` tables.
