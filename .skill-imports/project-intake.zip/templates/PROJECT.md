---
ims:
  # Stable canonical ID (normally repo basename)
  project_id: <project-id>

  # Human readable
  name: <project-name>

  # One of: backend | mcp-server | skill | cli | library | app | docs
  kind: <project-kind>

  # One sentence
  summary: <one-sentence-summary>

  # Keywords to improve retrieval
  tags: [ims, <tag2>, <tag3>]

  # Describe relationships to other repos in your IMS ecosystem.
  # relation_type: parent | child | sibling | depends_on | used_by
  related_projects:
    - project_id: <other-project-id>
      relation_type: sibling
      note: <why-related>

  # Optional: surface primary interfaces for quick retrieval.
  interfaces:
    http:
      - name: <service-name>
        base_url: http://localhost:<port>
        notes: <notes>
    mcp_tools:
      - <tool-name>
    clis:
      - <command>
---

# Project Definition

## What this repo is

(2–8 sentences. Focus on purpose, boundaries, and what it is *not*.)

## Key workflows

- Dev/run:
  - `<command>`
- Test:
  - `<command>`
- Lint/typecheck:
  - `<command>`
- Build/release:
  - `<command>`

## Key invariants

- ("must always" statements)
- (e.g., project_id defaulting rules, mandatory protocols, compatibility constraints)

## Related projects (narrative)

Briefly describe how this repo interacts with the related repos listed in frontmatter.

## Notes for agents

- Where to start reading:
  - `<file>`
- Common gotchas:
  - `<gotcha>`
