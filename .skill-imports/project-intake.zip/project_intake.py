#!/usr/bin/env python3
"""Generate a canonical docs/PROJECT.md for an IMS repo via a short interactive intake.

This script is intentionally dependency-free so it can run anywhere with Python 3.

Typical usage:
  python ~/.agents/skills/project-intake/project_intake.py --target /path/to/repo

It will write (by default):
  <target>/docs/PROJECT.md
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional


RELATION_TYPES = {"parent", "child", "sibling", "depends_on", "used_by"}
KINDS = {"backend", "mcp-server", "skill", "cli", "library", "app", "docs"}


def _slug_to_name(project_id: str) -> str:
    # "integrated-memory-system" -> "Integrated Memory System"
    parts = [p for p in project_id.replace("_", "-").split("-") if p]
    return " ".join(p[:1].upper() + p[1:] for p in parts) or project_id


def _prompt(
    label: str,
    *,
    default: Optional[str] = None,
    required: bool = False,
) -> str:
    while True:
        suffix = f" [{default}]" if default else ""
        raw = input(f"{label}{suffix}: ").strip()
        if raw:
            return raw
        if default is not None:
            return default
        if not required:
            return ""
        print("  (required)")


def _prompt_choice(label: str, choices: List[str], *, default: Optional[str] = None) -> str:
    choices_str = ", ".join(choices)
    while True:
        val = _prompt(f"{label} ({choices_str})", default=default)
        if not val:
            return ""
        if val in choices:
            return val
        print(f"  Invalid choice: {val!r}")


def _prompt_list(label: str, *, min_items: int = 0) -> List[str]:
    print(f"{label} (enter one per line; blank line to finish)")
    out: List[str] = []
    while True:
        raw = input("- ").strip()
        if not raw:
            if len(out) >= min_items:
                return out
            print(f"  (need at least {min_items})")
            continue
        out.append(raw)


def _prompt_tags(default: List[str]) -> List[str]:
    raw = _prompt(
        "Tags (comma-separated)",
        default=", ".join(default) if default else None,
    ).strip()
    if not raw:
        return []
    tags = [t.strip() for t in raw.split(",") if t.strip()]
    # de-dupe but preserve order
    seen = set()
    out: List[str] = []
    for t in tags:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def _yaml_quote(val: str) -> str:
    # conservative quoting for YAML strings
    escaped = val.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _render_frontmatter(data: Dict[str, object]) -> str:
    ims = data["ims"]
    assert isinstance(ims, dict)

    lines: List[str] = ["---", "ims:"]

    # Required
    lines.append(f"  project_id: {ims['project_id']}")
    lines.append(f"  name: {_yaml_quote(str(ims['name']))}")
    lines.append(f"  kind: {ims['kind']}")

    summary = str(ims.get("summary") or "").strip()
    if summary:
        lines.append(f"  summary: {_yaml_quote(summary)}")

    tags = ims.get("tags")
    if isinstance(tags, list) and tags:
        tag_list = ", ".join(_yaml_quote(str(t)) for t in tags)
        lines.append(f"  tags: [{tag_list}]")

    related = ims.get("related_projects")
    if isinstance(related, list) and related:
        lines.append("  related_projects:")
        for r in related:
            if not isinstance(r, dict):
                continue
            pid = str(r.get("project_id") or "").strip()
            rtype = str(r.get("relation_type") or "").strip()
            note = str(r.get("note") or "").strip()
            if not pid or not rtype:
                continue
            lines.append(f"    - project_id: {pid}")
            lines.append(f"      relation_type: {rtype}")
            if note:
                lines.append(f"      note: {_yaml_quote(note)}")

    interfaces = ims.get("interfaces")
    if isinstance(interfaces, dict) and interfaces:
        # Keep this minimal to avoid producing noisy YAML.
        http_list = interfaces.get("http") if isinstance(interfaces.get("http"), list) else []
        mcp_tools = interfaces.get("mcp_tools") if isinstance(interfaces.get("mcp_tools"), list) else []
        clis = interfaces.get("clis") if isinstance(interfaces.get("clis"), list) else []

        if http_list or mcp_tools or clis:
            lines.append("  interfaces:")

        if http_list:
            lines.append("    http:")
            for svc in http_list:
                if not isinstance(svc, dict):
                    continue
                name = str(svc.get("name") or "").strip()
                base_url = str(svc.get("base_url") or "").strip()
                notes = str(svc.get("notes") or "").strip()
                if not name or not base_url:
                    continue
                lines.append(f"      - name: {_yaml_quote(name)}")
                lines.append(f"        base_url: {_yaml_quote(base_url)}")
                if notes:
                    lines.append(f"        notes: {_yaml_quote(notes)}")

        if mcp_tools:
            lines.append("    mcp_tools:")
            for t in mcp_tools:
                tv = str(t).strip()
                if tv:
                    lines.append(f"      - {_yaml_quote(tv)}")

        if clis:
            lines.append("    clis:")
            for c in clis:
                cv = str(c).strip()
                if cv:
                    lines.append(f"      - {_yaml_quote(cv)}")

    lines.append("---")
    return "\n".join(lines)


def _render_body(
    *,
    purpose: str,
    workflows: Dict[str, List[str]],
    invariants: List[str],
    related_narrative: str,
    start_reading: List[str],
    gotchas: List[str],
) -> str:
    out: List[str] = [
        "# Project Definition",
        "",
        "## What this repo is",
        "",
        (purpose.strip() or "(todo: add purpose)").strip(),
        "",
        "## Key workflows",
        "",
    ]

    def add_cmds(title: str, cmds: List[str]) -> None:
        out.append(f"- {title}:")
        if not cmds:
            out.append("  - (todo)")
            return
        for c in cmds:
            out.append(f"  - `{c}`")

    add_cmds("Dev/run", workflows.get("dev", []))
    add_cmds("Test", workflows.get("test", []))
    add_cmds("Lint/typecheck", workflows.get("lint", []))
    add_cmds("Build/release", workflows.get("build", []))

    out.extend([
        "",
        "## Key invariants",
        "",
    ])
    if invariants:
        for inv in invariants:
            out.append(f"- {inv}")
    else:
        out.append("- (todo)")

    out.extend([
        "",
        "## Related projects (narrative)",
        "",
    ])
    out.append(related_narrative.strip() or "(optional)")

    out.extend([
        "",
        "## Notes for agents",
        "",
        "- Where to start reading:",
    ])
    if start_reading:
        for p in start_reading:
            out.append(f"  - `{p}`")
    else:
        out.append("  - (todo)")

    out.append("- Common gotchas:")
    if gotchas:
        for g in gotchas:
            out.append(f"  - {g}")
    else:
        out.append("  - (none known)")

    out.append("")
    return "\n".join(out)


def main() -> int:
    parser = argparse.ArgumentParser(description="IMS project intake -> generate docs/PROJECT.md")
    parser.add_argument("--target", default=".", help="Target repo root (default: current directory)")
    parser.add_argument(
        "--out",
        default=None,
        help="Output file path relative to repo root (default: docs/PROJECT.md)",
    )
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing docs/PROJECT.md")
    args = parser.parse_args()

    repo_root = Path(args.target).expanduser().resolve()
    if not repo_root.is_dir():
        print(f"ERROR: target is not a directory: {repo_root}", file=sys.stderr)
        return 2

    project_id_default = repo_root.name
    out_rel = Path(args.out) if args.out else Path("docs/PROJECT.md")
    out_path = (repo_root / out_rel).resolve()

    if out_path.exists() and not args.overwrite:
        print(f"ERROR: {out_path} already exists. Re-run with --overwrite to replace.", file=sys.stderr)
        return 2

    print("Project Intake (IMS)")
    print(f"Target: {repo_root}")
    print(f"Output: {out_path}")
    print("")

    project_id = _prompt("IMS project_id", default=project_id_default, required=True)
    name = _prompt("Project name", default=_slug_to_name(project_id), required=True)
    kind = _prompt_choice("Project kind", sorted(KINDS), default="backend")
    summary = _prompt("One-sentence summary", required=True)

    tags = _prompt_tags(default=["ims", kind] if kind else ["ims"])

    # Related projects
    related_projects: List[Dict[str, str]] = []
    print("Related projects (blank project_id to finish)")
    while True:
        rpid = _prompt("  related project_id")
        if not rpid:
            break
        rtype = _prompt_choice("  relation_type", sorted(RELATION_TYPES), default="sibling")
        note = _prompt("  note (optional)")
        related_projects.append(
            {
                "project_id": rpid,
                "relation_type": rtype,
                "note": note,
            }
        )

    # Interfaces (optional)
    interfaces: Dict[str, object] = {}
    http_ifaces: List[Dict[str, str]] = []
    if _prompt("Add HTTP interface entries? (y/N)", default="N").lower().startswith("y"):
        print("HTTP interfaces (blank name to finish)")
        while True:
            svc_name = _prompt("  name")
            if not svc_name:
                break
            base_url = _prompt("  base_url (e.g. http://localhost:8000)", required=True)
            notes = _prompt("  notes (optional)")
            http_ifaces.append({"name": svc_name, "base_url": base_url, "notes": notes})
    if http_ifaces:
        interfaces["http"] = http_ifaces

    mcp_tools: List[str] = []
    if _prompt("List MCP tools? (y/N)", default="N").lower().startswith("y"):
        mcp_tools = _prompt_list("MCP tools", min_items=0)
    if mcp_tools:
        interfaces["mcp_tools"] = mcp_tools

    clis: List[str] = []
    if _prompt("List CLI commands? (y/N)", default="N").lower().startswith("y"):
        clis = _prompt_list("CLIs", min_items=0)
    if clis:
        interfaces["clis"] = clis

    ims: Dict[str, object] = {
        "project_id": project_id,
        "name": name,
        "kind": kind or "backend",
        "summary": summary,
    }
    if tags:
        ims["tags"] = tags
    if related_projects:
        ims["related_projects"] = related_projects
    if interfaces:
        ims["interfaces"] = interfaces

    purpose = _prompt("Describe what this repo is (2–8 sentences)", required=True)

    workflows: Dict[str, List[str]] = {}
    workflows["dev"] = _prompt_list("Dev/run commands", min_items=0)
    workflows["test"] = _prompt_list("Test commands", min_items=0)
    workflows["lint"] = _prompt_list("Lint/typecheck commands", min_items=0)
    workflows["build"] = _prompt_list("Build/release commands", min_items=0)

    invariants = _prompt_list("Key invariants (must-always statements)", min_items=0)

    related_narrative = _prompt("Related projects narrative (optional)")

    start_reading = _prompt_list("Where should agents start reading?", min_items=0)
    gotchas = _prompt_list("Common gotchas", min_items=0)

    frontmatter = _render_frontmatter({"ims": ims})
    body = _render_body(
        purpose=purpose,
        workflows=workflows,
        invariants=invariants,
        related_narrative=related_narrative,
        start_reading=start_reading,
        gotchas=gotchas,
    )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(frontmatter + "\n\n" + body, encoding="utf-8")

    print("")
    print(f"Wrote: {out_path}")
    print("Next: re-index docs so this file is available in Meilisearch / context-rag.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
