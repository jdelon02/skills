# Project Intake – Handoff Notes (VCS + Issue Tracker + Isolation)

This document captures the agreed approach for what the **project-intake** workflow should do to:

1. Discover/capture a project’s VCS hosting (GitHub, Pantheon, none)
2. Discover/capture where issues/tasks should be created (GitHub Issues, upstream for Pantheon)
3. Support **strict isolation (Option A)** so isolated projects never participate in implicit related-project matching or context expansion

## Key concepts

### Two different “repos” per project
A project can have:

- **VCS remote**: where code is pushed/pulled (GitHub, Pantheon, other, or none)
- **Issue tracker repo**: where tasks/issues should be created (GitHub repo), which may differ from VCS remote (e.g. Pantheon project uses an upstream GitHub repo)

### Isolation (Option A)
If a project is marked **isolated**, it must:

- be excluded from any implicit “related project” matching / suggestions
- be excluded from any “include related projects” / scope expansion behavior
- only be used when the user explicitly targets the project_id

**Option A rule**: isolated projects MUST NOT create or store any related-project relationship edges at intake time.

## What project-intake should capture

### Required fields (frontmatter)
Store these in `docs/PROJECT.md` YAML frontmatter so any agent can read them.

```yaml
---
ims:
  project_id: <project-id>

  # Safety control:
  # If true, the project must not be implicitly mixed into other project contexts.
  is_isolated: false

  # VCS (where code lives)
  vcs:
    provider: github   # github | pantheon | other | none
    remote_url: <full-remote-url-or-empty>

  # Issues/tasks (where GitHub Issues should be created)
  issues:
    provider: github   # github | none
    github_repo: <owner/repo-or-empty>
    github_url: <https://github.com/owner/repo-or-empty>

  # Optional: if the project uses an upstream GitHub repo (common for Pantheon)
  upstream:
    github_repo: <owner/repo-or-empty>
---
```

### Postgres persistence (canonical lookup)
If the IMS backend exposes a project registry upsert (e.g. `POST /projects/upsert`), project-intake should also upsert:

- `project_id`
- `is_isolated`
- `vcs_provider`, `vcs_remote_url`
- `issues_provider`, `issues_github_repo`

This ensures other agents/tools can resolve the issue tracker repo without requiring filesystem access.

## Discovery & prompting rules

### 1) If the target directory is a git repo
Prefer robust git detection (don’t rely on a literal `.git` directory existing):

- Detect: `git rev-parse --is-inside-work-tree`
- Remote:
  - Prefer: `git remote get-url origin`
  - Fallback: `git remote -v`

Then:

- If remote is GitHub (ssh/https), parse:
  - owner/org
  - repo
  - set `ims.vcs.provider=github`
  - set `ims.issues.provider=github` and `ims.issues.github_repo=<owner/repo>`

- If remote is Pantheon:
  - set `ims.vcs.provider=pantheon`
  - prompt for **upstream GitHub repo** (where issues should be filed)
    - set `ims.issues.github_repo=<owner/repo>`
    - set `ims.upstream.github_repo=<owner/repo>`

- If remote is neither GitHub nor Pantheon:
  - set `ims.vcs.provider=other`
  - prompt: “Where should issues be tracked?”
    - If GitHub: collect `owner/repo`
    - Else: `ims.issues.provider=none`

### 2) If the target directory is not a git repo
Prompt:

1. “Does this project use git/VCS?”
   - If no: `ims.vcs.provider=none`

2. “Should tasks/issues be tracked somewhere?”
   - If no: `ims.issues.provider=none`
   - If yes and GitHub:
     - prompt personal vs organization owner
     - prompt visibility public/private
     - optionally create repo via `gh repo create` (only with explicit confirmation)
     - optionally `git init` + set origin (only with explicit confirmation)

### 3) Isolation prompt (Option A)
Prompt:

- “Should this project be isolated completely?” (boolean)

If `true`:

- set `ims.is_isolated=true`
- DO NOT prompt for or store related-project edges
- any later “related project” features must treat it as opt-out for implicit matching

## Non-goals

- This document does not define the cross-project handoff tool itself (see `ims-mcp/spec/ims_handoff.md` for that).
- This document does not require projects to be on GitHub; it only defines where IMS can create tasks when GitHub Issues are used.
