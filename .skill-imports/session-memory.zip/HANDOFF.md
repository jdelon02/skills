# HANDOFF: session-memory Skill Enhancement

**Date**: 2026-02-17  
**Status**: Proposed  
**Purpose**: Reduce excessive `wrap_session` calls ("wrap chatter") by introducing a `checkpoint` operation and clarifying wrap semantics.

---

## Problem

Agents currently treat **every conversational step** as a "wrap boundary" and call `wrap_session` excessively, resulting in verbose logs and user friction:
- make code change → wrap
- ask user to test → wrap
- run tests → wrap
- ask user to fix tests → wrap

This was observed with Copilot Chat in VS Code (via `ims-mcp`), but the root cause is **agent interpretation of when to wrap**, not the IMS server or MCP adapter.

The current session-memory SKILL.md says:
> "Before pausing, switching tasks, or handing off to another agent, update ... and call `session-memory.wrap_session(...)`."

Some agents interpret "asking the user a question" as "pausing", leading to wrap after every user interaction.

---

## Proposed Solution

### 1. Add a new `checkpoint_session` operation

**Semantics**: "Update session state mid-burst without implying 'pause/hand-off/stop'."

**Purpose**: Allow agents to:
- Persist progress incrementally during a work burst,
- Update `next_action` as they move through steps,
- Record intermediate state for crash recovery

…without signaling that work has stopped or triggering verbose "IMS Session Wrap" messages.

**Operation signature** (same as `wrap_session`, different name/semantics):
```json
POST /sessions/checkpoint
{
  "project_id": "my-project",
  "user_id": "jdelon02",      // optional
  "agent_id": "planner",      // optional
  "task_id": "default",       // optional
  "state": { /* SessionState */ }
}
```

**Response** (same shape as wrap, but `status: "checkpointed"`):
```json
{
  "status": "checkpointed",
  "session_id": "UUID",
  "state": { /* final persisted SessionState */ }
}
```

**Differences from `wrap_session`**:
| Aspect | `checkpoint_session` | `wrap_session` |
|--------|---------------------|----------------|
| Semantic intent | "still working, just saving progress" | "pausing / stopping / handing off" |
| Visibility | Low (no mandatory "IMS Session Wrap" summary) | High (MUST surface "IMS Session Wrap" summary per AGENTS.md) |
| When to use | Frequently during active work | Rarely, only at true boundaries |
| Log verbosity | Minimal / silent | Verbose (tuple + status + session_id) |

---

### 2. Update SKILL.md agent workflow guidance

**Current (vague)**:
> "Before pausing, switching tasks, or handing off to another agent, ... call `wrap_session`."

**Proposed (explicit)**:
> **When to wrap (rare)**:
> - The user explicitly asks to pause or stop ("let's pick this up later", "stop for now")
> - You are switching to a different task/session tuple
> - You are handing off to another agent
> - The conversation is ending without explicit "continue" signal
>
> **When to checkpoint (frequent)**:
> - You complete a discrete step within a multi-step task (e.g., edit files → checkpoint)
> - You want to persist intermediate state for crash recovery
> - You are about to run a potentially long-running or risky operation (tests, builds, deploys)
>
> **When NOT to wrap or checkpoint**:
> - You ask the user a question and are waiting for a response (still working, no state change)
> - You display output to the user (no action boundary)
> - The current step hasn't meaningfully changed `next_action` or progress

---

### 3. Implementation tasks

#### Backend (this repo: `integrated-memory-system`)
- [ ] Add `POST /sessions/checkpoint` endpoint in `app/main.py` (duplicate of `/sessions/wrap` logic, returns `status="checkpointed"`)
- [ ] Add `checkpoint_session` test in `tests/test_sessions_continue.py`
- [ ] Update `spec/API_ENDPOINTS.md` to document `/sessions/checkpoint` (note: no mandatory "IMS Session Wrap" summary)

#### MCP adapter (`ims-mcp`)
- [ ] Add `@mcp.tool("session_memory_checkpoint_session")` in `ims-mcp/server.py` (same signature as `wrap`, different endpoint/docstring)
- [ ] Update `ims-mcp/app/ims_client.py` `SessionMemoryClient` to expose `.checkpoint_session(...)`
- [ ] Update `ims-mcp/spec/session-memory.json` to include `checkpoint_session` tool
- [ ] Update `ims-mcp/README.md` tool list

#### Skill (this dir: `~/.agents/skills/session-memory`)
- [ ] Update `SKILL.md` "Recommended Agent Workflow" section with explicit "When to wrap vs checkpoint" guidance (see above)
- [ ] Add `checkpoint_session` to operation list in frontmatter metadata
- [ ] Update keywords to include "checkpoint"
- [ ] (Optional) Add example showing checkpoint within a multi-step task vs wrap at true boundary

#### Upstream propagation
- [ ] Update `AGENTS.md` in `integrated-memory-system` repo to clarify wrap vs checkpoint semantics
- [ ] (Optional) Update `.github/instructions/main.instructions.md` if it references wrap protocol

---

## Open Questions

1. **Should `checkpoint_session` still bump `updated_at`?**
   - Proposal: Yes, but optionally skip (or only bump every N checkpoints) if we want checkpoint to be ultra-silent.

2. **Should `checkpoint_session` still compute `last_action`?**
   - Proposal: Yes, to keep the server-side "last action taken" tracking accurate.

3. **Should agents be allowed to call both wrap and checkpoint in the same work burst?**
   - Proposal: Yes (e.g., checkpoint after file edits, checkpoint after tests, then wrap at the end). The agent decides based on semantics.

---

## Success Criteria

- [ ] Agents can persist progress mid-burst without verbose "IMS Session Wrap" messages
- [ ] `wrap_session` calls are rare (only at true boundaries: pause/hand-off/stop)
- [ ] Session state remains consistent and resumable even with frequent checkpoints
- [ ] No user-facing behavioral regressions (existing wrap behavior still works)

---

## Related Work

- `integrated-memory-system` repo has `last_action` tracking (auto-set when `next_action` changes), which should continue to work with checkpoint.
- `human_task_title` + `last_action_summary` resume UX improvements (just deployed) are independent of checkpoint.

---

## Next Steps

1. Review this HANDOFF with skill maintainer / user (you!)
2. If approved:
   - Implement backend `/sessions/checkpoint` endpoint + tests
   - Add MCP adapter tool
   - Update SKILL.md guidance
3. Test in practice with Copilot Chat / Warp to confirm reduced wrap chatter
4. If successful, archive this HANDOFF → commit to skill repo

---

**Contact**: jdelon02  
**Repo**: `~/.agents/skills/session-memory` (git-backed skill dir)
