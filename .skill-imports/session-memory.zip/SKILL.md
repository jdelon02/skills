---
name: session-memory
description: |
  IMS durable session/task state (project/user/agent/task tuple) backed by Redis for reliable pause/resume.
  Use at start of work to resume/create a session (`auto_session`/`continue_session`) and before pausing to persist progress (`wrap_session`).
license: Proprietary
compatibility: Requires Redis-backed IMS session service; persists session state; intended for frequent reads/writes.
metadata:
  user_invocable: true
  phase: 2
  tuple_identity: ["project_id", "user_id", "agent_id", "task_id"]
  operations: ["auto_session", "continue_session", "checkpoint_session", "wrap_session", "list_open_sessions", "resume_session"]
  keywords: ["auto_session", "wrap_session", "checkpoint", "resume", "redis", "next_action"]
allowed-tools: read_mcp_resource call_mcp_tool
---

# Session Memory Skill

Session-scoped state for agents working on a project. This skill sits alongside `memory-core` and is responsible for explicit task/session state, not long-term memories.

---

## Identity Model

Each **session** is uniquely identified by the tuple:

- `project_id` – usually `basename($PWD)` for the current repo.
- `user_id` – logical/OS user (e.g., `IMS_USER_ID`, `whoami`).
- `agent_id` – agent role, e.g. `planner`, `implementer`, `debugger`.
- `task_id` – logical task identifier, e.g. `default`, `refactor-auth`, `fix-ci`.

We call this 4-field combination the **session identity**. There is at most one *current* session per session identity. Historical sessions may be archived separately.

Redis key convention:

```text
ims:session:{project_id}:{user_id}:{agent_id}:{task_id}
```

---

## Core Data Shape: SessionState

Minimum fields:

- `session_id` (string, UUID) – internal, immutable for life of the session.
- `project_id` (string)
- `user_id` (string)
- `agent_id` (string)
- `task_id` (string)
- `status` (string, optional) – e.g. `"active" | "completed" | "abandoned"`. Defaults to `"active"`.
- `current_phase` (string, optional) – e.g. `"Phase 3: Tasks API"`.
- `current_stage` (string, optional) – `"Implementation" | "Verification" | "Debugging" | ...`.
- `last_checkpoint` (string, optional) – git hash or human label.
- `next_action` (object, optional):
  - `description` (string) – *concrete* next step.
  - `file_path` (string, optional) – primary file to open.
  - `line_hint` (int, optional) – approximate line to jump to.
- `phases` (map, optional) – `phase_id -> { status, progress, ... }`.
- `known_issues` (list of strings, optional).
- `metadata` (object, optional) – free-form metadata such as
  `human_task_title`, tags, etc.

Identity fields `session_id`, `project_id`, `user_id`, `agent_id`, and `task_id` should be treated as immutable once a session is created.
All other fields may be updated over time as work progresses.

Agents SHOULD keep `next_action` very specific, e.g.:

> "Implement PATCH /api/tasks/:id in src/routes/tasks.ts:47 with ownership check"

rather than vague descriptions like "continue API".

---

## Skill Operations

Agents and tools MUST call the **`session-memory` skill/client** (or an `IMSClient().session_memory` wrapper) rather than issuing raw HTTP requests.

### 1. Continue Session

**Operation**: `continue_session({ project_id, user_id?, agent_id?, task_id?, initial_state? })`

**NOTE: Prefer using `auto_session` (operation #5) as the primary entry point.**
Use `continue_session` only when you have an explicit `task_id` from prior context.

Resolve or create the current session for a tuple.

#### Request

```json
{
  "project_id": "my-project",             
  "user_id": "jdelon02",                 
  "agent_id": "planner",                 
  "task_id": "default",                  
  "initial_state": {                       
    "project_id": "my-project",
    "current_phase": "Phase 1",
    "current_stage": "Implementation",
    "next_action": {
      "description": "Plan database schema",
      "file_path": "docs/IMPLEMENTATION_PHASES.md",
      "line_hint": 0
    }
  }
}
```

All fields except `project_id` are optional:

- `user_id` defaulting:
  - explicit in payload → `initial_state.user_id` → environment (`IMS_USER_ID` or OS user).
- `agent_id` defaulting:
  - explicit in payload → `initial_state.agent_id` → `"default"`.
- `task_id` defaulting:
  - explicit in payload → `initial_state.task_id` → `"default"`.

If `initial_state` is omitted, a minimal `SessionState` is created.

#### Response

```json
{
  "status": "created",
  "session_id": "UUID-string",
  "state": {
    "session_id": "UUID-string",
    "project_id": "my-project",
    "user_id": "jdelon02",
    "agent_id": "planner",
    "task_id": "default",
    "status": "active",
    "current_phase": "Phase 1",
    "current_stage": "Implementation",
    "next_action": { "description": "Plan database schema", ... },
    "phases": {},
    "known_issues": [],
    "metadata": {
      "human_task_title": "Plan database schema"
    }
  }
}
```

- If a session already exists for the tuple, its current `SessionState` is
  returned (with identifiers ensured) and `status = "resumed"`.
- If no session exists, a new session is created, stored under the Redis
  key for that tuple, and returned with `status = "created"`.

---

### 2. Checkpoint Session

**Operation**: `checkpoint_session({ project_id, user_id?, agent_id?, task_id?, state })`

Persist an updated `SessionState` snapshot **mid-burst** ("I'm still working, save progress").

This operation has the same *shape* as `wrap_session`, but different semantics:
- **checkpoint** = persist progress without implying pause/hand-off/stop
- **wrap** = end-of-burst pause/hand-off/stop

Use checkpoint **frequently** during implementation/verification steps to avoid wrap chatter.

**Note**: The PostToolUse hook automatically calls `checkpoint_session` after file Edit/Write operations, updating `last_checkpoint` with the modified file path. Agents can still call this operation manually for other progress updates.

---

### 3. Wrap Session

**Operation**: `wrap_session({ project_id, user_id?, agent_id?, task_id?, state })`

Persist an updated `SessionState` snapshot for a tuple at a **true boundary**.
Semantically this is "wrap up this work burst".

**Note**: Calling `wrap_session` also clears the Redis active session marker for this project, signaling that no session is currently active.

#### Request

```json
{
  "project_id": "my-project",
  "user_id": "jdelon02",
  "agent_id": "planner",
  "task_id": "default",
  "state": {
    "session_id": "UUID-string",          
    "project_id": "my-project",
    "user_id": "jdelon02",
    "agent_id": "planner",
    "task_id": "default",
    "current_phase": "Phase 3: Tasks API",
    "current_stage": "Verification",
    "last_checkpoint": "abc1234",         
    "next_action": {
      "description": "Run tests for Tasks API",
      "file_path": "tests/test_tasks_api.py",
      "line_hint": 0
    },
    "phases": {"phase-3": {"status": "in-progress"}},
    "known_issues": []
  }
}
```

Identifier rules:

- `user_id`, `agent_id`, `task_id` on the stored state are always aligned
  with the tuple in the request.
- If `state.session_id` is missing, the service generates a new UUID.

#### Response

Same shape as `/sessions/continue`:

```json
{
  "status": "wrapped",
  "session_id": "UUID-string",
  "state": { /* final persisted SessionState */ }
}
```

---

### 4. List Open Sessions

**Operation**: `list_open_sessions({ project_id, user_id?, only_open? })`

List open sessions for a given `(project_id, user_id)`, ignoring
`agent_id` and `task_id`. This is primarily used when a user starts a
*new* chat and expresses a desire to "resume" without specifying which
session.

#### Response (shape)

```json
{
  "sessions": [
    {
      "session_id": "UUID-1",
      "project_id": "my-project",
      "user_id": "jdelon02",
      "agent_id": "planner",
      "task_id": "implement-context-rag-7f3a",
      "status": "active",
      "last_checkpoint": "abc1234",
      "next_action_summary": "Finish /context/search implementation"
    }
  ]
}
```

### 5. Resume Session

**Operation**: `resume_session({ session_id })`

Explicitly resume a session by `session_id`. The service finds the
matching `SessionState`, normalizes identity fields, and returns a
`SessionOut` with `status = "resumed"`.

### 6. Auto Session Routing (RECOMMENDED PRIMARY ENTRY POINT)

**Operation**: `auto_session({ project_id, user_message, user_id?, agent_id? })`

**This is the recommended primary entry point for all session operations.**

High-level intelligent router that inspects the user's message and either
resumes an existing session or creates a new one:

- If `user_message` clearly expresses a resume intent (e.g.
  "resume", "continue", "let's resume", "pick up where we left off",
  "pick up where we stopped", "keep going", "keep working"), the helper:
  - calls `list_open_sessions` for `(project_id, user_id)`, and
  - either resumes the single open session automatically, or
  - returns a list of candidates for the caller to choose from when multiple exist.
- Otherwise, it generates an opaque `task_id` slug from `user_message`,
  seeds `metadata.human_task_title`, and calls `continue_session` to
  create a new task session.

#### Response Format

```json
{
  "mode": "created" | "resumed" | "choice_required",
  "reason": "explanation of what happened",
  "session": {
    "status": "created" | "resumed",
    "session_id": "UUID",
    "state": { /* SessionState */ }
  },
  "sessions": [ /* array of OpenSessionSummary when mode=choice_required */ ]
}
```

#### Example Usage

```bash
curl -X POST http://localhost:8000/sessions/auto \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": "my-project",
    "user_message": "resume",
    "user_id": "jdelon02",
    "agent_id": "default"
  }'
```

**Use this operation instead of `continue_session` unless you have an explicit
`task_id` from prior context.**

---

## Active Session Tracking

The IMS backend maintains a Redis key `ims:active_session:{project_id}` that tracks which session is currently active for each project. This enables:

- **PreToolUse hook validation**: Before non-session-memory tool use, the hook checks if an active session exists via `GET /sessions/active/{project_id}`. If no active session exists, the hook blocks the operation and prompts the agent to resolve a session first.

- **Automatic session activation**: When `continue_session`, `resume_session`, or `auto_session` is called, the backend automatically sets the active session marker with a 24-hour TTL.

- **Automatic deactivation**: When `wrap_session` is called, the backend clears the active session marker.

Agents don't need to manage this directly - the backend and hooks handle it automatically. However, agents should be aware that:
- All work requires an active session
- Session-memory operations (list_open, continue, resume, auto, wrap) are always allowed
- Other tools are blocked until a session is active

---

## Capability Endpoint

The backend exposes `GET /capabilities/session-memory` which returns structured documentation about:
- Available operations (auto_session, continue_session, checkpoint_session, wrap_session, etc.)
- SessionState field definitions
- Protocol requirements and best practices

This endpoint is used by hooks to inject usage documentation into agent context at appropriate times. Agents can also call this endpoint directly to refresh their understanding of session-memory operations.

---

## Recommended Agent Workflow

For each agent (planner, implementer, debugger, etc.) and task **session**:

1. **Start or resume work – USE AUTO_SESSION (RECOMMENDED)**
   - At the beginning of a chat/run or work burst, call
     `/sessions/auto` with the user's message.
   - This is the **primary entry point** and handles:
     - Resume detection automatically
     - Single session resumption
     - Multiple session choice presentation
     - New session creation with smart task_id generation

   **Only use `continue_session` directly when:**
   - You already have an explicit `task_id` from prior context in the same conversation
   - You are explicitly creating a new session for a specific sub-task
   - You are being invoked with explicit session coordinates

   After `auto_session` returns:
   - If `mode: "resumed"` or `mode: "created"`, extract `session.state`
   - If `mode: "choice_required"`, present options and call `/sessions/resume`
   - Read `state.next_action`, `current_phase`, `current_stage`, etc.

2. **Work using SessionState**
   - Perform the next action.
   - Update the in-memory `SessionState` to reflect progress.

3. **Work burst checkpointing (frequent) – checkpoint_session**
   - During active work, after completing a discrete step (e.g. file edits, a refactor, or before running tests), update:
     - `current_phase`
     - `current_stage`
     - `last_checkpoint` (git hash or label) if applicable
     - `next_action` (planned next step)
   - Call `session-memory.checkpoint_session(...)` to persist progress.

4. **Pause, hand off, or finish (rare) – wrap_session**
   - Only when you are truly pausing/ending the burst (stop for now, switching tasks, handing off), update:
     - `current_phase`
     - `current_stage`
     - `last_checkpoint`
     - `next_action`
   - Call `session-memory.wrap_session(...)`.

Guidance:
- Do NOT `wrap_session` just because you asked the user a question.
- Do NOT `wrap_session` if nothing meaningful changed.

This protocol ensures robust pause/resume behavior, even across multiple
agents and tasks, and provides a stable foundation for later phases
(maintenance, promotion, integration with `memory-core`).

### IMS-backed Project Requirements

- For IMS-backed projects, `session-memory` is the **single source of truth**
  for session state for each **session** (each `(project_id, user_id, agent_id, task_id)` identity).
- These requirements apply to *all* agents and tools using this skill,
  whether they are Claude chatmodes, IDE agents, or non-Claude agents
  accessing it via MCP; MCP simply exposes the same operations as tools.
- Agents MUST NOT maintain separate ad-hoc notions of "current session".
- Agents MUST call `continue_session` before **any** interaction or work in
  this project (including responding to chat, planning, reading specs,
  gathering context, or editing code), and MUST call `wrap_session` before
  pausing or handing off work.
- Agents MUST surface an "IMS Session Resume" on start and an
  "IMS Session Wrap" on pause, including at least:
  `project_id`, `user_id`, `agent_id`, `task_id`, `session_id`,
  `current_phase`, `current_stage`, `last_checkpoint`, and `next_action`.
  When using `auto_session` or `list_open_sessions`/`resume_session`, the
  same resume/wrap summaries still apply once a concrete session has
  been selected.
- In addition, **every call** to the `session-memory` skill (including
  `continue_session`, `wrap_session`, `list_open_sessions`, `resume_session`,
  and `auto_session`) MUST emit a concise, human-visible log line or
  chat message showing at least:
  - the operation name (e.g. `continue_session`, `wrap_session`),
  - the resolved `(project_id, user_id, agent_id, task_id)` tuple when
    available, and
  - the returned `status` and `session_id` when those fields are present.
  This requirement applies even when calls are made indirectly through
  helper libraries or client wrappers.
