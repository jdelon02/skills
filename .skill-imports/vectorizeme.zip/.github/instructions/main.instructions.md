## IMS Projects: Mandatory Session Memory Usage

This project uses the Integrated Memory System (IMS) backend. This project requires using the `session-memory`, `memory-core`, and `context-rag` skills as primary mechanisms for memory and context.

When working within this project, the following rules apply:

1. **Session-memory is REQUIRED**

   - The `session-memory` skill is NOT optional in IMS projects.
   - All agents and automations MUST use the `session-memory` skill in the
     following step-by-step flow:

     1. **Start or resume work – Continue session**
        - At the beginning of a chat/run or work burst, call the
          *Continue session* operation for the relevant **session**
          (its `(project_id, user_id, agent_id, task_id)` identity) to
          resolve or create the current session.

     2. **Do work using `SessionState.next_action`**
        - Use the returned `SessionState.next_action` (and related
          fields like `current_phase` / `current_stage`) to decide what
          to do next.

     3. **Pause, hand off, or finish – Wrap session**
        - Before pausing, switching tasks, or handing off to another
          agent, update the in-memory `SessionState` and call the
          *Wrap session* operation to persist the new `current_phase`,
          `current_stage`, `last_checkpoint`, and `next_action`.

     4. **New chat with "resume" intent – List open sessions / resume**
        - When a user starts a *new* chat and the first message clearly
          expresses a resume intent (e.g. "let's resume", "pick up where
          we left off", "pick up where we stopped", "keep going",
          "keep working") without specifying a task, use the *List open
          sessions / resume* operations to discover existing sessions for
          this project/user and resume the one the user selects.

     5. **Optional shortcut – Auto session routing**
        - When available, use the *Auto session routing* helper given
          the first user message to automatically decide whether to
          resume an existing session or create a new one, instead of
          manually invoking steps 1 and 4.
   - All work MUST be associated with a **session** identified by the
     tuple `(project_id, user_id, agent_id, task_id)`.

2. **Canonical Session Protocol and Ordering**

   Before **any** interaction or work in this project (including answering
   questions, planning, scanning specs, using `context-rag`, or editing code):

   - If you are in an existing chat/run **and already know** the tuple or
     `session_id`, resolve the current session via the `session-memory`
     **continue session** op.
   - If the user has started a *new* chat and types a natural-language
     message that clearly expresses a resume intent (e.g. "let's resume",
     "pick up where we left off", "pick up where we stopped", "keep going",
     "keep working") without specifying which task, first use
      `session-memory` helpers to discover the right session:
       - Prefer a high-level `sessions.auto` helper when available, which
         will internally call `list_open_sessions` and `resume_session`.
       - Otherwise, call `list_open_sessions` for the current
         `(project_id, user_id)`, ask the user which open session to
         resume when multiple are returned, and then call `resume_session`
         or `continue_session` with the chosen session.
   - Use the returned `SessionState.next_action` as the starting point.
   - Emit an **"IMS Session Resume"** summary that includes at least:
     - `project_id`, `user_id`, `agent_id`, `task_id`
     - `session_id`
     - `current_phase`
     - `current_stage`
     - `last_checkpoint` (if any)
     - `next_action.description` (and `file_path` / `line_hint` when present)

   Before pausing or ending a work burst:

   - Update `SessionState` to reflect the new progress and concrete next step, including `current_phase`, `current_stage`, `last_checkpoint`, and `next_action`.
   - Persist the updated state via the `session-memory` **wrap session** op for the same tuple.
   - Emit an **"IMS Session Wrap"** summary with the updated fields so that session state changes are visible to the user.

3. **Prohibited Patterns**

   - Do NOT maintain separate, ad-hoc notions of "current task" or "current session" outside IMS for IMS projects.
   - Do NOT start work without a resolved `SessionState` obtained via the `session-memory` skill.
   - Do NOT end work without persisting an update `SessionState` via the `session-memory` skill and surfacing an "IMS Session Wrap" summary.

Violation of these rules is considered an **IMS protocol error** and may result in inconsistent or lost session memory across agents.
