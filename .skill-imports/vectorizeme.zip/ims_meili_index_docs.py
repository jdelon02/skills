#!/usr/bin/env python3
"""Index local documents into the IMS Meilisearch docs index.

Default behavior:
- Root directory to index: current working directory (where you invoked the script)
- project_id: basename(root)
- user_id: IMS_USER_ID (if set) else OS username
- Index: Meilisearch index uid "project_docs"
- File types: common text/markdown extensions (.md, .txt, ...)
- Chunking: enabled by default

Requires:
- IMS_MEILI_URL (e.g. http://localhost:7700)
- IMS_MEILI_API_KEY

Example:
  IMS_MEILI_URL=http://localhost:7700 IMS_MEILI_API_KEY=*** \
    ims_meili_index_docs.py

Tip (make callable from anywhere):
  chmod +x ims_meili_index_docs.py
  ln -sf "$PWD/ims_meili_index_docs.py" ~/bin/ims-meili-index
"""

from __future__ import annotations

import argparse
import fnmatch
import getpass
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

DEFAULT_EXTS = {
    # Docs / notes
    ".md",
    ".markdown",
    ".mdx",
    ".txt",
    ".rst",
    ".adoc",
    ".org",

    # Common code / scripts
    ".py",
    ".pyi",
    ".php",
    ".phtml",
    ".inc",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".html",
    ".css",
    ".scss",
    ".sql",
    ".sh",
    ".bash",
    ".zsh",
    ".ps1",

    # DevOps / IaC / config (text)
    ".yml",
    ".yaml",
    ".json",
    ".toml",
    ".ini",
    ".conf",
    ".tf",
    ".tfvars",

    # Salesforce / Apex
    ".cls",
    ".trigger",
    ".page",
    ".component",
    ".cmp",
    ".app",
    ".evt",
    ".auradoc",
    ".design",
}

DEFAULT_EXCLUDE_GLOBS = [
    # Secrets / key material
    ".env",
    ".env.*",
    "**/.env",
    "**/.env.*",
    "**/*.pem",
    "**/*.key",
    "**/*.p12",
    "**/*.pfx",

    # Low-signal / large artifacts
    "**/*.min.js",
    "**/*.map",
    "**/package-lock.json",
    "**/yarn.lock",
    "**/pnpm-lock.yaml",
    "**/poetry.lock",
    "**/composer.lock",
]

DEFAULT_PRUNE_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "dist",
    "build",
    ".next",
}

DEFAULT_CHUNK_MAX_CHARS = 4000
DEFAULT_SNIPPET_CHARS = 400


class MeiliIndexError(RuntimeError):
    pass


@dataclass(frozen=True)
class DocRecord:
    id: str
    project_id: str
    user_id: str
    title: str
    chunk_title: str
    path: str
    chunk_index: int
    content: str
    snippet: str
    tags: List[str]
    ext: str
    bytes: int
    mtime: float

    def to_meili(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "user_id": self.user_id,
            "title": self.title,
            "chunk_title": self.chunk_title,
            "path": self.path,
            "chunk_index": self.chunk_index,
            "content": self.content,
            "snippet": self.snippet,
            "tags": self.tags,
            "ext": self.ext,
            "bytes": self.bytes,
            "mtime": self.mtime,
        }


def _env(name: str) -> Optional[str]:
    val = os.getenv(name)
    if val is None:
        return None
    val = val.strip()
    return val or None


def _default_user_id() -> str:
    return _env("IMS_USER_ID") or getpass.getuser() or "default"


def _meili_base_url() -> str:
    url = _env("IMS_MEILI_URL")
    if not url:
        raise MeiliIndexError("IMS_MEILI_URL is not set")
    return url.rstrip("/")


def _meili_headers() -> Dict[str, str]:
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ims-meili-index/1.0",
    }
    api_key = _env("IMS_MEILI_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _http_json(method: str, url: str, *, payload: Any | None = None, timeout: float = 10.0) -> Tuple[int, Any]:
    data: Optional[bytes] = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")

    req = Request(url, data=data, method=method, headers=_meili_headers())

    try:
        with urlopen(req, timeout=timeout) as resp:  # nosec B310 - controlled by env var
            raw = resp.read()
            ct = (resp.headers.get("Content-Type") or "").lower()
            if raw and "application/json" in ct:
                return resp.status, json.loads(raw.decode("utf-8"))
            if raw:
                return resp.status, raw.decode("utf-8", errors="replace")
            return resp.status, None
    except HTTPError as exc:
        body = None
        try:
            body_raw = exc.read()
            if body_raw:
                body = body_raw.decode("utf-8", errors="replace")
        except Exception:
            body = None
        raise MeiliIndexError(f"Meilisearch HTTP error {exc.code} for {url}: {body or exc.reason}") from exc
    except URLError as exc:
        raise MeiliIndexError(f"Meilisearch request failed for {url}: {exc.reason}") from exc


def _detect_title(text: str, *, fallback: str) -> str:
    # Prefer first markdown H1.
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("# "):
            return s[2:].strip() or fallback
    # Otherwise first non-empty line.
    for line in text.splitlines():
        s = line.strip()
        if s:
            return s[:200]
    return fallback


def _tags_for_path(rel_path: Path) -> List[str]:
    # Simple, non-opinionated tags: top-level directory + extension.
    tags: List[str] = []
    parts = rel_path.parts
    if len(parts) >= 2:
        tags.append(parts[0])
    ext = rel_path.suffix.lower().lstrip(".")
    if ext:
        tags.append(ext)
    if not tags:
        tags.append("docs")
    # de-dupe while preserving order
    seen: set[str] = set()
    out: List[str] = []
    for t in tags:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def _doc_id(project_id: str, user_id: str, rel_path: str, chunk_index: int) -> str:
    # Stable, globally unique within the Meilisearch index.
    h = hashlib.sha1(
        f"{project_id}:{user_id}:{rel_path}:{chunk_index}".encode("utf-8")
    ).hexdigest()  # nosec B303 - non-crypto use
    return h


def _make_snippet(text: str, snippet_chars: int) -> str:
    if snippet_chars <= 0:
        return ""
    # Light normalization so snippets don't contain excessive whitespace.
    s = re.sub(r"\s+", " ", text.strip())
    if len(s) <= snippet_chars:
        return s
    return s[:snippet_chars].rstrip() + "…"


def _split_large_block(block: str, max_chars: int) -> List[str]:
    if max_chars <= 0:
        return [block]
    if len(block) <= max_chars:
        return [block]

    out: List[str] = []
    start = 0
    while start < len(block):
        end = min(len(block), start + max_chars)
        # Try to split on a newline boundary for readability.
        nl = block.rfind("\n", start, end)
        if nl > start + 200:  # don't create tiny fragments
            end = nl
        out.append(block[start:end].strip("\n"))
        start = end
    return [x for x in out if x.strip()]


def _chunk_by_paragraphs(text: str, max_chars: int) -> List[str]:
    # Split on blank lines. (Good-enough heuristic for .txt/.md.)
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if not paras:
        return []

    chunks: List[str] = []
    cur: List[str] = []
    cur_len = 0

    def flush() -> None:
        nonlocal cur, cur_len
        if not cur:
            return
        chunks.append("\n\n".join(cur).strip())
        cur = []
        cur_len = 0

    for p in paras:
        if max_chars > 0 and len(p) > max_chars:
            # Paragraph itself is too large; flush what we have then split it.
            flush()
            chunks.extend(_split_large_block(p, max_chars))
            continue

        add_len = len(p) + (2 if cur else 0)
        if max_chars > 0 and cur and (cur_len + add_len) > max_chars:
            flush()

        cur.append(p)
        cur_len += add_len

    flush()
    return chunks


def _chunk_markdown(text: str, max_chars: int) -> List[Tuple[str, str]]:
    """Return markdown chunks as (chunk_title, chunk_text)."""
    lines = text.splitlines()
    header_re = re.compile(r"^(#{1,6})\s+(.*)\s*$")

    sections: List[Tuple[Optional[str], List[str]]] = []
    current_title: Optional[str] = None
    current_lines: List[str] = []

    def push_section() -> None:
        nonlocal current_title, current_lines
        if current_lines:
            sections.append((current_title, current_lines))
        current_lines = []

    for line in lines:
        m = header_re.match(line)
        if m:
            # Start a new section. Flush the previous one.
            push_section()
            current_title = m.group(2).strip() or None
            current_lines = [line]
        else:
            current_lines.append(line)

    push_section()

    chunks: List[Tuple[str, str]] = []
    for sec_title, sec_lines in sections:
        sec_text = "\n".join(sec_lines).strip()
        if not sec_text:
            continue

        # If the section already fits, keep it.
        if max_chars <= 0 or len(sec_text) <= max_chars:
            chunks.append((sec_title or "(untitled)", sec_text))
            continue

        # Otherwise chunk within the section by paragraphs.
        # Keep the header line (if any) as context in each chunk.
        first = sec_lines[0] if sec_lines else ""
        rest = "\n".join(sec_lines[1:]).strip()
        sub_chunks = _chunk_by_paragraphs(rest, max_chars=max(1, max_chars - len(first) - 2))
        if not sub_chunks:
            chunks.append((sec_title or "(untitled)", sec_text))
            continue

        for i, sub in enumerate(sub_chunks, start=1):
            title = sec_title or "(untitled)"
            chunks.append((f"{title} ({i})", (first + "\n\n" + sub).strip()))

    return chunks


def _matches_any_glob(path: str, globs: Sequence[str]) -> bool:
    # Match using POSIX-style paths ("a/b/c.ext").
    for pat in globs:
        if fnmatch.fnmatch(path, pat):
            return True
    return False


def _walk_files(
    root: Path,
    *,
    prune_dirs: set[str],
    include_globs: Sequence[str],
    exclude_globs: Sequence[str],
) -> Iterable[Path]:
    # Use os.walk so we can prune directories cheaply.
    for dirpath, dirnames, filenames in os.walk(root):
        # Prune in-place
        dirnames[:] = [d for d in dirnames if d not in prune_dirs and not d.startswith(".")]
        for name in filenames:
            if name.startswith("."):
                continue

            p = Path(dirpath) / name
            try:
                rel = p.relative_to(root).as_posix()
            except ValueError:
                rel = p.as_posix()

            if exclude_globs and _matches_any_glob(rel, exclude_globs):
                continue

            if include_globs and not _matches_any_glob(rel, include_globs):
                continue

            yield p


def collect_docs(
    *,
    root: Path,
    project_id: str,
    user_id: str,
    exts: set[str],
    max_bytes: int,
    prune_dirs: set[str],
    include_globs: Sequence[str],
    exclude_globs: Sequence[str],
    chunking: bool,
    chunk_max_chars: int,
    snippet_chars: int,
) -> Tuple[List[DocRecord], Dict[str, int]]:
    records: List[DocRecord] = []
    stats = {
        "seen": 0,
        "files_kept": 0,
        "chunks_kept": 0,
        "skipped_ext": 0,
        "skipped_large": 0,
        "skipped_read": 0,
    }

    for path in _walk_files(
        root,
        prune_dirs=prune_dirs,
        include_globs=include_globs,
        exclude_globs=exclude_globs,
    ):
        stats["seen"] += 1

        ext = path.suffix.lower()
        if ext not in exts:
            stats["skipped_ext"] += 1
            continue

        try:
            st = path.stat()
        except OSError:
            stats["skipped_read"] += 1
            continue

        if st.st_size > max_bytes:
            stats["skipped_large"] += 1
            continue

        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            stats["skipped_read"] += 1
            continue

        rel_path = str(path.relative_to(root))
        file_title = _detect_title(text, fallback=path.name)
        tags = _tags_for_path(Path(rel_path))

        if chunking:
            if ext in {".md", ".markdown", ".mdx"}:
                chunk_pairs = _chunk_markdown(text, max_chars=chunk_max_chars)
                chunks = [c for _, c in chunk_pairs]
                chunk_titles = [t for t, _ in chunk_pairs]
            else:
                chunks = _chunk_by_paragraphs(text, max_chars=chunk_max_chars)
                chunk_titles = [file_title for _ in chunks]
        else:
            chunks = [text]
            chunk_titles = [file_title]

        if not chunks:
            continue

        stats["files_kept"] += 1

        for idx, chunk_text in enumerate(chunks):
            chunk_title = chunk_titles[idx] if idx < len(chunk_titles) else file_title
            rec = DocRecord(
                id=_doc_id(project_id, user_id, rel_path, idx),
                project_id=project_id,
                user_id=user_id,
                title=file_title,
                chunk_title=chunk_title,
                path=rel_path,
                chunk_index=idx,
                content=chunk_text,
                snippet=_make_snippet(chunk_text, snippet_chars=snippet_chars),
                tags=tags,
                ext=ext.lstrip("."),
                bytes=int(st.st_size),
                mtime=float(st.st_mtime),
            )
            records.append(rec)
            stats["chunks_kept"] += 1

    return records, stats


def _chunked(items: Sequence[DocRecord], chunk_size: int) -> Iterable[List[DocRecord]]:
    for i in range(0, len(items), chunk_size):
        yield list(items[i : i + chunk_size])


def ensure_index(index_uid: str) -> None:
    base = _meili_base_url()
    # Create index (idempotent-ish). If it already exists, Meilisearch returns 409.
    try:
        _http_json("POST", f"{base}/indexes", payload={"uid": index_uid, "primaryKey": "id"})
    except MeiliIndexError as exc:
        # Best effort: tolerate "index already exists" (409).
        if "HTTP error 409" not in str(exc):
            raise

    # Best-effort: ensure useful filterable attributes for scoping.
    # This is safe to run repeatedly.
    try:
        _http_json(
            "PUT",
            f"{base}/indexes/{index_uid}/settings/filterable-attributes",
            payload=["project_id", "user_id", "tags", "path", "ext"],
        )
    except MeiliIndexError:
        pass


def upload_docs(
    *,
    index_uid: str,
    records: Sequence[DocRecord],
    batch_size: int,
    dry_run: bool,
) -> None:
    if not records:
        return

    if dry_run:
        return

    base = _meili_base_url()
    endpoint = f"{base}/indexes/{index_uid}/documents"

    for batch in _chunked(records, batch_size):
        payload = [r.to_meili() for r in batch]
        status, body = _http_json("POST", endpoint, payload=payload, timeout=30.0)
        # Meilisearch typically responds 202 with a task object.
        if status >= 400:
            raise MeiliIndexError(f"Meilisearch returned status {status}: {body}")


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Index the current directory's docs into Meilisearch (IMS docs index).",
    )
    p.add_argument(
        "--root",
        type=str,
        default=None,
        help="Root directory to index (default: current working directory).",
    )
    p.add_argument(
        "--project-id",
        type=str,
        default=None,
        help="Override project_id (default: basename(root)).",
    )
    p.add_argument(
        "--user-id",
        type=str,
        default=None,
        help="Override user_id (default: IMS_USER_ID else OS username).",
    )
    p.add_argument(
        "--index",
        type=str,
        default="project_docs",
        help='Meilisearch index uid (default: "project_docs").',
    )
    p.add_argument(
        "--ext",
        action="append",
        default=None,
        help=(
            "Extensions to include (repeatable). Example: --ext .md --ext .txt. "
            "Default: a curated set of common doc/code/config extensions."
        ),
    )
    p.add_argument(
        "--include-glob",
        action="append",
        default=None,
        help=(
            "Only include files whose *relative path* matches this glob (repeatable). "
            "Example: --include-glob '**/*-meta.xml'. "
            "If provided, files must match at least one include glob."
        ),
    )
    p.add_argument(
        "--exclude-glob",
        action="append",
        default=None,
        help=(
            "Exclude files whose *relative path* matches this glob (repeatable). "
            "Example: --exclude-glob '**/*.min.js'."
        ),
    )
    p.add_argument(
        "--no-default-excludes",
        action="store_true",
        help="Disable the built-in exclude glob list (secrets, lockfiles, maps, etc.).",
    )
    p.add_argument(
        "--max-bytes",
        type=int,
        default=2_000_000,
        help="Skip files larger than this many bytes (default: 2,000,000).",
    )
    p.add_argument(
        "--batch-size",
        type=int,
        default=100,
        help="Number of docs per Meilisearch upsert request (default: 100).",
    )
    p.add_argument(
        "--no-chunking",
        action="store_true",
        help="Disable chunking and index each file as a single document.",
    )
    p.add_argument(
        "--chunk-max-chars",
        type=int,
        default=DEFAULT_CHUNK_MAX_CHARS,
        help=f"Approx max characters per chunk (default: {DEFAULT_CHUNK_MAX_CHARS}).",
    )
    p.add_argument(
        "--snippet-chars",
        type=int,
        default=DEFAULT_SNIPPET_CHARS,
        help=f"Max characters to store in the 'snippet' field (default: {DEFAULT_SNIPPET_CHARS}).",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Collect/print stats but do not upload anything.",
    )
    p.add_argument(
        "--no-prune",
        action="store_true",
        help="Do not prune common directories like .git, node_modules, .venv.",
    )
    p.add_argument(
        "--verbose",
        action="store_true",
        help="Print each chunk as it is collected.",
    )
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)

    root = Path(args.root).expanduser().resolve() if args.root else Path.cwd().resolve()
    project_id = args.project_id or root.name
    user_id = args.user_id or _default_user_id()

    exts = (
        DEFAULT_EXTS
        if args.ext is None
        else {e.lower() if e.startswith(".") else f".{e.lower()}" for e in args.ext}
    )
    prune_dirs = set() if args.no_prune else set(DEFAULT_PRUNE_DIRS)

    include_globs = [] if args.include_glob is None else list(args.include_glob)
    user_excludes = [] if args.exclude_glob is None else list(args.exclude_glob)
    exclude_globs = [] if args.no_default_excludes else list(DEFAULT_EXCLUDE_GLOBS)
    exclude_globs.extend(user_excludes)

    t0 = time.time()
    records, stats = collect_docs(
        root=root,
        project_id=project_id,
        user_id=user_id,
        exts=exts,
        max_bytes=int(args.max_bytes),
        prune_dirs=prune_dirs,
        include_globs=include_globs,
        exclude_globs=exclude_globs,
        chunking=not bool(args.no_chunking),
        chunk_max_chars=int(args.chunk_max_chars),
        snippet_chars=int(args.snippet_chars),
    )

    if args.verbose:
        for r in records:
            print(f"{r.path}#{r.chunk_index} {r.chunk_title}")

    print(
        "\n".join(
            [
                f"root:         {root}",
                f"project_id:   {project_id}",
                f"user_id:      {user_id}",
                f"index:        {args.index}",
                f"exts:         {', '.join(sorted(exts))}",
                f"include_globs:{', '.join(include_globs) if include_globs else '(none)'}",
                f"exclude_globs:{', '.join(exclude_globs) if exclude_globs else '(none)'}",
                f"chunking:     {not bool(args.no_chunking)}",
                f"chunk_chars:  {int(args.chunk_max_chars)}",
                f"snippet_chars:{int(args.snippet_chars)}",
                f"seen:         {stats['seen']}",
                f"files_kept:   {stats['files_kept']}",
                f"chunks_kept:  {stats['chunks_kept']}",
                f"skipped:      ext={stats['skipped_ext']} large={stats['skipped_large']} read={stats['skipped_read']}",
                f"dry_run:      {bool(args.dry_run)}",
            ]
        )
    )

    if not args.dry_run:
        ensure_index(args.index)
        upload_docs(
            index_uid=args.index,
            records=records,
            batch_size=int(args.batch_size),
            dry_run=bool(args.dry_run),
        )

    dt = time.time() - t0
    print(f"done in {dt:.2f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
