# IMS Meilisearch Doc Indexer (Chunked)

This repo contains a small, dependency-free script (`ims_meili_index_docs.py`) that indexes local text/markdown documents into **Meilisearch** for use by the Integrated Memory System (IMS) docs retrieval.

Unlike the earlier whole-file approach, this script **chunks files** by default and uploads **one chunk per Meilisearch document**, which tends to produce better search results.

## What it does

When you run the script from any directory:

- **Root to index**: the directory you invoked it from (recursive)
- **project_id**: `basename(root)`
- **user_id (owner)**: `IMS_USER_ID` if set, otherwise your OS username
- **Index**: Meilisearch index uid `project_docs`
- **File types**: a curated set of common *text* formats (docs + code + config). Override via `--ext`.
- **Optional include/exclude filters**: limit by path globs via `--include-glob` / `--exclude-glob`.
- **Chunking**:
  - Markdown (`.md`, `.markdown`, `.mdx`): split by headings first; oversized sections are further split by paragraphs
  - Text-like (`.txt`, `.rst`, etc.): split by paragraphs (blank-line separated)

Each chunk document includes:

- `project_id`, `user_id`
- `path` (relative to root)
- `title` (file title)
- `chunk_title` (section title for markdown)
- `chunk_index` (0-based)
- `content` (chunk text)
- `snippet` (short, whitespace-normalized preview)
- `tags`, `ext`, `mtime`, `bytes`

The script also attempts to configure Meilisearch filterable attributes to include:

- `project_id`, `user_id`, `tags`, `path`, `ext`

## Requirements

You must export the following environment variables:

- `IMS_MEILI_URL` (e.g. `http://localhost:7700`)
- `IMS_MEILI_API_KEY`

Optional:

- `IMS_USER_ID` (if you want to override the default owner)

## Install / run globally on macOS

This is a standalone Python script. The easiest global install pattern is to symlink it into a directory on your `PATH`.

### 1) Make the script executable

```bash
chmod +x /path/to/vectorizeme/ims_meili_index_docs.py
```

### 2) Put a symlink in `~/bin` (recommended)

```bash
mkdir -p ~/bin
ln -sf /path/to/vectorizeme/ims_meili_index_docs.py ~/bin/ims-meili-index
```

### 3) Ensure `~/bin` is on your `PATH`

Add this to your `~/.zshrc`:

```bash
export PATH="$HOME/bin:$PATH"
```

Reload your shell:

```bash
source ~/.zshrc
```

You should now be able to run `ims-meili-index` from any directory.

## Usage

### Dry run (no upload)

```bash
ims-meili-index --dry-run
```

### Include / exclude filtering (globs)

You can restrict indexing by *relative path* globs:

- `--include-glob` (repeatable): only include files matching at least one glob
- `--exclude-glob` (repeatable): skip files matching any glob

By default, the script also applies a small built-in exclude list for common secret
files and low-signal artifacts (e.g. `.env*`, `*.pem`, `*.min.js`, lockfiles). You
can disable that behavior with `--no-default-excludes`.

Example: index Salesforce metadata files (common pattern: `*-meta.xml`) without
indexing all XML files:

```bash
ims-meili-index --include-glob '**/*-meta.xml'
```

### Upload (chunked by default)

```bash
export IMS_MEILI_URL="http://localhost:7700"
export IMS_MEILI_API_KEY="..."

# optional
export IMS_USER_ID="alice"

ims-meili-index
```

### Tune chunk size / snippet size

```bash
ims-meili-index --chunk-max-chars 2500 --snippet-chars 600
```

### Disable chunking (index whole-file as one document)

```bash
ims-meili-index --no-chunking
```

### Override root / project_id / user_id

```bash
ims-meili-index \
  --root /path/to/some/dir \
  --project-id some-project \
  --user-id alice
```

## Notes / caveats

- The script skips hidden files and prunes common large directories by default (e.g. `.git`, `node_modules`, `.venv`, `dist`, etc.).
- It skips files larger than ~2MB by default (configurable via `--max-bytes`).
- Chunk ids are stable per `(project_id, user_id, path, chunk_index)`.

## Future IMS change (important)

Right now, the IMS `/context/search` docs path typically:

- queries Meilisearch index `project_docs`
- filters by `project_id`

This script now writes *chunked* documents, adds richer metadata (e.g. `ext`, `tags`), and is intended to index a broader set of **text** files (docs + code + config). **IMS / ims-mcp will not automatically take advantage of these changes unless you update the IMS implementation.**

When updating ims-mcp / IMS docs retrieval to work well with mixed file types, consider:

1. **Return better snippets**
   - Prefer the stored `snippet` field (or generate snippets) rather than returning full chunk content as the hit preview.

2. **Filtering controls (file types, paths, tags)**
   - Consider allowing optional filters in the docs retrieval request and mapping them to Meilisearch filters:
     - `ext IN [...]` (e.g. only `md`/`txt`, or only `cls`/`trigger` for Apex)
     - `path` prefix filtering (e.g. restrict to `docs/`)
     - `tags` filtering (e.g. `tags = 'terraform'`)
   - At minimum, ensure `ext`, `path`, and `tags` remain filterable attributes in the Meilisearch index settings.

3. **Salesforce metadata (`*-meta.xml`)**
   - This indexer supports indexing Salesforce metadata via `--include-glob '**/*-meta.xml'`.
   - If ims-mcp wants to distinguish metadata vs source files, consider:
     - tagging `*-meta.xml` records explicitly (e.g. add a tag like `sf-meta`), or
     - applying an `ext`/`path` filter convention in the ims-mcp docs query layer.

4. **Ranking/scoring with many small chunks**
   - Chunking increases document count substantially; validate that the number of returned hits (`k`) and your UI/prompt budget still make sense.
   - If relevance becomes noisy, consider adding a lightweight post-filter step that prefers fewer unique `path` values (dedupe per file) or re-ranks by `path` + score.

5. **Multi-user isolation (optional)**
   - Decide whether docs retrieval should also filter by `user_id` (multi-user isolation) or remain project-only.

If you keep IMS query semantics simple, a pragmatic first step is: support `ext` filters in ims-mcp, and default to returning `snippet` for the user-facing preview.
